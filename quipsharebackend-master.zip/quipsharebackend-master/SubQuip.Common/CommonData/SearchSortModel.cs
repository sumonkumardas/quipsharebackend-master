﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using SubQuip.Common.Enums;

namespace SubQuip.Common.CommonData
{
    public class SearchSortModel
    {
        public string SearchString { get; set; }

        public string SortColumn { get; set; }

        public SortDirection SortDirection { get; set; } = SortDirection.Desc;

        public int Page { get; set; } = 1;

        public int PageSize { get; set; } = 10;

        [BindNever]
        public int? TotalRecords { get; set; }

        [BindNever]
        public dynamic SearchResult { get; set; }

        public List<Filter> Filters { get; set; } = new List<Filter>();

        /// <summary>
        /// Property is only for those entities who having tech specs
        /// </summary>
        public bool IstechSpecRequired { get; set; }

        /// <summary>
        /// Prperty to get all single column values as per search sort criteria
        /// </summary>
        public string SingleColumnName { get; set; }
    }


    public class Filter
    {
        public string PropertyName { get; set; }
        public ExpressionOperation ExpOperation { get; set; }
        public List<string> Value { get; set; }
    }
}
