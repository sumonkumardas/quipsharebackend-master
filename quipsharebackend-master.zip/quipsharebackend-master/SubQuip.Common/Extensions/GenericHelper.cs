﻿using SubQuip.Common.CommonData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace SubQuip.Common.Extensions
{
    public static class GenericHelper
    {
        public static DateTime CurrentDate => DateTime.Now;

        public static UserClaim GetUserClaimDetails(ClaimsIdentity identity)
        {
            UserClaim userClaim = null;
            if (identity != null)
            {
                if (identity.Claims.Any())
                {
                    IEnumerable<Claim> claims = identity.Claims;

                    userClaim = new UserClaim
                    {
                        Name = identity.FindFirst("Name").Value
                    };
                    var emailClaim = identity.FindFirst(ClaimTypes.Email) ?? identity.FindFirst(ClaimTypes.Upn);
                    userClaim.Email = emailClaim.Value;
                }
            }
            return userClaim;
        }

        /// <summary>
        /// Get the email of request user
        /// </summary>
        /// <param name="identity"></param>
        /// <returns></returns>
        public static string GetActiveUserId(this ClaimsIdentity identity)
        {
            var emailClaim = identity.FindFirst(ClaimTypes.Email) ?? identity.FindFirst(ClaimTypes.Upn);
            return emailClaim != null ? emailClaim.Value : string.Empty;
        }

        /// <summary>
        /// Get the Name of request user
        /// </summary>
        /// <param name="identity"></param>
        /// <returns></returns>
        public static string GetActiveUserName(this ClaimsIdentity identity)
        {
            if (identity != null)
            {
                if (identity.Claims.Any())
                {
                    var name = identity.Claims.SingleOrDefault(x => x.Type == "name");
                    return name != null ? name.Value : string.Empty;
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Maps the audit columns.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <param name="identity"></param>
        public static void MapAuditColumns(this object model, ClaimsIdentity identity)
        {
            if (identity != null)
            {
                var authorizedInfo = GenericHelper.GetUserClaimDetails(identity);
                if (model != null && authorizedInfo != null)
                {
                    var emailId = authorizedInfo.Email;
                    var createdBy = Convert.ToString(GetColumnValue(Constants.CreatedBy, model));
                    if (string.IsNullOrEmpty(createdBy))
                    {
                        SetColumnValue(Constants.IsActiveColumn, model, true);
                        SetColumnValue(Constants.CreatedDate, model, CurrentDate);
                        SetColumnValue(Constants.CreatedBy, model, emailId);
                    }
                    SetColumnValue(Constants.ModifiedDate, model, CurrentDate);
                    SetColumnValue(Constants.ModifiedBy, model, emailId);
                }
            }
        }

        /// <summary>
        /// Gets the column value.
        /// </summary>
        /// <param name="columnName">Name of the column.</param>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        public static object GetColumnValue(String columnName, object entity)
        {
            var pinfo = entity.GetType().GetProperty(columnName);
            if (pinfo == null) { return null; }
            return pinfo.GetValue(entity, null);
        }

        /// <summary>
        /// Sets the column value.
        /// </summary>
        /// <param name="columnName">Name of the column.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="value">The value.</param>
        public static void SetColumnValue(String columnName, object entity, object value)
        {
            var pinfo = entity.GetType().GetProperty(columnName);
            if (pinfo != null) { pinfo.SetValue(entity, value, null); }
        }

        /// <summary>
        /// Create expression from property name
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="entityName"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static Expression<Func<T, TValue>> MemberSelector<T, TValue>(string entityName, string propertyName)
        {
            var parameter = Expression.Parameter(typeof(T), entityName);
            var body = Expression.PropertyOrField(parameter, propertyName);
            return Expression.Lambda<Func<T, TValue>>(body, parameter);
        }

        public static string GenerateContractSequence(string sequenceValue)
        {
            if (sequenceValue.Length >= 4)
                return sequenceValue;

            while (sequenceValue.Length != 4)
            {
                sequenceValue = "0" + sequenceValue;
            }
            return sequenceValue;
        }

    }
}
