using System.Collections.Generic;

namespace SubQuip.Common.Importer
{
    public class ImportedData
    {
        public List<string> Headers { get; } = new List<string>();
        public List<Dictionary<string, string>> RowData { get; } = new List<Dictionary<string, string>>();

        public List<DataParsingError> Errors { get; } = new List<DataParsingError>();

    }

    public class DataParsingError
    {
        public int ErrorRow { get; set; }

        public string Row { get; set; }

        public string ErrorString { get; set; }
    }
}