using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SubQuip.Common.CommonData;


namespace SubQuip.Common.Importer
{
    public class CsvFileReader
    {
        private readonly char _seperator = ';';
        private readonly Encoding _encoding = Encoding.GetEncoding("iso-8859-1");

        /// <summary>
        /// Default constructor for CsvFileReader. Default seperator is ;
        /// </summary>
        public CsvFileReader()
        {

        }

        /// <summary>
        /// Create a new CsvFileReader with a custom seperator
        /// </summary>
        /// <param name="seperator">The field seperator to use</param>
        /// <param name="encoding"></param>
        public CsvFileReader(char seperator, Encoding encoding)
        {
            this._seperator = seperator;
            this._encoding = encoding;
        }

        public ImportedData ProcessFile(Stream fileStream)
        {
            using (var streamReader = new StreamReader(fileStream, _encoding))
            {
                var rowNum = 0;
                var headerLine = streamReader.ReadLine();
                var importedData = new ImportedData();
                if (headerLine == null) return importedData;
                var headers = headerLine.Split(_seperator).Select(s => s.Trim()).ToList();
                importedData.Headers.AddRange(headers);
                while (!streamReader.EndOfStream)
                {
                    rowNum++;
                    var rowLine = streamReader.ReadLine();
                    if (string.IsNullOrEmpty(rowLine)) continue;
                    var rowValues = rowLine.Split(_seperator).Select(s => s.Trim()).ToList();

                    if (headers.Count != rowValues.Count)
                    {
                        importedData.Errors.Add(new DataParsingError
                        {
                            ErrorRow = rowNum,
                            Row = rowLine,
                            ErrorString = CommonErrorMessages.HdrRowCountNotMatched
                        });
                    }
                    else
                    {
                        var row = new Dictionary<string, string>();
                        for (var i = 0; i < headers.Count; i++)
                        {
                            try
                            {
                                if (i < rowValues.Count)
                                    row.Add(headers[i], rowValues[i]);
                            }
                            catch (IndexOutOfRangeException ex)
                            {
                                importedData.Errors.Add(new DataParsingError
                                {
                                    ErrorRow = rowNum,
                                    Row = rowLine,
                                    ErrorString = string.Format(CommonErrorMessages.IndexOutofRange, ex.Message)
                                });
                            }
                            catch (Exception ex)
                            {
                                importedData.Errors.Add(new DataParsingError
                                {
                                    ErrorRow = rowNum,
                                    Row = rowLine,
                                    ErrorString = ex.Message
                                });
                            }
                        }
                        importedData.RowData.Add(row);
                    }
                }
                return importedData;
            }
        }
    }
}