﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SubQuip.Entity.Models
{
   public class Contract : BaseEntity
    {
        [BsonId]
        public ObjectId ContractId { get; set; }

        [BsonElement("regardingId")]
        public ObjectId RegardingId { get; set; }

        [BsonElement("contractTitle")]
        public string ContractTitle { get; set; }

        [BsonElement("contractNumber")]
        public string ContractNumber { get; set; }

        [BsonElement("contractData")]
        public string ContractData{ get; set; }

        [BsonElement("contractFile")]
        public ObjectId? ContractFile { get; set; }
    }
}
