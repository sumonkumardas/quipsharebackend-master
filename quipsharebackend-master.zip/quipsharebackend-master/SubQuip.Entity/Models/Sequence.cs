﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SubQuip.Entity.Models
{
    public class Sequence
    {
        [BsonId]
        public ObjectId SequenceId { get; set; }

        [BsonElement("sequenceName")]
        public string SequenceName { get; set; }

        [BsonElement("sequenceValue")]
        public long SequenceValue { get; set; }
    }
}
