﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.Entity.Models
{
    public class Licence : BaseEntity
    {
        [BsonId]
        public ObjectId LicenceId { get; set; }

        [BsonElement("licenceNumber")]
        public string LicenceNumber { get; set; }

        [BsonIgnore]
        public bool IsDeleted { get; set; }
    }
}
