﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using SubQuip.Entity.Models.BillOfMaterials;
using System.Collections.Generic;

namespace SubQuip.Entity.Models
{
    public class Equipment : BaseEntity
    {
        [BsonId]
        public ObjectId EquipmentId { get; set; }

        [BsonElement("equipment_number")]
        public string EquipmentNumber { get; set; }

        [BsonElement("material")]
        public ObjectId Material { get; set; }

        [BsonElement("materialNumber")]
        public string MaterialNumber { get; set; }

        [BsonElement("manufactor_part_number")]
        public string ManufactorPartNumber { get; set; }

        [BsonElement("manufactor_serial_number")]
        public string ManufactorSerialNumber { get; set; }

        [BsonElement("manufactor_name")]
        public string ManufactorName { get; set; }

        [BsonElement("vendor_part_number")]
        public string VendorPartNumber { get; set; }

        [BsonElement("vendor_serial_number")]
        public string VendorSerialNumber { get; set; }

        [BsonElement("vendor_name")]
        public string Vendor { get; set; }

        [BsonElement("description")]
        public string Description { get; set; }

        [BsonElement("owner")]
        public string Owner { get; set; }

        [BsonElement("location")]
        public string Location { get; set; }

        [BsonElement("imageId")]
        public ObjectId? ImageId { get; set; }

        [BsonElement("partProperties")]
        public List<PartProperty> PartProperties { get; set; }

        [BsonElement("documents")]
        public List<ObjectId> Documents { get; set; }

        [BsonElement("technicalSpecifications")]
        public List<TechnicalSpecification> TechnicalSpecifications { get; set; }

        [BsonIgnore]
        public bool IsDeleted { get; set; }
    }
}
