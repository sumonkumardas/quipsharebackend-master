﻿using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using SubQuip.Entity.Models.BillOfMaterials;

namespace SubQuip.Entity.Models
{
    public class Material :BaseEntity
    {
        [BsonId]
        public ObjectId MaterialId { get; set; } //Should be unique, hidden from user

        [BsonElement("materialnumber")]
        public string Materialnumber { get; set; }

        [BsonElement("description")]
        public string Description { get; set; }

        [BsonElement("manufactor_part_number")]
        public string ManufactorPartNumber { get; set; }

        [BsonElement("manufactor_serial_number")]
        public string ManufactorSerialNumber { get; set; }

        [BsonElement("manufactor_name")]
        public string ManufactorName { get; set; }

        [BsonElement("Owner")]
        public string Owner { get; set; }

        [BsonElement("Location")]
        public string Location { get; set; }

        [BsonElement("type")]
        public string Type { get; set; }

        [BsonElement("imageId")]
        public ObjectId? ImageId { get; set; }

        [BsonElement("partProperties")]
        public List<PartProperty> PartProperties { get; set; }

        [BsonElement("documents")]
        public List<ObjectId> Documents { get; set; }

        [BsonElement("technicalSpecifications")]
        public List<TechnicalSpecification> TechnicalSpecifications { get; set; }

        [BsonIgnore]
        public bool IsDeleted { get; set; }

    }
}
