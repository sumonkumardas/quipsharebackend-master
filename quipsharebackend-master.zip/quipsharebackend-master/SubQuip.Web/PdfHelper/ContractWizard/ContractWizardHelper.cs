﻿using System;
using System.Collections.Generic;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using SubQuip.ViewModel.ContractWizard;

namespace SubQuip.WebApi.PdfHelper.ContractWizard
{
    /// <summary>
    /// Contract wizard
    /// </summary>
    public static class ContractWizardHelper
    {
        /// <summary>
        /// Dummy data for contract wizard pdf
        /// </summary>
        /// <returns></returns>
        public static ContractWizardViewModel GetDummy()
        {
            var add1 = new ContractAddressViewModel
            {
                CompanyName = "A/S NORSKE SHELL",
                Email = "shell@shell.com",
                AddressType = ContractWizardTypes.Owner,
                Address = "P.b. 2244, 6503 KRISTIANSUND",
                Fax = "71564030",
                Technical = "Technical: Jan André Furnes",
                Commercial = "Commercial: Jan André Furnes",
                Telephone = "71564030"
            };
            var add2 = new ContractAddressViewModel
            {
                CompanyName = "A/S NORSKE Ludin",
                Email = "Ludin@Ludin.com",
                AddressType = ContractWizardTypes.Renter,
                Address = "P.b. 2244, 6503 KRISTIANSUND",
                Fax = "71564031",
                Technical = "Technical: Jan André Furnes",
                Commercial = "Commercial: Jan André Furnes",
                Telephone = "71564031"
            };

            var part1 = new ContractPart { Item = "1", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 1", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part2 = new ContractPart { Item = "2", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 1", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part3 = new ContractPart { Item = "3", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 3", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part4 = new ContractPart { Item = "4", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 4", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part5 = new ContractPart { Item = "5", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 5", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part6 = new ContractPart { Item = "6", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 6", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part7 = new ContractPart { Item = "7", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 7", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part8 = new ContractPart { Item = "8", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 8", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part9 = new ContractPart { Item = "9", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 9", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part10 = new ContractPart { Item = "10", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 10", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            //var part11 = new ContractPart { Item = "6", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 6", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            //var part12 = new ContractPart { Item = "7", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 7", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            //var part13 = new ContractPart { Item = "8", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 8", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            //var part14 = new ContractPart { Item = "9", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 9", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            //var part15 = new ContractPart { Item = "10", Description = "TUBING HANGER RUNNING/RETRIEVAL TOOL 10", SubQuipRate = "2368", RentalPerDay = "2323", SubQuipNo = "123456" };
            var part16 = new ContractPart { Item = "", Description = "Total", SubQuipRate = "42368", RentalPerDay = "12323", SubQuipNo = "" };

            var term1 = new ContractSpecificTerm { Item = "a)", Term = "In case the OWNER determines in its sole judgment that it requires the rented EQUIPMENT or parts of such in connection with a need for immediate intervention of subsea wells at Draugen, the RENTER shall within six (6) weeks of being notified by OWNER of such need, return the requested EQUIPMENT (or the requested parts of such) to OWNER or obtain equivalent equipment (at RENTER’s expense) from another source and deliver it to OWNER." };
            var term2 = new ContractSpecificTerm { Item = "b)", Term = "The EQUIPMENT shall be returned to the OWNER no later than the end of the RENTAL PERIOD, overhauled and preserved at the cost of the RENTER in accordance with KOS/FMC maintenance procedures for long term storage outdoors. Particular attention shall be given to internal corrosion protection." };
            var term3 = new ContractSpecificTerm { Item = "c)", Term = "Possible modification of the EQUIPMENT requires advance written approval by the OWNER" };
            var term4 = new ContractSpecificTerm { Item = "d)", Term = "RENTER shall log all use of the EQUIPMENT such that a history of usage and loads is made available to the OWNER after the rental period. RENTER shall cover their proportionate part of certification costs according to logged hours." };
            var term5 = new ContractSpecificTerm { Item = "e)", Term = "All lengths shall be delivered with end protection. The lengths will be delivered in suitable transport baskets" };
            var term6 = new ContractSpecificTerm { Item = "f)", Term = "RENTER shall document when the EQUIPMENT was demobilised and arrived onshore for overhaul and preservation. In the time from arrival onshore to return of the EQUIPMENT to COLLECTION ADDRESS, the day rate is halved, unless OWNER can document that alternative opportunities for hiring out of the EQUIPMENT has been lost. If OWNER can document loss of alternative rental of the EQUIPMENT in the period, RENTER shall pay the full daily rate until the EQUIPMENT has been returned to COLLECTION ADDRESS, and has been made available to the OWNER.  In the event the EQUIPMENT is not returned to OWNER by the END DATE, RENTER shall pay double the daily rate until the EQUIPMENT has been returned to COLLECTION ADDRESS, and has been made available to the OWNER." };
            var term7 = new ContractSpecificTerm { Item = "c)", Term = "Possible modification of the EQUIPMENT requires advance written approval by the OWNER" };
            var term8 = new ContractSpecificTerm { Item = "d)", Term = "RENTER shall log all use of the EQUIPMENT such that a history of usage and loads is made available to the OWNER after the rental period. RENTER shall cover their proportionate part of certification costs according to logged hours." };
            var term9 = new ContractSpecificTerm { Item = "e)", Term = "All lengths shall be delivered with end protection. The lengths will be delivered in suitable transport baskets" };
            var term10 = new ContractSpecificTerm { Item = "f)", Term = "RENTER shall document when the EQUIPMENT was demobilised and arrived onshore for overhaul and preservation. In the time from arrival onshore to return of the EQUIPMENT to COLLECTION ADDRESS, the day rate is halved, unless OWNER can document that alternative opportunities for hiring out of the EQUIPMENT has been lost. If OWNER can document loss of alternative rental of the EQUIPMENT in the period, RENTER shall pay the full daily rate until the EQUIPMENT has been returned to COLLECTION ADDRESS, and has been made available to the OWNER.  In the event the EQUIPMENT is not returned to OWNER by the END DATE, RENTER shall pay double the daily rate until the EQUIPMENT has been returned to COLLECTION ADDRESS, and has been made available to the OWNER." };

            var tnA1 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 1 – EQUIPMENT FOR HIRE",
                Articles = new List<ContractTnCArticle> { new ContractTnCArticle { Item = "1.1", ArticleText = "This CONTRACT covers the EQUIPMENT specified on the front page and/ or attachments. The RENTER shall collect the EQUIPMENT at the COLLECTION ADDRESS specified on the front page. The RENTER shall, during the rental period, ensure that the OWNER’s EQUIPMENT is clearly marked and easily identifiable." } }
            };
            var tnA2 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 2 – RENTAL RATES",
                Articles = new List<ContractTnCArticle>
                {
                    new ContractTnCArticle { Item = "2.1", ArticleText = "The EQUIPMENT rental rates begin and apply for the period that the EQUIPMENT is available to RENTER. The payment ceases when the EQUIPMENT has been returned to the COLLECTION ADDRESS or the onshore base agreed by the parties. Normal wear and tear is included in the rental rates. The rental rates are net rates and any other costs that are incurred, including, but not limited to taxes, import or export duties, VAT, customs clearance documentation fees, trallying, certification of weight, loading and transportation costs shall be for RENTER's account." },
                    new ContractTnCArticle { Item = "2.2", ArticleText = "Damages or wear which in OWNER’s opinion represent a loss in value beyond normal wear and tear shall be covered by RENTER. The RENTER shall see to that the EQUIPMENT is returned to good operating condition as soon as possible. If the RENTER does not perform this, the OWNER shall have the right to arrange for repair and charge the OWNER with all costs related to the repair." },
                    new ContractTnCArticle { Item = "2.3", ArticleText = "The RENTER shall perform maintenance of the EQUIPMENT unless otherwise agreed." }
                }
            };
            var tnA3 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 3 – COLLECTION",
                Articles = new List<ContractTnCArticle>
                {
                    new ContractTnCArticle { Item = "3.1", ArticleText = "The RENTER shall collect the EQUIPMENT from the OWNER’s COLLECTION ADDRESS. All costs in connection with this shall be covered by the RENTER." }
                }
            };
            var tnA4 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 4 - PAYMENT",
                Articles = new List<ContractTnCArticle>
                {
                    new ContractTnCArticle { Item = "4.1", ArticleText = "The OWNER has the right to submit an invoice for amounts specified in paragraph 2.1 beginning upon the signature of this CONTRACT." },
                    new ContractTnCArticle { Item = "4.2", ArticleText = "The RENTER shall pay the full amount of OWNER’s invoice within thirty (30) days of its reciept to a bank account given by the OWNER." }
                }
            };
            var tnA5 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 5 - GUARANTEE",
                Articles = new List<ContractTnCArticle>
                {
                    new ContractTnCArticle { Item = "5.1", ArticleText = "The RENTER shall, if requested by the OWNER and before collection of the EQUIPMENT, issue an irrevocable confirmed bank letter of credit or parent company guarantee in OWNER’s format in an amount determined by OWNER and with a guarantor or bank approved by the OWNER. The RENTER may also choose to make a deposit to OWNER for the determined amount." }
                }
            };
            var tnA6 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 6 – LIABILITY AND INDEMNITY",
                Articles = new List<ContractTnCArticle>
                {
                    new ContractTnCArticle { Item = "6.1", ArticleText = "The RENTER shall indemnify, defend and  hold harmless OWNER from and against all claims, demands, actions and costs, including legal fees howsoever arising as a result of this CONTRACT including, but not limited to:\r\n \r\n a) loss of the EQUIPMENT; \r\n \r\n b) damage to the EQUIPMENT during the rental period and which in OWNER’s opinion represents a loss in the value of the EQUIPMENT beyond normal wear and tear; \r\n \r\n c) damage to OWNER’s, RENTER’s or third parties’ assets during or resulting from collection, removal and transportation of the EQUIPMENT; \r\n \r\n d) injury or death of OWNER’s, RENTER’s or third parties’ employees, servants and agents howsoever arising from this CONTRACT; \r\n \r\n e) all fines, duties or other costs resulting from RENTER’s failure to abide with laws and rules as set out in Article 7." },
                    new ContractTnCArticle { Item = "6.2", ArticleText = "The RENTER shall maintain sufficient insurance to cover its liabilities under this CONTRACT and shall provide OWNER proof of such coverage upon OWNER’s request." }
                }
            };
            var tnA7 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 7 - COMPLIANCE WITH LAW",
                Articles = new List<ContractTnCArticle>
                {
                    new ContractTnCArticle{Item = "7.1", ArticleText = "The RENTER shall abide with all applicable laws and regulations in connection with this CONTRACT."}
                }
            };
            var tnA8 = new ContractTermsAndCondition
            {
                ArticleNoText = "ARTICLE 8 – GOVERNING LAW AND DISPUTES",
                Articles = new List<ContractTnCArticle>
                {
                    new ContractTnCArticle{Item = "8.1", ArticleText = "This CONTRACT shall be governed by and interpreted in accordance with Norwegian law. Disputes arising in connection with or as a result of this CONTRACT, and which are not resolved by mutual agreement, shall be settled by court proceedings. \r\n This CONTRACT is produced in two copies, one for each party to this CONTRACT."}
                }
            };

            var signatures = new List<ContractSignature>
            {
                new ContractSignature {SignType = ContractWizardTypes.Owner, NamePosition = "Contractor"},
                new ContractSignature {SignType = ContractWizardTypes.Renter, NamePosition = "Renter"}
            };

            var wizardViewModel = new ContractWizardViewModel
            {
                ContractTitle = "Bom contract pdf wizard",
                ContractNumber = "01-Nov-2018-0001",
                // HeaderAddress = "A/S NORSKE SHELL\r\nE&P, OPERATIONS\r\nP.O.BOX 2244\r\nN - 6501 KRISTIANSUND N",
                ContractAddresses = new List<ContractAddressViewModel> { add1, add2 },
                Parts = new List<ContractPart> { part1, part2, part3, part4, part5, part6, part7, part8, part9,
                    part10, //part11, part12, part13, part14, part15,
                    part16 },
                SpecificTerms = new List<ContractSpecificTerm> { term1, term2, term3, term4, term5, term6, term7, term8, term9, term10 },
                CollectionAddress = "A/S Norske Shell, Omagt. 122, Bygning 26, 6517 KRISTIANSUND.",
                RentalPeriodStartDate = "01-Jan-2018",
                RentalPeriodEndDate = "31-Dec-2018",
                TermsAndConditions = new List<ContractTermsAndCondition> { tnA1, tnA2, tnA3, tnA4, tnA5, tnA6, tnA7, tnA8 },
                ContractSignatures = signatures,
                MaintenanceBeforePeriod = "Mobilization maintenance",
                MaintenanceByOem = "No",
                MaintenanceAfterPeriod = "Demobilization maintenance"
            };

            return wizardViewModel;
        }

        /// <summary>
        /// Generate contract wizard pdf
        /// </summary>
        public static byte[] GeneratePdf(IHostingEnvironment hostingEnvironment, ContractWizardViewModel viewModel, ContractHeaderContent headerContent, List<FileDetails> logoList)
        {
            var pageSize = new Rectangle(PageSize.A4);
            pageSize.BackgroundColor = new BaseColor(252, 253, 254);
            var pdfDoc = new Document(pageSize, 25f, 25f, 80f, 40f);

            using (var memoryStream = new MemoryStream())
            {
                var writer = PdfWriter.GetInstance(pdfDoc, memoryStream);
                writer.PageEvent = new TextEvents(headerContent);
                pdfDoc.Open();

                var contractWizard = new ContractWizardPdfBody(hostingEnvironment, viewModel, logoList);
                var bodytable = contractWizard.PdfBodyTable();
                pdfDoc.Add(bodytable);

                pdfDoc.Close();

                byte[] bytes = memoryStream.ToArray();
                memoryStream.Close();

                // For saving file
                //var testFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "test.pdf");
                //System.IO.File.WriteAllBytes(testFile, bytes);

                // For sending in email
                return bytes;

            }
        }
    }
}
