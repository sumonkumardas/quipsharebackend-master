﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Hosting;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using SubQuip.ViewModel.ContractWizard;
using System.Text;

namespace SubQuip.WebApi.PdfHelper.ContractWizard
{
    /// <summary>
    /// Contract wizard pdf body
    /// </summary>
    public class ContractWizardPdfBody
    {
        private readonly ContractWizardViewModel _contractWizard;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly List<FileDetails> _logoList;

        private readonly BaseColor _colorBody = new BaseColor(252, 253, 254);

        private readonly BaseColor _colorTableBorder = new BaseColor(175, 190, 196);
        private readonly BaseColor _colorFont = new BaseColor(100, 101, 101);

        readonly Font _baseItalicFont;

        readonly Font _baseLableFontSmallBold;
        readonly Font _baseLableFontSmallNormal;

        readonly Font _baseLableFontMediumBold;
        readonly Font _baseLableFontMediumNormal;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="hostingEnvironment"></param>
        /// <param name="contractWizard"></param>
        public ContractWizardPdfBody(IHostingEnvironment hostingEnvironment, ContractWizardViewModel contractWizard, List<FileDetails> logoList)
        {
            _contractWizard = contractWizard;
            _logoList = logoList;
            _hostingEnvironment = hostingEnvironment;

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var enc1252 = Encoding.GetEncoding(1252);

            var fontPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Fonts/montserrat-light.ttf");
            var customfont = BaseFont.CreateFont(fontPath, BaseFont.WINANSI, BaseFont.EMBEDDED);

            _baseItalicFont = new Font(customfont, 6f, Font.ITALIC, _colorFont);

            _baseLableFontSmallBold = new Font(customfont, 8f, Font.BOLD, _colorFont);
            _baseLableFontSmallNormal = new Font(customfont, 8f, Font.NORMAL, _colorFont);

            _baseLableFontMediumBold = new Font(customfont, 9f, Font.BOLD, _colorFont);
            _baseLableFontMediumNormal = new Font(customfont, 9f, Font.NORMAL, _colorFont);

        }

        /// <summary>
        /// Create default settings for main table cell
        /// </summary>
        /// <returns></returns>
        private PdfPCell PdfMainTableCell()
        {
            var pdfPCell = new PdfPCell
            {
                Border = Rectangle.NO_BORDER,
                HorizontalAlignment = Element.ALIGN_LEFT,
                VerticalAlignment = Element.ALIGN_TOP,
                Padding = 0
            };
            return pdfPCell;
        }

        /// <summary>
        /// Label Chunk
        /// </summary>
        /// <param name="str"></param>
        /// <param name="font"></param>
        /// <returns></returns>
        private Chunk LabelChunk(string str, Font font = null)
        {
            var text = str;
            if (font == null)
                return new Chunk(text, _baseLableFontSmallBold);
            return new Chunk(text, font);
        }

        /// <summary>
        /// Text Chunk
        /// </summary>
        /// <param name="str"></param>
        /// <param name="font"></param>
        /// <returns></returns>
        private Chunk TextChunk(string str, Font font = null)
        {
            var text = str;
            if (font == null)
                return new Chunk(text, _baseLableFontSmallNormal);
            return new Chunk(text, font);
        }

        /// <summary>
        /// Create pdf body main table
        /// </summary>
        /// <returns></returns>
        public PdfPTable PdfBodyTable()
        {
            var pdfTable = new PdfPTable(5);
            float[] widths = { 1, 1, 5, 2, 2 };  //cell Widths
            pdfTable.SetWidths(widths);  //Set the pdf cell witdth
            pdfTable.WidthPercentage = 100;
            pdfTable.HorizontalAlignment = 0;
            pdfTable.SpacingAfter = 0f;
            pdfTable.SpacingBefore = 0f;

            #region Contract details table

            var contractDetailMainCell = PdfMainTableCell();
            contractDetailMainCell.Colspan = 5;
            contractDetailMainCell.AddElement(ContractDetailsTable());
            pdfTable.AddCell(contractDetailMainCell);

            #endregion

            #region Empty rows

            var emptyPhrase = new Phrase(" ");
            var emptyPhraseCell = PdfMainTableCell();
            emptyPhraseCell.Colspan = 5;
            emptyPhraseCell.Phrase = emptyPhrase;
            emptyPhraseCell.Padding = 6f;
            pdfTable.AddCell(emptyPhraseCell);

            #endregion

            #region Contract addresses

            var contractAddressMainCell = PdfMainTableCell();
            contractAddressMainCell.Colspan = 5;
            contractAddressMainCell.AddElement(ContractAddressesTables());
            pdfTable.AddCell(contractAddressMainCell);

            #endregion

            #region Empty rows

            pdfTable.AddCell(emptyPhraseCell);

            #endregion

            #region Equipment List

            // var equipmentListCell = PdfMainTableCell();
            // equipmentListCell.AddElement(EquipmentList());
            // pdfTable.AddCell(equipmentListCell);

            EquipmentList(ref pdfTable);

            #endregion

            #region Empty rows

            pdfTable.AddCell(emptyPhraseCell);

            #endregion

            #region Specific term text

            // Row 1
            var speclblPhrase = new Phrase { LabelChunk("SPECIFIC TERMS", _baseLableFontMediumBold) };
            var speclblCell = new PdfPCell(speclblPhrase) { Colspan = 5, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(speclblCell);

            // Row 2
            var speclbl2Phrase = new Phrase { LabelChunk("(in addition to the terms and conditions following the signatures to this Contract)", _baseLableFontMediumNormal) };
            var speclbl2Cell = new PdfPCell(speclbl2Phrase) { Colspan = 5, PaddingBottom = 15f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(speclbl2Cell);

            // Row 3
            var dropdownCell = new PdfPCell { Colspan = 5, PaddingBottom = 15f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER };
            dropdownCell.AddElement(SpecificTermDropValues());
            pdfTable.AddCell(dropdownCell);

            #endregion

            #region Specific term list

            //var specificTermListCell = PdfMainTableCell();
            //specificTermListCell.AddElement(SpecificTermTable());
            //pdfTable.AddCell(specificTermListCell);
            SpecificTermTable(ref pdfTable);

            #endregion

            #region Empty rows

            pdfTable.AddCell(emptyPhraseCell);

            #endregion

            #region Collection Address row

            var collectionAddressCell = PdfMainTableCell();
            collectionAddressCell.Colspan = 5;
            collectionAddressCell.AddElement(CollectionAddress());
            pdfTable.AddCell(collectionAddressCell);

            #endregion

            #region Empty rows

            pdfTable.AddCell(emptyPhraseCell);

            #endregion

            #region Signature Boxes

            var signatureMainCell = PdfMainTableCell();
            signatureMainCell.Colspan = 5;
            signatureMainCell.AddElement(SignatureBoxesTable());
            pdfTable.AddCell(signatureMainCell);

            #endregion

            #region Empty rows

            pdfTable.AddCell(emptyPhraseCell);

            #endregion

            #region Terms and condition

            //var termsCell = PdfMainTableCell();
            //termsCell.AddElement(TermsAndCondition());
            //pdfTable.AddCell(termsCell);

            TermsAndCondition(ref pdfTable);

            #endregion

            return pdfTable;
        }

        /// <summary>
        /// Contract details
        /// </summary>
        /// <returns></returns>
        private PdfPTable ContractDetailsTable()
        {
            var pdfTable = new PdfPTable(2)
            {
                WidthPercentage = 50,
                HorizontalAlignment = 0,
                SpacingAfter = 0,
                SpacingBefore = 0
            };
            float[] widths = { 1, 1 };  //cell Widths
            pdfTable.SetWidths(widths);

            // Row 1
            //var oneImage = NumberImage(1);
            //var contractItemNoCell = new PdfPCell(oneImage, true) { Colspan = 2, FixedHeight = 20f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            //pdfTable.AddCell(contractItemNoCell);

            // Row 2
            var contractTitlePhrase = new Phrase { LabelChunk("CONTRACT TITLE") };
            var contractTitleCell = new PdfPCell(contractTitlePhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(contractTitleCell);

            var contractNoPhrase = new Phrase { LabelChunk("CONTRACT NO.") };
            var contractNoCell = new PdfPCell(contractNoPhrase) { PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody };
            pdfTable.AddCell(contractNoCell);

            // Row 3
            var contractTitleValuePhrase = new Phrase { TextChunk(_contractWizard.ContractTitle) };
            var contractTitleValueCell = new PdfPCell(contractTitleValuePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(contractTitleValueCell);

            var contractNoValuePhrase = new Phrase { TextChunk(_contractWizard.ContractNumber) };
            var contractNoValueCell = new PdfPCell(contractNoValuePhrase) { PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(contractNoValueCell);

            return pdfTable;
        }

        /// <summary>
        /// Contract address tables
        /// </summary>
        /// <returns></returns>
        private PdfPTable ContractAddressesTables()
        {
            var pdfTable = new PdfPTable(3)
            {
                WidthPercentage = 100,
                HorizontalAlignment = 0,
                SpacingAfter = 0,
                SpacingBefore = 0
            };
            float[] widths = { 48f, 4f, 48f };  //cell Widths
            pdfTable.SetWidths(widths);

            var fileOwner = _logoList.FirstOrDefault(t => t.FileKeyName.ToLower().Contains(ContractWizardTypes.Owner.ToString().ToLower()));
            var ownerAddress = _contractWizard.ContractAddresses.FirstOrDefault(t => t.AddressType == ContractWizardTypes.Owner);
            var addressCell1 = new PdfPCell { Padding = 0, Border = Rectangle.NO_BORDER, VerticalAlignment = Element.ALIGN_TOP, HorizontalAlignment = Element.ALIGN_LEFT };
            addressCell1.AddElement(AddressTable(ownerAddress, 2, fileOwner));
            pdfTable.AddCell(addressCell1);

            var emptyPhrase = new Phrase(" ");
            var emptyPhraseCell = new PdfPCell(emptyPhrase) { Padding = 0, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(emptyPhraseCell);

            var fileRenter = _logoList.FirstOrDefault(t => t.FileKeyName.ToLower().Contains(ContractWizardTypes.Renter.ToString().ToLower()));
            var renterAddress = _contractWizard.ContractAddresses.FirstOrDefault(t => t.AddressType == ContractWizardTypes.Renter);
            var addressCell2 = new PdfPCell { Padding = 0, Border = Rectangle.NO_BORDER, VerticalAlignment = Element.ALIGN_TOP, HorizontalAlignment = Element.ALIGN_LEFT };
            addressCell2.AddElement(AddressTable(renterAddress, 3, fileRenter));
            pdfTable.AddCell(addressCell2);

            return pdfTable;
        }

        /// <summary>
        /// Address table
        /// </summary>
        /// <param name="contractAddress"></param>
        /// <param name="count"></param>
        /// <param name="logoFile"></param>
        /// <returns></returns>
        private PdfPTable AddressTable(ContractAddressViewModel contractAddress, int count, FileDetails logoFile)
        {
            var pdfTable = new PdfPTable(2)
            {
                WidthPercentage = 100,
                HorizontalAlignment = 0,
                SpacingAfter = 0,
                SpacingBefore = 0
            };
            float[] widths = { 1, 1 };  //cell Widths
            pdfTable.SetWidths(widths);

            // Row 1
            //var oneImage = NumberImage(count);
            //var contractItemNoCell = new PdfPCell(oneImage, true) { Colspan = 2, FixedHeight = 20f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            //pdfTable.AddCell(contractItemNoCell);


            // Row 2
            var companyNamePhrase = new Phrase { LabelChunk(contractAddress.AddressType.ToString()) };
            var companyNameCell = new PdfPCell(companyNamePhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(companyNameCell);

            // Row 2-Rowspan 
            if (logoFile != null)
            {
                byte[] imageBytes = Convert.FromBase64String(logoFile.Content);
                iTextSharp.text.Image logoImage = iTextSharp.text.Image.GetInstance(imageBytes);
                logoImage.ScaleToFit(35f, 35f);
                var logoCell = new PdfPCell(logoImage, true)
                {
                    FixedHeight = 35f,
                    Rowspan = 4,
                    Padding = 2f,
                    HorizontalAlignment = Element.ALIGN_RIGHT,
                    VerticalAlignment = Element.ALIGN_TOP,
                    Border = Rectangle.NO_BORDER
                };
                pdfTable.AddCell(logoCell);
            }

            // Row 3
            var companyNameValuePhrase = new Phrase { TextChunk(contractAddress.CompanyName) };
            var companyNameValueCell = new PdfPCell(companyNameValuePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(companyNameValueCell);

            // Row 4
            var addressTypePhrase = new Phrase { LabelChunk("(hereafter referred to as " + contractAddress.AddressType.ToString().ToUpper() + ")", _baseItalicFont) };
            var addressTypeCell = new PdfPCell(addressTypePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(addressTypeCell);

            // Row 5
            var emptyPhrase = new Phrase(" ");
            var emptyPhraseCell = new PdfPCell(emptyPhrase) { Padding = 2f, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(emptyPhraseCell);

            // row 6
            var representativelblPhrase = new Phrase { LabelChunk("REPRESENTATIVES", _baseLableFontMediumBold) };
            var representativelblCell = new PdfPCell(representativelblPhrase) { Colspan = 2, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(representativelblCell);

            // Row 7
            var techLblPhrase = new Phrase { LabelChunk("Technical") };
            var techLblCell = new PdfPCell(techLblPhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(techLblCell);

            var commLblPhrase = new Phrase { LabelChunk("Commercial") };
            var commLblCell = new PdfPCell(commLblPhrase) { PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody };
            pdfTable.AddCell(commLblCell);

            // Row 8
            var techValuePhrase = new Phrase { TextChunk(contractAddress.Technical) };
            var techValueCell = new PdfPCell(techValuePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(techValueCell);

            var commValuePhrase = new Phrase { TextChunk(contractAddress.Commercial) };
            var commValueCell = new PdfPCell(commValuePhrase) { PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(commValueCell);

            // row 9
            var addLblPhrase = new Phrase { LabelChunk("Address") };
            var addLblCell = new PdfPCell(addLblPhrase) { Colspan = 2, PaddingTop = 5f, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(addLblCell);

            // row 10
            var addValuePhrase = new Phrase { TextChunk(contractAddress.Address) };
            var addValueCell = new PdfPCell(addValuePhrase) { Colspan = 2, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(addValueCell);

            // row 11
            var teleLblPhrase = new Phrase { LabelChunk("Telephone") };
            var teleLblCell = new PdfPCell(teleLblPhrase) { PaddingTop = 5f, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(teleLblCell);

            var emailLblPhrase = new Phrase { LabelChunk("E-mail") };
            var emailLblCell = new PdfPCell(emailLblPhrase) { PaddingTop = 5f, PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody };
            pdfTable.AddCell(emailLblCell);


            // Row 12
            var teleValuePhrase = new Phrase { TextChunk(contractAddress.Telephone) };
            var teleValueCell = new PdfPCell(teleValuePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(teleValueCell);

            var emailValuePhrase = new Phrase { TextChunk(contractAddress.Email) };
            var emailValueCell = new PdfPCell(emailValuePhrase) { PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(emailValueCell);

            return pdfTable;
        }

        /// <summary>
        /// Equipment list table
        /// </summary>
        /// <returns></returns>
        private PdfPTable EquipmentList(ref PdfPTable pdfTable)
        {
            //var pdfTable = new PdfPTable(5)
            //{
            //    WidthPercentage = 100,
            //    HorizontalAlignment = 0,
            //    SpacingAfter = 0,
            //    SpacingBefore = 0
            //};
            //float[] widths = { 1, 1, 5, 2, 2 };  //cell Widths
            //pdfTable.SetWidths(widths);

            // Row 1
            //var oneImage = NumberImage(4);
            //var contractItemNoCell = new PdfPCell(oneImage, true) { Colspan = 5, FixedHeight = 20f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            //pdfTable.AddCell(contractItemNoCell);

            // Row 2
            var desclblPhrase = new Phrase { LabelChunk("DESCRIPTION OF ”EQUIPMENT”", _baseLableFontMediumBold) };
            var desclblCell = new PdfPCell(desclblPhrase) { Colspan = 5, PaddingBottom = 15f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(desclblCell);

            // row 3
            var headerPhrase1 = new Phrase { LabelChunk("ITEM") };
            var headerCell1 = new PdfPCell(headerPhrase1) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
            pdfTable.AddCell(headerCell1);
            var headerPhrase2 = new Phrase { LabelChunk("SubQuip No") };
            var headerCell2 = new PdfPCell(headerPhrase2) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
            pdfTable.AddCell(headerCell2);
            var headerPhrase3 = new Phrase { LabelChunk("DESCRIPTION (TYPE/ PART NO./ MANUFACTURER, ETC.)") };
            var headerCell3 = new PdfPCell(headerPhrase3) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
            pdfTable.AddCell(headerCell3);
            var headerPhrase4 = new Phrase { LabelChunk("SubQuip Rate(NOK)") };
            var headerCell4 = new PdfPCell(headerPhrase4) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
            pdfTable.AddCell(headerCell4);
            var headerPhrase5 = new Phrase { LabelChunk("RENTAL RATE/ DAY(NOK)") };
            var headerCell5 = new PdfPCell(headerPhrase5) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
            pdfTable.AddCell(headerCell5);

            foreach (var part in _contractWizard.Parts)
            {
                var dataPhrase1 = new Phrase { TextChunk(part.Item) };
                var dataCell1 = new PdfPCell(dataPhrase1) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
                pdfTable.AddCell(dataCell1);
                var dataPhrase2 = new Phrase { TextChunk(part.SubQuipNo) };
                var dataCell2 = new PdfPCell(dataPhrase2) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
                pdfTable.AddCell(dataCell2);
                var dataPhrase3 = new Phrase { TextChunk(part.Description) };
                var dataCell3 = new PdfPCell(dataPhrase3) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
                pdfTable.AddCell(dataCell3);
                var dataPhrase4 = new Phrase { TextChunk(part.SubQuipRate) };
                var dataCell4 = new PdfPCell(dataPhrase4) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
                pdfTable.AddCell(dataCell4);
                var dataPhrase5 = new Phrase { TextChunk(part.RentalPerDay) };
                var dataCell5 = new PdfPCell(dataPhrase5) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
                pdfTable.AddCell(dataCell5);
            }
            return pdfTable;
        }

        /// <summary>
        /// Specific Terms table list
        /// </summary>
        /// <returns></returns>
        private PdfPTable SpecificTermTable(ref PdfPTable pdfTable)
        {
            //var pdfTable = new PdfPTable(2)
            //{
            //    WidthPercentage = 80,
            //    HorizontalAlignment = 0,
            //    SpacingAfter = 0,
            //    SpacingBefore = 0
            //};
            //float[] widths = { 1, 9 };  //cell Widths
            //pdfTable.SetWidths(widths);

            foreach (var specificTerms in _contractWizard.SpecificTerms)
            {
                var labelPhrase1 = new Phrase { LabelChunk(specificTerms.Item) };
                var labelCell1 = new PdfPCell(labelPhrase1) { PaddingLeft = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
                pdfTable.AddCell(labelCell1);
                var dataPhrase1 = new Phrase { TextChunk(specificTerms.Term) };
                var dataCell1 = new PdfPCell(dataPhrase1) { Colspan = 4, PaddingLeft = 5f, PaddingBottom = 10f, PaddingTop = 10f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.BOX, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
                pdfTable.AddCell(dataCell1);
            }

            return pdfTable;
        }

        /// <summary>
        /// Specific term drop down values
        /// </summary>
        /// <returns></returns>
        private PdfPTable SpecificTermDropValues()
        {
            var pdfTable = new PdfPTable(3)
            {
                WidthPercentage = 100,
                HorizontalAlignment = 0,
                SpacingAfter = 0,
                SpacingBefore = 0
            };
            float[] widths = { 48f, 4f, 48f };  //cell Widths
            pdfTable.SetWidths(widths);

            // Row 1
            var maintenBeforelblPhrase = new Phrase { LabelChunk("Maintenance before rental period") };
            var maintenBeforeLblCell = new PdfPCell(maintenBeforelblPhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(maintenBeforeLblCell);

            var emptyPhrase = new Phrase(" ");
            var emptyPhraseCell = new PdfPCell(emptyPhrase) { Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(emptyPhraseCell);

            var oemLblPhrase = new Phrase { LabelChunk("Should maintenance be performed by OEM?") };
            var oemLblCell = new PdfPCell(oemLblPhrase) { PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody };
            pdfTable.AddCell(oemLblCell);

            // Row 2
            var maintenBeforeValuePhrase = new Phrase { TextChunk(_contractWizard.MaintenanceBeforePeriod) };
            var maintenBeforeValueCell = new PdfPCell(maintenBeforeValuePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(maintenBeforeValueCell);

            pdfTable.AddCell(emptyPhraseCell);

            var oemValuePhrase = new Phrase { TextChunk(_contractWizard.MaintenanceByOem) };
            var oemValueCell = new PdfPCell(oemValuePhrase) { PaddingLeft = 8f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.LEFT_BORDER, BorderWidth = 10f, BorderColor = _colorBody, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(oemValueCell);

            // Row 3
            var maintenAfterlblPhrase = new Phrase { LabelChunk("Maintenance after rental period") };
            var maintenAfterLblCell = new PdfPCell(maintenAfterlblPhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(maintenAfterLblCell);

            var emptyPhraseCell1 = new PdfPCell(emptyPhrase) { Colspan = 2, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(emptyPhraseCell1);


            // Row 4
            var maintenAfterValuePhrase = new Phrase { TextChunk(_contractWizard.MaintenanceAfterPeriod) };
            var maintenAfterValueCell = new PdfPCell(maintenAfterValuePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(maintenAfterValueCell);

            pdfTable.AddCell(emptyPhraseCell1);

            return pdfTable;
        }

        /// <summary>
        /// Collection address and rental row
        /// </summary>
        /// <returns></returns>
        private PdfPTable CollectionAddress()
        {
            var pdfTable = new PdfPTable(3)
            {
                WidthPercentage = 100,
                HorizontalAlignment = 0,
                SpacingAfter = 0,
                SpacingBefore = 0
            };
            float[] widths = { 48f, 4f, 48f };  //cell Widths
            pdfTable.SetWidths(widths);

            // Row 1
            //var oneImage = NumberImage(5);
            //var oneCell = new PdfPCell(oneImage, true) { FixedHeight = 20f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            //pdfTable.AddCell(oneCell);

            var emptyPhrase = new Phrase(" ");
            var emptyPhraseCell = new PdfPCell(emptyPhrase) { Border = Rectangle.NO_BORDER };
            // pdfTable.AddCell(emptyPhraseCell);

            //var twoImage = NumberImage(6);
            //var twoCell = new PdfPCell(twoImage, true) { FixedHeight = 20f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            //pdfTable.AddCell(twoCell);

            // Row 2
            var collAddNamePhrase = new Phrase { LabelChunk("COLLECTION ADDRESS") };
            var collAddNameCell = new PdfPCell(collAddNamePhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(collAddNameCell);

            pdfTable.AddCell(emptyPhraseCell);

            var rentPrdLblPhrase = new Phrase { LabelChunk("RENTAL PERIOD") };
            var rentPrdLblCell = new PdfPCell(rentPrdLblPhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(rentPrdLblCell);

            // row 3
            var addLblPhrase = new Phrase { LabelChunk("Address") };
            var addLblCell = new PdfPCell(addLblPhrase) { PaddingTop = 5f, VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(addLblCell);

            pdfTable.AddCell(emptyPhraseCell);
            pdfTable.AddCell(emptyPhraseCell);

            // Row 4
            var collAddValuePhrase = new Phrase { TextChunk(_contractWizard.CollectionAddress) };
            var collAddValueCell = new PdfPCell(collAddValuePhrase) { VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(collAddValueCell);

            pdfTable.AddCell(emptyPhraseCell);

            var rentalPrdValuePhrase = new Phrase
            {
                 TextChunk(_contractWizard.RentalPeriodStartDate), LabelChunk("  to "), TextChunk(_contractWizard.RentalPeriodEndDate)
            };
            var rentalPrdValueCell = new PdfPCell(rentalPrdValuePhrase) { VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER, BackgroundColor = BaseColor.WHITE };
            pdfTable.AddCell(rentalPrdValueCell);

            return pdfTable;
        }

        /// <summary>
        /// Signature Boxes
        /// </summary>
        /// <returns></returns>
        private PdfPTable SignatureBoxesTable()
        {
            var pdfTable = new PdfPTable(3)
            {
                WidthPercentage = 100,
                HorizontalAlignment = 0,
                SpacingAfter = 0,
                SpacingBefore = 0
            };
            float[] widths = { 48f, 4f, 48f };  //cell Widths
            pdfTable.SetWidths(widths);

            var ownerSign = _contractWizard.ContractSignatures.FirstOrDefault(t => t.SignType == ContractWizardTypes.Owner);
            var signBoxCell1 = new PdfPCell { Padding = 0, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER, HorizontalAlignment = Element.ALIGN_LEFT };
            signBoxCell1.AddElement(SignatureBoxTable(ownerSign, 7));
            pdfTable.AddCell(signBoxCell1);

            var emptyPhrase = new Phrase(" ");
            var emptyPhraseCell = new PdfPCell(emptyPhrase) { Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(emptyPhraseCell);

            var renterSign = _contractWizard.ContractSignatures.FirstOrDefault(t => t.SignType == ContractWizardTypes.Renter);
            var signBoxCell2 = new PdfPCell { Padding = 0, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER, HorizontalAlignment = Element.ALIGN_LEFT };
            signBoxCell2.AddElement(SignatureBoxTable(renterSign, 8));
            pdfTable.AddCell(signBoxCell2);

            return pdfTable;
        }

        /// <summary>
        /// Signature box
        /// </summary>
        /// <param name="contractSignature"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        private PdfPTable SignatureBoxTable(ContractSignature contractSignature, int count)
        {
            var pdfTable = new PdfPTable(1)
            {
                WidthPercentage = 100,
                HorizontalAlignment = 0,
                SpacingAfter = 0,
                SpacingBefore = 0
            };
            float[] widths = { 1 };  //cell Widths
            pdfTable.SetWidths(widths);

            // Row 1
            //var oneImage = NumberImage(count);
            //var contractItemNoCell = new PdfPCell(oneImage, true) { Colspan = 2, FixedHeight = 20f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER };
            //pdfTable.AddCell(contractItemNoCell);

            // Row 2
            var signForPhrase = new Phrase { LabelChunk("FOR " + contractSignature.SignType.ToString().ToUpper()) };
            var signForCell = new PdfPCell(signForPhrase) { VerticalAlignment = Element.ALIGN_BOTTOM, Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(signForCell);

            // Row 3
            var emptyPhrase = new Phrase(" ");
            var emptylineCell = new PdfPCell(emptyPhrase) { Border = Rectangle.BOTTOM_BORDER, BorderColor = _colorTableBorder };
            pdfTable.AddCell(emptylineCell);

            // row 4
            var signLblPhrase = new Phrase { LabelChunk("Signature") };
            var representativelblCell = new PdfPCell(signLblPhrase) { VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER, HorizontalAlignment = Element.ALIGN_LEFT };
            pdfTable.AddCell(representativelblCell);

            // row 5
            var emptyCell = new PdfPCell(emptyPhrase) { Border = Rectangle.NO_BORDER };
            pdfTable.AddCell(emptyCell);

            // Row 6
            var nameTextPhrase = new Phrase { TextChunk(contractSignature.NamePosition) };
            var nameTextCell = new PdfPCell(nameTextPhrase) { Border = Rectangle.BOTTOM_BORDER, VerticalAlignment = Element.ALIGN_MIDDLE, BorderColor = _colorTableBorder };
            pdfTable.AddCell(nameTextCell);

            // row 7
            var nameLblPhrase = new Phrase { LabelChunk("Name & Position(capital letters)") };
            var nameLbllblCell = new PdfPCell(nameLblPhrase) { VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER, HorizontalAlignment = Element.ALIGN_LEFT };
            pdfTable.AddCell(nameLbllblCell);

            // row 8
            pdfTable.AddCell(emptyCell);

            // Row 9
            pdfTable.AddCell(emptylineCell);

            // row 10
            var placeDatePhrase = new Phrase { LabelChunk("Place & Date(capital letters)") };
            var placeDatelblCell = new PdfPCell(placeDatePhrase) { VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.NO_BORDER, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
            pdfTable.AddCell(placeDatelblCell);

            return pdfTable;
        }

        /// <summary>
        /// Terms and condition
        /// </summary>
        /// <returns></returns>
        private PdfPTable TermsAndCondition(ref PdfPTable pdfTable)
        {
            //var pdfTable = new PdfPTable(2)
            //{
            //    WidthPercentage = 80,
            //    HorizontalAlignment = 0,
            //    SpacingAfter = 0,
            //    SpacingBefore = 0
            //};
            //float[] widths = { 1, 9 };  //cell Widths
            //pdfTable.SetWidths(widths);

            // Row 1
            var articleHeadingPhrase = new Phrase { LabelChunk("OWNER and RENTER further agree to the following :", _baseLableFontMediumBold) };
            var articleHeadingCell = new PdfPCell(articleHeadingPhrase) { Colspan = 5, PaddingBottom = 5f, PaddingTop = 5f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.NO_BORDER, HorizontalAlignment = Element.ALIGN_LEFT };
            pdfTable.AddCell(articleHeadingCell);

            foreach (var termsAndCondition in _contractWizard.TermsAndConditions)
            {
                // Row 2 with article tex
                var emptyPhrase = new Phrase(" ");
                var emptylineCell = new PdfPCell(emptyPhrase) { Border = Rectangle.LEFT_BORDER | Rectangle.TOP_BORDER | Rectangle.RIGHT_BORDER, BorderColor = _colorTableBorder };
                pdfTable.AddCell(emptylineCell);

                var articleNoPhrase = new Phrase { LabelChunk(termsAndCondition.ArticleNoText, _baseLableFontSmallBold) };
                var articleNoCell1 = new PdfPCell(articleNoPhrase) { Colspan = 4, PaddingLeft = 5f, PaddingBottom = 10f, PaddingTop = 10f, VerticalAlignment = Element.ALIGN_MIDDLE, Border = Rectangle.TOP_BORDER | Rectangle.RIGHT_BORDER, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
                pdfTable.AddCell(articleNoCell1);

                // Row 4
                foreach (var contractTnAArticls in termsAndCondition.Articles)
                {
                    var labelPhrase1 = new Phrase { LabelChunk(contractTnAArticls.Item, _baseLableFontSmallBold) };
                    var labelCell1 = new PdfPCell(labelPhrase1) { PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.LEFT_BORDER | Rectangle.RIGHT_BORDER, HorizontalAlignment = Element.ALIGN_CENTER, BorderColor = _colorTableBorder };
                    pdfTable.AddCell(labelCell1);
                    var dataPhrase1 = new Phrase { TextChunk(contractTnAArticls.ArticleText, _baseLableFontSmallNormal) };
                    var dataCell1 = new PdfPCell(dataPhrase1) { Colspan = 4, PaddingLeft = 5f, PaddingBottom = 5f, VerticalAlignment = Element.ALIGN_TOP, Border = Rectangle.RIGHT_BORDER, HorizontalAlignment = Element.ALIGN_LEFT, BorderColor = _colorTableBorder };
                    pdfTable.AddCell(dataCell1);
                }

                // Row 4
                var emptyCell1 = new PdfPCell(emptyPhrase) { Border = Rectangle.LEFT_BORDER | Rectangle.BOTTOM_BORDER | Rectangle.RIGHT_BORDER, BorderColor = _colorTableBorder };
                pdfTable.AddCell(emptyCell1);
                var emptyCell2 = new PdfPCell(emptyPhrase) { Colspan = 4, Border = Rectangle.BOTTOM_BORDER | Rectangle.RIGHT_BORDER, BorderColor = _colorTableBorder };
                pdfTable.AddCell(emptyCell2);
            }
            return pdfTable;
        }

        /// <summary>
        /// Get the number image
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        private Image NumberImage(int number)
        {
            var path = Path.Combine(_hostingEnvironment.ContentRootPath, "Images");
            switch (number)
            {
                case 1:
                    path += "\\one.png";
                    break;
                case 2:
                    path += "\\two.png";
                    break;
                case 3:
                    path += "\\three.png";
                    break;
                case 4:
                    path += "\\four.png";
                    break;
                case 5:
                    path += "\\five.png";
                    break;
                case 6:
                    path += "\\six.png";
                    break;
                case 7:
                    path += "\\seven.png";
                    break;
                case 8:
                    path += "\\eight.png";
                    break;
            }

            var image = iTextSharp.text.Image.GetInstance(path);
            image.ScaleToFit(20f, 20f);
            return image;
        }
    }
}
