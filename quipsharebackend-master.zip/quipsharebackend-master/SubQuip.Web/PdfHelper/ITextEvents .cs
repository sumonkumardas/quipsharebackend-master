﻿using System;
using System.Drawing.Imaging;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Http;
using SubQuip.Common.Extensions;
using SubQuip.ViewModel.ContractWizard;
using System.Text;

namespace SubQuip.WebApi.PdfHelper
{
    /// <summary>
    /// Pdf page event helper
    /// </summary>
    public class TextEvents : PdfPageEventHelper
    {
        private ContractHeaderContent _headerContent;

        private BaseFont _baseFont;

        public TextEvents(ContractHeaderContent headerContent)
        {
            _headerContent = headerContent;
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var enc1252 = Encoding.GetEncoding(1252);
            _baseFont = BaseFont.CreateFont(headerContent.FontPath, BaseFont.WINANSI, BaseFont.EMBEDDED);
        }

        // This is the contentbyte object of the writer
        private PdfContentByte _cb;

        // we will put the final number of pages in a template
        private PdfTemplate _headerTemplate;
        private PdfTemplate _footerTemplate;

        // this is the BaseFont we are going to use for the header / footer
        BaseFont bf = null;

        // This keeps track of the creation time
        DateTime _printTime = DateTime.Now;

        #region Fields
        private string _header;
        #endregion

        #region Properties
        public string Header
        {
            get { return _header; }
            set { _header = value; }
        }
        #endregion

        public override void OnOpenDocument(PdfWriter writer, Document document)
        {
            try
            {
                _printTime = DateTime.Now;
                bf = _baseFont;// BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                _cb = writer.DirectContent;
                _headerTemplate = _cb.CreateTemplate(100, 100);
                _footerTemplate = _cb.CreateTemplate(50, 50);
            }
            catch (DocumentException de)
            {
            }
            catch (System.IO.IOException ioe)
            {
            }
        }

        public override void OnEndPage(PdfWriter writer, Document document)
        {
            base.OnEndPage(writer, document);
            Font baseFontNormal = new Font(_baseFont, 12f, Font.BOLD, new BaseColor(83, 110, 121));

            //Create PdfTable object left
            PdfPTable pdfTabLeft = new PdfPTable(1)
            {
                TotalWidth = document.PageSize.Width - 350f,
                WidthPercentage = 40,
                HorizontalAlignment = Element.ALIGN_LEFT
            };

            //Row 1 
            iTextSharp.text.Image logoImage = iTextSharp.text.Image.GetInstance(_headerContent.HeaderLogoPath);
            logoImage.ScaleToFit(35f, 35f);
            var pdfLogoCell = new PdfPCell(logoImage, true)
            {
                FixedHeight = 35f,
                PaddingTop = -10f,
                HorizontalAlignment = Element.ALIGN_LEFT,
                VerticalAlignment = Element.ALIGN_TOP,
                Border = Rectangle.NO_BORDER
            };
            pdfTabLeft.AddCell(pdfLogoCell);

            //Row 2
            string titleContent = "RENTAL CONTRACT";
            Phrase pTitle = new Phrase(titleContent, baseFontNormal);
            PdfPCell pdfTextCell = new PdfPCell(pTitle)
            {
                HorizontalAlignment = Element.ALIGN_LEFT,
                VerticalAlignment = Element.ALIGN_TOP,
                Border = Rectangle.NO_BORDER
            };
            pdfTabLeft.AddCell(pdfTextCell);

            //call WriteSelectedRows of PdfTable. This writes rows from PdfWriter in PdfTable
            //first param is start row. -1 indicates there is no end row and all the rows to be included to write
            //Third and fourth param is x and y position to start writing
            pdfTabLeft.WriteSelectedRows(0, -1, 25, document.PageSize.Height - 15, writer.DirectContent);


            //Create PdfTable object Right
            PdfPTable pdfTabRight = new PdfPTable(1)
            {
                TotalWidth = document.PageSize.Width - 350f,
                WidthPercentage = 40,
                HorizontalAlignment = Element.ALIGN_RIGHT
            };

            iTextSharp.text.Image rightHeaderImage = iTextSharp.text.Image.GetInstance(_headerContent.HeaderRightImagePath);
            //rightHeaderImage.ScaleToFit(130, 175);
            //rightHeaderImage.Transparency = new int[] { 0x00, 0x10 };
            //PdfPCell pdfRghtImgCell = new PdfPCell(rightHeaderImage, true)
            //{
            //    FixedHeight = 175,
            //    HorizontalAlignment = Element.ALIGN_RIGHT,
            //    VerticalAlignment = Element.ALIGN_TOP,
            //    Border = Rectangle.BOX,
            //    // PaddingRight = 5f
            //};
            //pdfTabRight.AddCell(pdfRghtImgCell);

            //call WriteSelectedRows of PdfTable. This writes rows from PdfWriter in PdfTable
            //first param is start row. -1 indicates there is no end row and all the rows to be included to write
            //Third and fourth param is x and y position to start writing
            //   pdfTabRight.WriteSelectedRows(0, -1, 325, document.PageSize.Height - 15, writer.DirectContent);

            // For watermakr
            //PdfContentByte under = writer.DirectContentUnder;
            //Image image = rightHeaderImage;
            //image.ScaleToFit(130, 175);
            //image.SetAbsolutePosition(document.PageSize.Width - 145, document.PageSize.Height - 185);
            //under.AddImage(image);

            PdfContentByte canvas = writer.DirectContent;
            Image image = rightHeaderImage;
            image.ScaleToFit(130, 175);
            image.SetAbsolutePosition(document.PageSize.Width - 145, document.PageSize.Height - 185);
            canvas.SaveState();
            var state = new PdfGState { FillOpacity = (0.5f) };
            canvas.SetGState(state);
            canvas.AddImage(image);
            canvas.RestoreState();


            String text = "Page " + writer.PageNumber;
            //Add paging to header
            //{
            //    cb.BeginText();
            //    cb.SetFontAndSize(bf, 12);
            //    cb.SetTextMatrix(document.PageSize.GetRight(200), document.PageSize.GetTop(45));
            //    cb.ShowText(text);
            //    cb.EndText();
            //    float len = bf.GetWidthPoint(text, 12);
            //    //Adds "12" in Page 1 of 12
            //    // cb.AddTemplate(headerTemplate, document.PageSize.GetRight(200) + len, document.PageSize.GetTop(45));
            //}
            //Add paging to footer
            {
                _cb.BeginText();
                _cb.SetFontAndSize(bf, 9);
                _cb.SetTextMatrix(document.PageSize.GetRight(50), document.PageSize.GetBottom(15));
                _cb.ShowText(text);
                _cb.EndText();
                float len = bf.GetWidthPoint(text, 12);
                //  cb.AddTemplate(footerTemplate, document.PageSize.GetRight(180) + len, document.PageSize.GetBottom(30));
            }

            //set pdfContent value
            //Move the pointer and draw line to separate header section from rest of page
            //cb.MoveTo(40, document.PageSize.Height - 100);
            //cb.LineTo(document.PageSize.Width - 40, document.PageSize.Height - 100);
            //cb.Stroke();

            //Move the pointer and draw line to separate footer section from rest of page
            //cb.MoveTo(40, document.PageSize.GetBottom(50));
            //cb.LineTo(document.PageSize.Width - 40, document.PageSize.GetBottom(50));
            //cb.Stroke();
        }

        public override void OnCloseDocument(PdfWriter writer, Document document)
        {
            base.OnCloseDocument(writer, document);

            _headerTemplate.BeginText();
            _headerTemplate.SetFontAndSize(bf, 12);
            _headerTemplate.SetTextMatrix(0, 0);
            _headerTemplate.ShowText((writer.PageNumber - 1).ToString());
            _headerTemplate.EndText();

            _footerTemplate.BeginText();
            _footerTemplate.SetFontAndSize(bf, 12);
            _footerTemplate.SetTextMatrix(0, 0);
            _footerTemplate.ShowText((writer.PageNumber - 1).ToString());
            _footerTemplate.EndText();
        }
    }
}
