﻿using System;
using System.Collections.Generic;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Business.Interfaces;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using System.Threading.Tasks;
using SubQuip.ViewModel.BillOfMaterial;
using SubQuip.ViewModel.Request;
using SubQuip.ViewModel.Statistics;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Statistics controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/statistics")]
    [ValidateModel]
    [Authorize]
    public class StatisticsController : Controller
    {
        private readonly IBillOfMaterialService _billOfMaterialsManagerService;
        private readonly IEquipmentService _equipmentManagerService;
        private readonly IRequestService _requestService;

        /// <summary>
        /// Stat contructor
        /// </summary>
        /// <param name="billOfMaterialsManagerService"></param>
        /// <param name="equipmentManagerService"></param>
        /// <param name="requestService"></param>
        public StatisticsController(IBillOfMaterialService billOfMaterialsManagerService, IEquipmentService equipmentManagerService, IRequestService requestService)
        {
            _billOfMaterialsManagerService = billOfMaterialsManagerService;
            _equipmentManagerService = equipmentManagerService;
            _requestService = requestService;
        }

        /// <summary>
        /// Get Statistics 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(BomStatsViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(EquipmentStats), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(List<DashboardRequestViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult GetStats(Stats stats)
        {
            switch (stats)
            {
                case Stats.BomStat:
                    return _billOfMaterialsManagerService.BomStats();
                case Stats.EquipmentStat:
                    return _equipmentManagerService.EquipmentStats();
                case Stats.RecentBomRequestStat:
                    var latestSearchModel = new SearchSortModel
                    {
                        SortColumn = Constants.CreatedDate,
                        SortDirection = SortDirection.Desc,
                        Page = 1,
                        PageSize = 10
                    };
                    var requests = _requestService.GetDashboardRequests(latestSearchModel);
                    return requests;
            }
            return null;
        }
    }
}
