using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Business.Interfaces;
using SubQuip.Common.CommonData;
using SubQuip.Entity.Models.Graph;
using SubQuip.ViewModel.User;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// User controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/User/[Action]")]
    [ValidateModel]
    [Authorize]
    public class UserController : Controller
    {

        private readonly IUserService _userManager;

        /// <summary>
        /// Initializes a new instance of the UserController
        /// </summary>
        /// <param name="userManager"></param>
        public UserController(IUserService userManager)
        {
            _userManager = userManager;
        }

        /// <summary>
        /// Gets details for given user
        /// </summary>
        /// <param name="userName">username</param>
        [HttpGet]
        [ProducesResponseType(typeof(User), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> GetUser(string userName)
        {
            var details = await _userManager.GetUser(userName);
            return details;
        }

        /// <summary>
        /// Application users
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<User>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> Users()
        {
            var details = await _userManager.ApplicationUsers();
            return details;
        }

        /// <summary>
        /// Get all Tabs For User.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<SavedTabViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult GetUserTabs()
        {
            var userTabs = _userManager.GetTabsForUser();
            return userTabs;
        }

        /// <summary>
        /// Add/Update user tab details
        /// </summary>
        /// <param name="savedTabViewModel"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(SavedTabViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult SaveTabDetail([FromBody]SavedTabViewModel savedTabViewModel)
        {
            var savedTabDetails = _userManager.SaveTabDetail(savedTabViewModel);
            return savedTabDetails;
        }

        /// <summary>
        /// Delete the user tab.
        /// </summary>
        /// <returns>The deleted user tab.</returns>
        /// <param name="id">Identifier of the tab.</param>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult DeleteTab(string id)
        {
            return _userManager.DeleteUserTab(id);
        }

    }
}