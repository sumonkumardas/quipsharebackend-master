﻿using System.Collections.Generic;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Common.CommonData;
using Microsoft.AspNetCore.Authorization;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.ImportViewModel;
using SubQuip.ViewModel.Location;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Location Controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/Location/[Action]")]
    [ValidateModel]
    [Authorize]
    public class LocationController : Controller
    {
        private readonly ILocationService _locationManager;

        /// <summary>
        /// Initializes a new instance of the LocationController.
        /// </summary>
        /// <param name="locationManager"></param>
        public LocationController(ILocationService locationManager)
        {
            _locationManager = locationManager;
        }

        /// <summary>
        /// Get all Locations.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<LocationViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Locations(SearchSortModel search)
        {
            var locationList = _locationManager.GetAllLocations(search);
            return locationList;
        }

        /// <summary>
        /// Import licence data
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ImportResultViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Import(IFormFile uploadFile)
        {
            var result = _locationManager.ImportLocations(uploadFile);
            return result;
        }

        /// <summary>
        /// Export all licence
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<LocationExportViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Export()
        {
            var result = _locationManager.ExportLocations();
            return result;
        }
    }
}