﻿using System;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Common.CommonData;
using Microsoft.AspNetCore.Authorization;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.Equipment;
using SubQuip.ViewModel.PartProperties;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using System.Collections.Generic;
using Newtonsoft.Json;
using SubQuip.Common.Extensions;
using System.IO;
using System.Linq;
using SubQuip.ViewModel.TechSpecs;
using SubQuip.ViewModel.User;
using System.Threading.Tasks;
using SubQuip.ViewModel.Request;
using SubQuip.Common.Enums;
using System.Net;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using System.Security.Principal;
using MongoDB.Bson;
using SubQuip.Entity.Models;
using SubQuip.ViewModel.ImportViewModel;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Equipment controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/Equipment/[Action]")]
    [ValidateModel]
    [Authorize]
    public class EquipmentController : Controller
    {
        private readonly ClaimsPrincipal _principal;
        private readonly IConfiguration _configuration;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IEquipmentService _equipmentService;

        /// <summary>
        /// Initializes a new instance of the EquipmentController
        /// </summary>
        /// <param name="equipmentService">Equipment manager.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="hostingEnvironment">Hosting environment.</param>
        /// <param name="principal"></param>
        public EquipmentController(IEquipmentService equipmentService, IConfiguration configuration, IHostingEnvironment hostingEnvironment,
            IPrincipal principal)
        {
            _principal = principal as ClaimsPrincipal;
            _equipmentService = equipmentService;
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// Search for equipments.
        /// </summary>
        /// <returns>The equipments found by the search.</returns>
        /// <param name="search">Search parameters to find equipments.</param>
        [HttpPost]
        [ProducesResponseType(typeof(List<EquipmentViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Equipments([FromBody]SearchSortModel search)
        {
            var equipmentList = _equipmentService.GetAllEquipments(search);
            return equipmentList;
        }

        /// <summary>
        /// Get a specific equipment by its identifier.
        /// </summary>
        /// <returns>The spesific equipment.</returns>
        /// <param name="id">Identifier of the equipment</param>
        [HttpGet]
        [ProducesResponseType(typeof(EquipmentViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Details(string id)
        {
            var equipmentRecord = _equipmentService.GetEquipmentById(id);
            return equipmentRecord;
        }

        /// <summary>
        /// Create a new equipment.
        /// </summary>
        /// <returns>The created equipment.</returns>
        [HttpPost]
        [ProducesResponseType(typeof(EquipmentViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Create()
        {
            FileDetails fileModel = null;
            var equipmentViewModel = JsonConvert.DeserializeObject<EquipmentViewModel>(Request.Form["model"]);
            if (equipmentViewModel != null)
            {
                var files = Request.Form.Files;
                if (files.Any())
                {
                    var file = files[0];
                    fileModel = FileHelper.GetFileDetails(file);
                }
            }
            var result = _equipmentService.InsertEquipment(equipmentViewModel, fileModel);
            return result;
        }

        /// <summary>
        /// Uploads the equipment document.
        /// </summary>
        /// <returns>The equipment document.</returns>
        [HttpPost]
        [ProducesResponseType(typeof(List<FileDetails>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult InsertEquipmentDocument()
        {
            IResult result = null;
            var documentViewModel = JsonConvert.DeserializeObject<DocumentViewModel>(Request.Form["model"]);
            var fileList = new List<FileDetails>();
            if (documentViewModel != null)
            {
                var files = Request.Form.Files;
                foreach (var file in files)
                {
                    var fileModel = FileHelper.GetFileDetails(file);
                    fileModel.Title = documentViewModel.Title;
                    fileModel.Description = documentViewModel.Description;
                    fileList.Add(fileModel);
                }
                result = _equipmentService.SaveEquipmentDocument(fileList, documentViewModel);
            }
            return result;
        }

        /// <summary>
        /// Updated a spesific equipment.
        /// </summary>
        /// <returns>The updated equipment.</returns>
        [HttpPut]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Update()
        {
            FileDetails fileModel = null;
            var equipmentViewModel = JsonConvert.DeserializeObject<EquipmentViewModel>(Request.Form["model"]);
            if (equipmentViewModel != null)
            {
                var files = Request.Form.Files;
                if (files.Any())
                {
                    var file = files[0];
                    fileModel = FileHelper.GetFileDetails(file);
                }
            }
            var result = _equipmentService.UpdateEquipment(equipmentViewModel, fileModel);
            return result;
        }

        /// <summary>
        /// Manages the equipment part properties.
        /// </summary>
        /// <returns>The equipment part properties.</returns>
        /// <param name="partPropertyViewModel">Part property view model.</param>
        [HttpPut]
        [ProducesResponseType(typeof(PartPropertyViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult ManageEquipmentPartProperties([FromBody] PartPropertyViewModel partPropertyViewModel)
        {
            var result = _equipmentService.ManageEquipmentPartProperties(partPropertyViewModel);
            return result;
        }

        /// <summary>
        /// Manages the equipment tech specs.
        /// </summary>
        /// <returns>The equipment tech specs.</returns>
        /// <param name="techSpecsViewModel">Tech specs view model.</param>
        [HttpPut]
        [ProducesResponseType(typeof(TechSpecsViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult ManageEquipmentTechSpecs([FromBody] TechSpecsViewModel techSpecsViewModel)
        {
            var result = _equipmentService.ManageEquipmentTechnicalSpecs(techSpecsViewModel);
            return result;
        }

        /// <summary>
        /// Delete the equipment.
        /// </summary>
        /// <returns>The deleted equipment.</returns>
        /// <param name="id">Identifier of the equipment.</param>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Delete(string id)
        {
            return _equipmentService.DeleteEquipment(id);
        }

        /// <summary>
        /// Delete All Equipments.
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult DeleteAll([FromBody]UserLoginViewModel loginModel)
        {
            if (loginModel.UserName.Equals("test") && loginModel.UserPassword.Equals("test"))
            {
                return _equipmentService.DeleteAllEquipment();
            }
            return null;
        }

        /// <summary>
        /// Delete Equipment Techincal Specification.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="techSpecId"></param>
        /// <returns></returns>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult DeleteEquipmentTechnicalSpecification(string id, string techSpecId)
        {
            return _equipmentService.DeleteEquipmentTechnicalSpecification(id, techSpecId);
        }

        /// <summary>
        /// Insert Equipment Request
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(EquipmentRequestViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> RequestEquipment()
        {
            IResult result = null;
            var requestViewModel = JsonConvert.DeserializeObject<EquipmentRequestViewModel>(Request.Form["model"]);
            if (requestViewModel != null)
            {
                var fileList = new List<FileDetails>();
                var files = Request.Form.Files;
                foreach (var file in files)
                {
                    var fileModel = FileHelper.GetFileDetails(file);
                    fileList.Add(fileModel);
                }

                result = _equipmentService.InsertEquipmentRequest(fileList, requestViewModel);
                if (result.Status == Status.Success)
                {
                    var emailOptions = PrepareEmailOptions(requestViewModel);
                    if (!string.IsNullOrEmpty(emailOptions.HtmlBody))
                    {
                        #region Append attach files
                        foreach (var file in files)
                        {
                            byte[] content;
                            using (var ms = new MemoryStream())
                            {
                                file.CopyTo(ms);
                                content = ms.ToArray();
                            }
                            emailOptions.Attachments.Add(new Attachment
                            {
                                Name = file.FileName,
                                ContentType = file.ContentType,
                                Content = content
                            });
                        }
                        #endregion

                        var response = await SendGridMailHelper.SendSingleEmailToMultipleRecipients(_configuration, emailOptions);
                        if (response.StatusCode == HttpStatusCode.Accepted)
                        {
                            result.Message += "; Mail sent.";
                        }
                        else
                        {
                            result.Message += "; Mail not sent to provided email.";
                        }
                    }
                    else
                    {
                        result.Message += "; Mail not sent, as email template not found";
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Import Equipments
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(EquipmentImportResult), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Import(IFormFile uploadFile)
        {

            var result = _equipmentService.ImportEquipments(uploadFile);
            return result;
        }

        /// <summary>
        /// Export all Equipments
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<EquipmentExportViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Export()
        {
            var result = _equipmentService.ExportEquipment();
            return result;
        }

        /// <summary>
        /// Get the distinct column values
        /// </summary>
        /// <param name="searchSort"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<string>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult GetDistinctColumnValues(SearchSortModel searchSort)
        {
            var result = _equipmentService.GetDistinctEquipmentColumnValues(searchSort);
            return result;
        }

        /// <summary>
        /// Get Equipments by ids
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="techSpecRequired"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<EquipmentViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult GetEquipmentsByIds(List<string> ids, bool techSpecRequired)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var objectIds = new List<ObjectId>();
                ids.ForEach(t =>
                 {
                     if (ObjectId.TryParse(t, out ObjectId objectId))
                     {
                         objectIds.Add(objectId);
                     }
                 });
                var equipments = _equipmentService.GetEquipmentsByIds(objectIds, techSpecRequired);
                if (equipments == null && !equipments.Any())
                {
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = equipments;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        #region Private methods

        /// <summary>
        /// Prepare Email options for equipment requests
        /// </summary>
        /// <param name="requestViewModel"></param>
        /// <returns></returns>
        private EmailOptions PrepareEmailOptions(EquipmentRequestViewModel requestViewModel)
        {
            var emailOptions = new EmailOptions
            {
                Template = MailTemplate.Equipment,
                PlainBody = string.Empty,
                Attachments = new List<Attachment>()
            };
            var msgBody = SendGridMailHelper.MailBody(_hostingEnvironment, emailOptions.Template);
            if (!string.IsNullOrEmpty(msgBody))
            {
                var link = string.Format("{0}feature/part-detail/equipment/{1}/overview", _configuration["AppUrl"], requestViewModel.RegardingId);
                emailOptions.Subject = "Request for Equipment Received - QuipShare";
                var mailUsers = new List<MailUser>()
                {
                    new MailUser { Name = _configuration["FromName"], Email = _configuration["requestEmail"] },
                    new MailUser { Name = ((ClaimsIdentity)_principal.Identity).GetActiveUserName(), Email = ((ClaimsIdentity)_principal.Identity).GetActiveUserId() }
                };

                emailOptions.ToCcMailList = mailUsers;
                emailOptions.ToMailsList = requestViewModel.MailUsers;
                emailOptions.HtmlBody = msgBody.Replace("{EquipmentNumber}", requestViewModel.EquipmentNumber).
                                                Replace("{Link}", link).
                                                Replace("{FromDate}", requestViewModel.FromDate.ToString("dd-MM-yyyy")).
                                                Replace("{ToDate}", requestViewModel.ToDate.ToString("dd-MM-yyyy"));
            }
            return emailOptions;
        }
        #endregion
    }


}