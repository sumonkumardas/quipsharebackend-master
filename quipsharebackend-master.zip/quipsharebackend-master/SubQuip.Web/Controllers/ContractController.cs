﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SubQuip.Business.Interfaces;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using SubQuip.Common.Extensions;
using SubQuip.ViewModel.ContractWizard;
using SubQuip.WebApi.PdfHelper;
using Newtonsoft.Json;
using SubQuip.WebApi.PdfHelper.ContractWizard;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Contract wizard controller
    /// </summary>
    [Produces("application/json")]
    [Route("api/Contract/[Action]")]
    [Authorize]
    public class ContractController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly ClaimsPrincipal _principal;
        private readonly IContractService _contractService;
        private readonly ISequenceService _sequenceService;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:SubQuip.WebApi.Controllers.ContractController"/> class.
        /// </summary>
        /// <param name="configuration">Configuration.</param>
        /// <param name="hostingEnvironment"></param>
        /// <param name="principal"></param>
        /// <param name="contractService"></param>
        /// <param name="sequenceService"></param>
        public ContractController(IConfiguration configuration, IHostingEnvironment hostingEnvironment, IPrincipal principal, IContractService contractService, ISequenceService sequenceService)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _principal = principal as ClaimsPrincipal;
            _contractService = contractService;
            _sequenceService = sequenceService;
        }


        /// <summary>
        /// Search for contracts.
        /// </summary>
        /// <returns>The contracts found by the search.</returns>
        /// <param name="search">Search parameters to find contracts.</param>
        [HttpGet]
        [ProducesResponseType(typeof(List<ContractDetailViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Contracts(SearchSortModel search)
        {
            var contractList = _contractService.GetAllContracts(search);
            return contractList;
        }

        /// <summary>
        /// Get contracts by regarding id
        /// </summary>
        /// <param name="regardingId"></param>
        /// <param name="search"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<ContractDetailViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult GetContractsByRegardingId(SearchSortModel search, string regardingId)
        {
            var result = _contractService.GetContractsByRegardingId(search, regardingId);
            return result;
        }

        /// <summary>
        /// Send the contract wizard pdf to list of users
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ContractDetailViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> SendRentalContractPdf()
        {
            // var abc = JsonConvert.SerializeObject(ContractWizardHelper.GetDummy());
            var logoFiles = new List<FileDetails>();
            var viewModel = JsonConvert.DeserializeObject<ContractWizardViewModel>(Request.Form["model"]);// ContractWizardHelper.GetDummy(); 
            var files = Request.Form.Files;
            if (files.Any())
            {
                logoFiles.AddRange(files.Select(FileHelper.GetFileDetails));
            }

            var headerContent = new ContractHeaderContent
            {
                HeaderLogoPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Images/logo.png"),
                HeaderRightImagePath = Path.Combine(_hostingEnvironment.ContentRootPath, "Images/top-right-bg.png"),
                FontPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Fonts/montserrat-light.ttf")
            };

            var sequenceValue = _sequenceService.GetSequenceValue(SequenceTypes.Contract);
            var contractNumber = GenericHelper.CurrentDate.ToString("yyyy-MM") + "-" + GenericHelper.GenerateContractSequence(sequenceValue.ToString());
            viewModel.ContractNumber = contractNumber;

            var result = new Result();
            try
            {
                var emailOptions = new EmailOptions
                {
                    Subject = "Rental Contract - " + contractNumber,
                    ToMailsList = viewModel.MailToUsers,
                    PlainBody = string.Empty,
                    Template = MailTemplate.ContractWizard,
                    ToCcMailList = new List<MailUser>
                    {
                        new MailUser { Name = _configuration["FromName"], Email = _configuration["contactEmail"] },
                        new MailUser { Name = ((ClaimsIdentity)_principal.Identity).GetActiveUserName(), Email = ((ClaimsIdentity)_principal.Identity).GetActiveUserId() }
                    }
                };
                var msgBody = SendGridMailHelper.MailBody(_hostingEnvironment, emailOptions.Template);
                if (!string.IsNullOrEmpty(msgBody))
                {
                    emailOptions.Attachments = new List<Attachment>{new Attachment
                    {
                        Name = "RentalContract_"+contractNumber+".pdf",
                        ContentType = System.Net.Mime.MediaTypeNames.Application.Pdf,
                        Content = ContractWizardHelper.GeneratePdf(_hostingEnvironment,viewModel,headerContent,logoFiles)
                    }};

                    emailOptions.HtmlBody = msgBody;
                    var response = await SendGridMailHelper.SendSingleEmailToMultipleRecipients(_configuration, emailOptions);
                    if (response.StatusCode == System.Net.HttpStatusCode.Accepted)
                    {
                        result = _contractService.InsertContract(viewModel.RegardingId, viewModel.ContractTitle, viewModel.ContractNumber, viewModel.DataString) as Result;
                        // ReSharper disable once PossibleNullReferenceException
                        result.Message += "; Mail sent.";
                    }
                    else
                    {
                        result.Message = "; Mail not sent to provided email.";
                        result.Status = Status.Fail;
                        result.StatusCode = HttpStatusCode.BadRequest;
                    }
                    return result;
                }
                result.Message = "Mail not sent, as email template not found";
                result.Body = "Mail not sent";
                result.Status = Status.Fail;
                result.StatusCode = HttpStatusCode.BadRequest;
            }
            catch (Exception ex)
            {
                // ReSharper disable once PossibleNullReferenceException
                result.Message = ex.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }


        /// <summary>
        /// Upload the final signed contract file
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult SaveContractFile()
        {
            var viewModel = JsonConvert.DeserializeObject<UploadContractViewModel>(Request.Form["model"]);
            if (viewModel != null)
            {
                var files = Request.Form.Files;
                if (files.Any())
                {
                    var file = files[0];
                    viewModel.FileDetail = FileHelper.GetFileDetails(file);
                }
            }
            var result = _contractService.SaveContractFile(viewModel);
            return result;
        }
    }
}