﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Business.Interfaces;
using SubQuip.Common.CommonData;
using SubQuip.ViewModel.BillOfMaterial;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using SubQuip.Common.Extensions;
using Microsoft.AspNetCore.Authorization;
using SubQuip.ViewModel.User;
using System.Threading.Tasks;
using SubQuip.ViewModel.Request;
using System.Collections.Generic;
using SubQuip.Common.Enums;
using System.IO;
using System.Net;
using System.Text;
using System.Security.Claims;
using System.Security.Principal;
using System.Text.RegularExpressions;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Bill of materials controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/BillOfMaterials/[Action]")]
    [Authorize]
    public class BillOfMaterialsController : Controller
    {
        private readonly ClaimsPrincipal _principal;
        private readonly IConfiguration _configuration;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IBillOfMaterialService _billOfMaterialsManager;

        /// <summary>
        /// Initializes a new instance of the BillOfMaterialsController
        /// </summary>
        /// <param name="billOfMaterialsManager">Bill of materials manager.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="hostingEnvironment">Hosting environment.</param>
        /// <param name="principal"></param>
        public BillOfMaterialsController(IBillOfMaterialService billOfMaterialsManager, IConfiguration configuration, IHostingEnvironment hostingEnvironment,
            IPrincipal principal)
        {
            _principal = principal as ClaimsPrincipal;
            _billOfMaterialsManager = billOfMaterialsManager;
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// Search for a Bill Of Material (BOM) owned by a user.
        /// </summary>
        /// <returns>The of materials for that spesific user.</returns>
        /// <param name="search">Search Model.</param>
        [HttpPost]
        [ProducesResponseType(typeof(List<BillOfMaterialViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> BillOfMaterialsForUser([FromBody]SearchSortModel search)
        {
            var boms = await _billOfMaterialsManager.GetBillOfMaterialsForUser(search);
            return boms;
        }

        /// <summary>
        /// Get a spesific Bill Of Material (BOM) by its identifier.
        /// </summary>
        /// <returns>The spesific material.</returns>
        /// <param name="id">Identifier of the material.</param>
        [HttpGet]
        [ProducesResponseType(typeof(BillOfMaterialViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Details(string id)
        {
            var bom = _billOfMaterialsManager.GetBillOfMaterialById(id);
            return bom;
        }

        /// <summary>
        /// Get Boms of Specific Template.
        /// </summary>
        /// <param name="templateId"></param>
        /// <param name="owner"></param>
        /// <param name="location"></param>
        /// <param name="license"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<BomTemplateViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> BomsForTemplate(string templateId, string owner, string location, string license)
        {
            var bom = await _billOfMaterialsManager.GetBomsForTemplate(templateId, owner, location, license);
            return bom;
        }

        /// <summary>
        /// Get all Bom Templates.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<BomTemplateViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> BomTemplates(SearchSortModel search)
        {
            var bomTemplates = await _billOfMaterialsManager.GetBomTemplates(search);
            return bomTemplates;
        }

        /// <summary>
        /// Create a Bill Of Material (BOM) / BOM Template.
        /// </summary>
        /// <returns>The created Bom Of Material / BOM Template.</returns>
        [HttpPost]
        [ProducesResponseType(typeof(BillOfMaterialViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Create()
        {
            FileDetails fileModel = null;
            var bomViewModel = JsonConvert.DeserializeObject<BillOfMaterialViewModel>(Request.Form["model"]);
            if (bomViewModel != null)
            {
                var files = Request.Form.Files;
                if (files.Any())
                {
                    var file = files[0];
                    fileModel = FileHelper.GetFileDetails(file);
                }
            }
            var result = _billOfMaterialsManager.CreateBillOfMaterial(bomViewModel, fileModel);
            return result;
        }

        /// <summary>
        /// Update a Bill Of Material (BOM)
        /// </summary>
        /// <returns>The update.</returns>
        [HttpPut]
        [ProducesResponseType(typeof(BillOfMaterialViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Update()
        {
            FileDetails fileModel = null;
            var bomViewModel = JsonConvert.DeserializeObject<BillOfMaterialViewModel>(Request.Form["model"]);
            if (bomViewModel != null)
            {
                var files = Request.Form.Files;
                if (files.Any())
                {
                    var file = files[0];
                    fileModel = FileHelper.GetFileDetails(file);
                }
            }
            var result = _billOfMaterialsManager.UpdateBillOfMaterial(bomViewModel, fileModel);
            return result;
        }

        /// <summary>
        /// Delete a Bill Of Material (BOM) by its identifier.
        /// </summary>
        /// <returns>The deleted Bill Of Material.</returns>
        /// <param name="id">Identifier of the Bill of Material (BOM).</param>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Delete(string id)
        {
            return _billOfMaterialsManager.DeleteBillOfMaterial(id);
        }

        /// <summary>
        /// Delete All Bill Of Material (BOM). 
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult DeleteAll([FromBody]UserLoginViewModel loginModel)
        {
            if (loginModel.UserName.Equals("test") && loginModel.UserPassword.Equals("test"))
            {
                return _billOfMaterialsManager.DeleteAllBillOfMaterial();
            }
            return null;
        }

        /// <summary>
        /// Adds comment to existing BOM
        /// </summary>
        /// <returns>The created comment on Bom</returns>
        [HttpPost]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult AddCommentToBOM([FromBody]BomCommentViewModel bomCommentViewModel)
        {
            var result = _billOfMaterialsManager.SaveCommentForBOM(bomCommentViewModel);
            return result;
        }

        /// <summary>
        /// Add Option to BOM.
        /// </summary>
        /// <param name="bomOptionViewModel"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult AddOptionToBOM([FromBody]BomOptionViewModel bomOptionViewModel)
        {
            var result = _billOfMaterialsManager.SaveOptionForBOM(bomOptionViewModel);
            return result;
        }

        /// <summary>
        /// Retrieve comments related to BOM
        /// </summary>
        /// <returns>Comments for specific BOM.</returns>
        /// <param name="bomId">Specific BomId.</param>
        [HttpGet]
        [ProducesResponseType(typeof(List<BomCommentViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult CommentsForBom(string bomId)
        {
            var boms = _billOfMaterialsManager.GetCommentsForBom(bomId);
            return boms;
        }

        /// <summary>
        /// Create and submit a new request.
        /// </summary>
        /// <returns>Result model.</returns>
        [HttpPost]
        [ProducesResponseType(typeof(BomRequestViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> CreateBOMRequest()
        {
            IResult result = null;
            var requestViewModel = JsonConvert.DeserializeObject<BomRequestViewModel>(Request.Form["model"]);
            if (requestViewModel == null) return result;

            requestViewModel.Type = RequestFormType.BillOfMaterial;
            var files = Request.Form.Files;
            var fileList = files.Select(FileHelper.GetFileDetails).ToList();
            result = _billOfMaterialsManager.InsertBOMRequest(fileList, requestViewModel);
            if (result.Status != Status.Success) return result;

            var emailOptions = PrepareEmailOptions(requestViewModel);
            if (!string.IsNullOrEmpty(emailOptions.HtmlBody))
            {
                #region Append attach files
                foreach (var file in files)
                {
                    byte[] content = null;
                    using (var ms = new MemoryStream())
                    {
                        file.CopyTo(ms);
                        content = ms.ToArray();
                    }
                    emailOptions.Attachments.Add(new Attachment
                    {
                        Name = file.FileName,
                        ContentType = file.ContentType,
                        Content = content
                    });
                }
                #endregion

                var response = await SendGridMailHelper.SendSingleEmailToMultipleRecipients(_configuration, emailOptions);
                result.Message += response.StatusCode == HttpStatusCode.Accepted
                    ? "; Mail sent."
                    : "; Mail not sent to provided email.";
            }
            else
            {
                result.Message += "; Mail not sent, as email template not found";
            }
            return result;
        }

        /// <summary>
        /// Add Equipment/Material To BOM.
        /// </summary>
        /// <param name="addItemToBom"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult AddItemToBom([FromBody]AddItemToBom addItemToBom)
        {
            var bom = _billOfMaterialsManager.AddItemToBom(addItemToBom);
            return bom;
        }

        /// <summary>
        /// Get Added Items of BOM.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="bomId"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(Item), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult GetAddedItemsOfBom(SearchSortModel search, string bomId)
        {
            var bom = _billOfMaterialsManager.GetAddedItemsOfBom(search, bomId);
            return bom;
        }

        /// <summary>
        /// Get the distinct column values
        /// </summary>
        /// <param name="searchSort"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<string>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public async Task<IResult> GetDistinctColumnValues(SearchSortModel searchSort)
        {
            var result = await _billOfMaterialsManager.GetDistinctBomColumnValues(searchSort);
            return result;
        }

        #region Private methods
        /// <summary>
        /// Prepare Email options for various system requests
        /// </summary>
        /// <param name="requestViewModel"></param>
        /// <returns></returns>
        private EmailOptions PrepareEmailOptions(BomRequestViewModel requestViewModel)
        {
            var emailOptions = new EmailOptions
            {
                Template = MailTemplate.BillOfMaterial,
                PlainBody = string.Empty,
                Attachments = new List<Attachment>()
            };
            var msgBody = SendGridMailHelper.MailBody(_hostingEnvironment, emailOptions.Template);
            if (string.IsNullOrEmpty(msgBody)) return emailOptions;
            var link = $"{ _configuration["AppUrl"]}feature/bom-detail/{ requestViewModel.RegardingId}";
            emailOptions.Subject = "Request for Bill Of Material Received - QuipShare";
            var ccMailUsers = new List<MailUser>()
            {
                new MailUser { Name = _configuration["FromName"], Email = _configuration["requestEmail"] },
                new MailUser { Name = ((ClaimsIdentity)_principal.Identity).GetActiveUserName(), Email = ((ClaimsIdentity)_principal.Identity).GetActiveUserId() }
            };
            emailOptions.ToCcMailList = ccMailUsers;
            emailOptions.ToMailsList = requestViewModel.MailUsers;
            emailOptions.HtmlBody = msgBody.Replace("{BomDescription}", requestViewModel.Description).
                Replace("{Description}", PrepareHtmlBody(requestViewModel)).
                Replace("{FromDate}", requestViewModel.FromDate.ToString("dd-MM-yyyy")).
                Replace("{ToDate}", requestViewModel.ToDate.ToString("dd-MM-yyyy")).
                Replace("{BomName}", requestViewModel.BomTitle).
                Replace("{BomLink}", link);
            return emailOptions;
        }

        /// <summary>
        /// Prepare HTML Msg Body
        /// </summary>
        /// <returns></returns>
        private string PrepareHtmlBody(BomRequestViewModel requestViewModel)
        {
            if (requestViewModel.BomRequestNodes == null || !requestViewModel.BomRequestNodes.Any()) return null;
            var sb = new StringBuilder();
            var materialItems = requestViewModel.BomRequestNodes.Where(x => x.Type == BomItemType.Material).ToList();
            if (materialItems.Any())
            {
                sb.Append("<div class='description'>");
                sb.Append("<div><span> I would like to order following subsea " + BomItemType.Material + "</span></div></br>");
                sb.Append("<div><table><tr><th class='th1'>Part Number</th><th class='th2'>Description</th><th class='th3'>Manufactor Name</th><th class='th4'>Manufactor Number</th></tr>");
                materialItems.ForEach(x =>
                {
                    var link = $"{_configuration["AppUrl"]}feature/part-detail/material/{x.RegardingId}/overview";
                    sb.Append($"<tr><td><a title='Click to view detail of {x.ItemNumber}' href='{link}'>{x.ItemNumber}</a></td><td>{x.Description}</td><td>{x.ManufactorName}</td><td>{x.ManufactorPartNumber}</td></tr>");
                });
                sb.Append("</table></div>");
                sb.Append("</div>");
            }

            var equipmentItems = requestViewModel.BomRequestNodes.Where(x => x.Type == BomItemType.Equipment).ToList();
            if (!equipmentItems.Any()) return sb.ToString();
            sb.Append("<div class='description'>");
            sb.Append("<div><span> I would like to order following subsea " + BomItemType.Equipment + "</span></div></br>");
            sb.Append("<div><table><tr><th class='th1'>Equipment Number</th><th class='th2'>Description</th><th class='th3'>Manufactor Name</th><th class='th4'>Manufactor Number</th></tr>");
            equipmentItems.ForEach(x =>
            {
                var link = $"{_configuration["AppUrl"]}feature/part-detail/equipment/{x.RegardingId}/overview";
                sb.Append($"<tr><td><a title='Click to view detail of {x.ItemNumber}' href='{link}'>{x.ItemNumber}</a></td><td>{x.Description}</td><td>{x.ManufactorName}</td><td>{x.ManufactorPartNumber}</td></tr>");
            });
            sb.Append("</table></div>");
            sb.Append("</div>");
            return sb.ToString();
        }
        #endregion
    }
}