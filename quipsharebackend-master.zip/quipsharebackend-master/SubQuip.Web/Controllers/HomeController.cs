﻿using Microsoft.AspNetCore.Mvc;

namespace SubQuip.WebApi.Controllers
{
    [Route("api")]
    public class HomeController : Controller
    {
        [HttpGet]
        public OkResult Get()
        {
            return Ok();
        }
    }
}
