﻿using System.Collections.Generic;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Common.CommonData;
using SubQuip.ViewModel.Partner;
using Microsoft.AspNetCore.Authorization;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.ImportViewModel;
using SubQuip.ViewModel.User;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Partner controller, to handle the different partners in SubQuip
    /// </summary>
    [Produces("application/json")]
    [Route("api/Partner/[Action]")]
    [ValidateModel]
    [Authorize]
    public class PartnerController : Controller
    {
        private readonly IPartnerService _partnerManager;

        /// <summary>
        /// Initializes a new instance of the PartnerController
        /// </summary>
        /// <param name="partnerManager"></param>
        public PartnerController(IPartnerService partnerManager)
        {
            _partnerManager = partnerManager;
        }

        /// <summary>
        /// Get a list of all partners registered in SubQuip.
        /// </summary>
        /// <returns>List of partners</returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<PartnerViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Partners(SearchSortModel search)
        {
            var partners = _partnerManager.GetAllPartners(search);
            return partners;
        }

        /// <summary>
        /// Get a specific partner by its identifier.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Partner</returns>
        [HttpGet]
        [ProducesResponseType(typeof(PartnerViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Details(string id)
        {
            var partner = _partnerManager.GetPartnerById(id);
            return partner;
        }

        /// <summary>
        /// Create a Partner.
        /// </summary>
        /// <param name="partnerView"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(PartnerViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Create([FromBody]PartnerViewModel partnerView)
        {
            var partner = _partnerManager.Create(partnerView);
            return partner;
        }

        /// <summary>
        /// Update a Partner.
        /// </summary>
        /// <param name="partnerView"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Update([FromBody]PartnerViewModel partnerView)
        {
            var partner = _partnerManager.Update(partnerView);
            return partner;
        }

        /// <summary>
        /// Delete a Partner.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Delete(string id)
        {
            var partner = _partnerManager.Delete(id);
            return partner;
        }

        /// <summary>
        /// Delete All Partners.
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpDelete]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult DeleteAll([FromBody]UserLoginViewModel loginModel)
        {
            if (loginModel.UserName.Equals("test") && loginModel.UserPassword.Equals("test"))
            {
                return _partnerManager.DeleteAllPartners();
            }
            return null;
        }

        /// <summary>
        /// Import partner data
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ImportResultViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Import(IFormFile uploadFile)
        {
            var result = _partnerManager.ImportPartners(uploadFile);
            return result;
        }

        /// <summary>
        /// Export all partners
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<PartnerExportViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Export()
        {
            var result = _partnerManager.ExportPartners();
            return result;
        }

    }
}