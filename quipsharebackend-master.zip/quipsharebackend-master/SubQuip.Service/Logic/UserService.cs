﻿using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Business.Interfaces;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using SubQuip.Common.Extensions;
using SubQuip.Data.Interfaces;
using SubQuip.Entity.Models.AppUser;
using SubQuip.ViewModel.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using SubQuip.Entity.Models.Graph;

namespace SubQuip.Business.Logic
{
    public class UserService : IUserService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly IUserRepository _userRepository;
        private readonly IGraphRepository _graphRepositoty;

        /// <summary>
        /// Initializes a new instance of the UserManagerService
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="graphRepository"></param>
        /// <param name="userRepository"></param>
        public UserService(IPrincipal principal, IGraphRepository graphRepository, IUserRepository userRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _userRepository = userRepository;
            _graphRepositoty = graphRepository;
        }

        public async Task<IResult> GetUser(string userName)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var user = (ClaimsIdentity)_principal.Identity;
                if (userName != user.Name && !user.Claims.Any(c => c.Value == userName) && !(await _graphRepositoty.FindExternalUser(user.Name)).IsAdmin)
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.NoResultFound;
                    result.StatusCode = HttpStatusCode.Unauthorized;
                    return result;
                }

                var details = await _graphRepositoty.FindExternalUser(userName);
                result.Body = details;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get All Tabs For User.
        /// </summary>
        /// <returns></returns>
        public IResult GetTabsForUser()
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {

                var mail = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(mail))
                {
                    var savedTabList = new List<SavedTabViewModel>();
                    var user = _userRepository.GetChildDocument(x => x.Mail.Equals(mail), "SavedTabs", "UserId");
                    if (user != null && user.SavedTabs != null && user.SavedTabs.Any())
                    {
                        user.SavedTabs = user.SavedTabs.OrderBy(x => x.CreatedDate).ToList();
                        savedTabList = savedTabList.MapFromModel<SavedTab, SavedTabViewModel>(user.SavedTabs);
                        result.Body = savedTabList;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    else
                    {
                        result.Body = savedTabList;
                        result.Message = CommonErrorMessages.NoResultFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Save User and Tab Details.
        /// </summary>
        /// <param name="savedTabViewModel"></param>
        /// <returns></returns>
        public IResult SaveTabDetail(SavedTabViewModel savedTabViewModel)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                SavedTab savedTabDetail = null;
                if (savedTabViewModel != null)
                {
                    var mail = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                    if (!string.IsNullOrEmpty(mail))
                    {
                        var user = _userRepository.GetOne(x => x.Mail.Equals(mail));
                        if (user == null)
                        {
                            user = new AppUser
                            {
                                Mail = mail,
                                SavedTabs = new List<SavedTab>()
                            };
                            user.MapAuditColumns((ClaimsIdentity)_principal.Identity);
                            _userRepository.InsertOne(user);
                        }

                        savedTabDetail = new SavedTab();
                        savedTabDetail.MapFromViewModel(savedTabViewModel, (ClaimsIdentity)_principal.Identity);
                        if (!string.IsNullOrEmpty(savedTabViewModel.TabId)) // Update
                        {
                            var updateDefinition = Builders<AppUser>.Update.
                                Set(t => t.ModifiedBy, mail).
                                Set(x => x.ModifiedDate, GenericHelper.CurrentDate).
                                Set(t => t.SavedTabs[-1].Name, savedTabViewModel.Name).
                                Set(t => t.SavedTabs[-1].Path, savedTabViewModel.Path).
                                Set(t => t.SavedTabs[-1].ModifiedBy, mail).
                                Set(t => t.SavedTabs[-1].ModifiedDate, GenericHelper.CurrentDate);

                            _userRepository.UpdateOne(t => t.UserId.Equals(user.UserId) &&
                                                           t.SavedTabs.Any(o => o.TabId.Equals(ObjectId.Parse(savedTabViewModel.TabId))),
                                updateDefinition);
                        }
                        else // insert
                        {
                            savedTabDetail.TabId = ObjectId.GenerateNewId();
                            var updateDefinition = Builders<AppUser>.Update.
                                Set(t => t.ModifiedBy, mail).
                                Set(x => x.ModifiedDate, GenericHelper.CurrentDate).
                                AddToSet(t => t.SavedTabs, savedTabDetail);
                            _userRepository.UpdateOne(t => t.UserId.Equals(user.UserId), updateDefinition);
                        }

                        result.Message = UserNotification.TabDetailsSaved;
                        result.Body = savedTabViewModel.MapFromModel(savedTabDetail);
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = CommonErrorMessages.MailNotFound;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                    }
                }
                else
                {
                    result.Message = UserNotification.NoTabDetails;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete user tab
        /// </summary>
        /// <param name="tabId"></param>
        /// <returns></returns>
        public IResult DeleteUserTab(string tabId)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                var mail = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(mail))
                {
                    var user = _userRepository.GetOne(x => x.Mail.Equals(mail));
                    if (user != null)
                    {
                        var update = Builders<AppUser>.Update.PullFilter(u => u.SavedTabs, f => f.TabId == ObjectId.Parse(tabId));
                        _userRepository.UpdateOne(p => p.UserId == user.UserId, update);
                        result.Message = UserNotification.TabDeleted;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// List of application users
        /// </summary>
        /// <returns></returns>
        public async Task<IResult> ApplicationUsers()
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var usersData = new List<User>();
                var users = await _graphRepositoty.ApplicationUsers();
                if (users.Value != null && users.Value.Any())
                {
                    var groups = await _graphRepositoty.ApplicationGroups();
                    usersData = users.Value.Select(u =>
                    {
                        var userGroups = new List<Group>();
                        if (groups.Value == null || !groups.Value.Any()) return u;
                        groups.Value.ForEach(g =>
                        {
                            if (g.Member.All(m => m.Id != u.Id)) return;
                            if (g.DisplayName.ToLower() == GraphConstants.AdminGroup.ToLower())
                                u.IsAdmin = true;
                            if (g.DisplayName.ToLower() == GraphConstants.CompanyAdminGroup.ToLower())
                                u.IsCompanyAdmin = true;
                            // userGroups.Add(g);
                        });
                        u.Groups = userGroups;
                        return u;
                    }).ToList();
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = usersData;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;

        }
    }
}