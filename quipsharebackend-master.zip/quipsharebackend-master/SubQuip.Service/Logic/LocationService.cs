﻿using SubQuip.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.Common.CommonData;
using SubQuip.Data.Interfaces;
using SubQuip.Common.Enums;
using SubQuip.ViewModel.Location;
using System.Linq;
using SubQuip.Common.Extensions;
using SubQuip.Entity.Models;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using Microsoft.AspNetCore.Http;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Common.Importer;
using SubQuip.ViewModel.ImportViewModel;
using SubQuip.ViewModel.Licence;

namespace SubQuip.Business.Logic
{
    public class LocationService : ILocationService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly ILocationRepository _locationRepository;

        /// <summary>
        /// Initializes a new instance of the LocationManagerService.
        /// </summary>
        /// <param name="locationRepository"></param>
        public LocationService(IPrincipal principal, ILocationRepository locationRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _locationRepository = locationRepository;
        }

        /// <summary>
        /// Get all Locations.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IResult GetAllLocations(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = "CreatedDate";
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var locationViewModels = new List<LocationViewModel>();
                var locations = _locationRepository.GetAllLocations(search);
                if (locations != null && locations.Any())
                {
                    search.SearchResult = locationViewModels.MapFromModel<Location, LocationViewModel>(locations);
                }
                else
                {
                    search.SearchResult = locationViewModels;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = search;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Import location
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        public IResult ImportLocations(IFormFile uploadFile)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                if (System.IO.Path.GetExtension(uploadFile.FileName) == ".csv")
                {
                    var dataToImport = new CsvFileReader().ProcessFile(uploadFile.OpenReadStream());
                    var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                    if (!string.IsNullOrEmpty(emailActiveUserId))
                    {
                        var isEdit = false;
                        var mainFields = new List<string> { "LocationName" };

                        if (CsvVerified(dataToImport.Headers, mainFields, ref result))
                        {
                            // 1. Map the incoming data to models
                            var mappedModels =
                                MapImportedToModel(dataToImport, mainFields, emailActiveUserId, ref isEdit);

                            // 2. Check for location in db if same file is again uploaded
                            var locationInDb = new List<string>();
                            var locationFromImport = !isEdit
                                ? mappedModels.Where(e => !e.IsDeleted).Select(e => e.LocationName).Distinct().ToList()
                                : mappedModels.Where(e => e.LocationId == ObjectId.Empty && !e.IsDeleted).Select(e => e.LocationName).Distinct().ToList();
                            if (locationFromImport.Any())
                            {
                                // location found from db
                                var locationFound = _locationRepository.Query.Where(e => locationFromImport.Contains(e.LocationName)).ToList();
                                if (locationFound.Any())
                                {
                                    locationInDb = locationFound.Select(t => t.LocationName).ToList();
                                }
                            }

                            // 3. Get the list of new location as whole.
                            var locationForInsert = new List<Location>();
                            var locationForUpdate = new List<Location>();
                            var locationForDeletion = new List<ObjectId>();
                            if (mappedModels.Any())
                            {
                                locationForDeletion = mappedModels.Where(e => e.IsDeleted).Select(t => t.LocationId).ToList();
                                locationForInsert = mappedModels.Where(t => t.LocationId == ObjectId.Empty && !locationInDb.Contains(t.LocationName) && !t.IsDeleted)
                                    .ToList();
                                locationForUpdate = mappedModels.Where(t => t.LocationId != ObjectId.Empty && !t.IsDeleted)
                                    .ToList();
                            }

                            // 4. Insert the location in bulk to db except the already exist
                            if (locationForInsert.Any())
                                _locationRepository.InsertMany(locationForInsert);

                            // 5. Update the Already exist location
                            if (locationForUpdate.Any())
                            {
                                locationForUpdate.ForEach(m =>
                                {
                                    var updateDefinition = Builders<Location>.Update
                                        .Set(x => x.LocationName, m.LocationName)
                                        .Set(x => x.ModifiedDate, m.ModifiedDate)
                                        .Set(x => x.ModifiedBy, m.ModifiedBy);
                                    _locationRepository.UpdateOne(t => t.LocationId.Equals(m.LocationId), updateDefinition);
                                });
                            }

                            // Delete location
                            if (locationForDeletion.Any())
                            {
                                _locationRepository.DeleteMany(t => locationForDeletion.Contains(t.LocationId));
                            }

                            // 6. Map the result with viewmodel
                            var importResult = new ImportResultViewModel
                            {
                                InsertedCount = locationForInsert.Count,
                                UpdatedCount = locationForUpdate.Count,
                                RecordsReUploaded = locationInDb.Count,
                                ErrorCount = dataToImport.Errors.Count,
                                RecordsForDeletion = locationForDeletion.Count,
                                Errors = dataToImport.Errors
                            };

                            result.Body = importResult;
                            result.StatusCode = HttpStatusCode.OK;
                        }
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = CommonErrorMessages.MailNotFound;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.UnSupportedFileFormat;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableFormat;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Export Locations
        /// </summary>
        /// <returns></returns>
        public IResult ExportLocations()
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var locations = _locationRepository.Query.OrderByDescending(t => t.CreatedDate)
                    .ThenByDescending(t => t.ModifiedDate).ToList();
                var dataForExport = new List<LocationExportViewModel>();
                if (locations.Any())
                {
                    dataForExport = locations.Select(m =>
                    {
                        var locationExportViewModel = new LocationExportViewModel();
                        locationExportViewModel.MapFromModel(m);
                        return locationExportViewModel;
                    }).ToList();
                }
                result.Body = dataForExport;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        #region Private Method

        /// <summary>
        /// Verify the uploaded csv
        /// </summary>
        /// <param name="headers"></param>
        /// <param name="mainFields"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        private bool CsvVerified(List<string> headers, List<string> mainFields, ref Result result)
        {
            var returnVal = true;
            if (headers.Any())
            {
                if (mainFields.Count != headers.Count(mainFields.Contains))
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.CsvReqHeadersNotPresent;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                    returnVal = false;
                }
            }
            else
            {
                result.Status = Status.Fail;
                result.Message = CommonErrorMessages.CsvHeadersNotPresent;
                result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                returnVal = false;
            }
            return returnVal;
        }

        /// <summary>
        /// Map imported row key value pair to material model
        /// </summary>
        /// <param name="dataToImport"></param>
        /// <param name="mainFields"></param>
        /// <param name="emailActiveUserId"></param>
        /// <param name="isEdit"></param>
        /// <returns></returns>
        private List<Location> MapImportedToModel(ImportedData dataToImport, List<string> mainFields, string emailActiveUserId, ref bool isEdit)
        {
            if (dataToImport.Headers.Any())
            {
                // 1. Check for Id field for add/Edit
                isEdit = dataToImport.Headers.Any(t => t.Equals("Id"));
                if (isEdit)
                {
                    mainFields.Add("Id");
                    if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                        mainFields.Add("IsDeleted");
                }
            }

            var locations = new List<Location>();
            if (dataToImport.RowData != null && dataToImport.RowData.Any())
            {
                var edit = isEdit;
                var rowNum = 0;
                locations = dataToImport.RowData.Select(row =>
                {
                    rowNum++;
                    try
                    {
                        var locationModel = new Location
                        {
                            LocationName = row[mainFields[0]],
                            IsActive = true,
                            CreatedBy = emailActiveUserId,
                            CreatedDate = GenericHelper.CurrentDate,
                            ModifiedBy = emailActiveUserId,
                            ModifiedDate = GenericHelper.CurrentDate
                        };
                        if (edit)
                        {
                            if (!string.IsNullOrEmpty(row[mainFields[1]]))
                                locationModel.LocationId = ObjectId.Parse(row[mainFields[1]]);
                            if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                                if (!string.IsNullOrEmpty(row[mainFields[2]]))
                                    locationModel.IsDeleted = Convert.ToBoolean(row[mainFields[2]]);
                        }
                        return locationModel;
                    }
                    catch (Exception ex)
                    {
                        dataToImport.Errors.Add(new DataParsingError
                        {
                            ErrorRow = rowNum,
                            Row = string.Format(CommonErrorMessages.DataMappingErrorAtRow, rowNum),
                            ErrorString = string.Format(CommonErrorMessages.DataMappingError, ex.Message)
                        });
                    }
                    return null;
                }).ToList();
            }
            return locations.Where(m => m != null).ToList();
        }

        #endregion
    }
}
