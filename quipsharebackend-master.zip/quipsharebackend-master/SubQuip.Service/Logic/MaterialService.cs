﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using SubQuip.Common.Extensions;
using SubQuip.Data.Interfaces;
using SubQuip.Entity.Models;
using System.Linq;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.Equipment;
using SubQuip.ViewModel.Material;
using SubQuip.ViewModel.PartProperties;
using SubQuip.ViewModel.TechSpecs;
using SubQuip.Common.Importer;
using SubQuip.ViewModel.Request;
using Microsoft.AspNetCore.Http;
using System.Net;
using Microsoft.Extensions.Configuration;
using SubQuip.ViewModel.ImportViewModel;

namespace SubQuip.Business.Logic
{
    public class MaterialService : IMaterialService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly IMaterialRepository _materialRepository;
        private readonly IEquipmentRepository _equipmentRepository;
        private readonly IRequestRepository _requestRepository;
        private readonly IFileRepository _fileRepository;
        private readonly IFileService _fileManagerService;
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the MaterialManagerService
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="configuration"></param>
        /// <param name="materialRepository"></param>
        /// <param name="equipmentRepository"></param>
        /// <param name="fileRepository"></param>
        /// <param name="fileManagerService"></param>
        /// <param name="requestRepository"></param>
        public MaterialService(IPrincipal principal, IConfiguration configuration, IMaterialRepository materialRepository,
            IEquipmentRepository equipmentRepository, IFileRepository fileRepository, IFileService fileManagerService,
            IRequestRepository requestRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _configuration = configuration;
            _materialRepository = materialRepository;
            _equipmentRepository = equipmentRepository;
            _fileRepository = fileRepository;
            _fileManagerService = fileManagerService;
            _requestRepository = requestRepository;
        }

        /// <summary>
        /// Get All Materials
        /// </summary>
        /// <returns></returns>
        public IResult GetAllMaterials(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = Constants.CreatedDate;
            }

            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var materialViewModels = new List<MaterialViewModel>();
                var allMaterial = _materialRepository.GetAllMaterials(search, search.IstechSpecRequired);
                if (allMaterial != null && allMaterial.Any())
                {
                    if (!search.IstechSpecRequired)
                    {
                        search.SearchResult = materialViewModels.MapFromModel<Material, MaterialViewModel>(allMaterial);
                    }
                    else
                    {
                        materialViewModels = allMaterial.Select(t =>
                           {
                               var materialViewModel = new MaterialViewModel();
                               materialViewModel.MapFromModel(t);
                               if (t.TechnicalSpecifications == null || !t.TechnicalSpecifications.Any())
                                   return materialViewModel;
                               var techSpecs = new List<TechSpecsViewModel>();
                               materialViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(t.TechnicalSpecifications);
                               return materialViewModel;
                           }).ToList();
                        search.SearchResult = materialViewModels;
                    }
                }
                else
                {
                    search.SearchResult = materialViewModels;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = search;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;

        }

        /// <summary>
        /// Get a Material
        /// </summary>
        /// <param name = "id" > material id</param>
        /// <returns></returns>
        public IResult GetMaterialById(string id)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    var material = _materialRepository.GetOne(t => t.MaterialId == ObjectId.Parse(id));
                    if (material != null)
                    {
                        var materialViewModel = new MaterialViewModel();
                        materialViewModel.MapFromModel(material);
                        if (material.ImageId != null)
                        {
                            var file = _fileRepository.GetOne(t => t.FileId == material.ImageId);
                            materialViewModel.ImageId = material.ImageId.ToString();
                            materialViewModel.ImageContent = (file != null) ? file.Content : string.Empty;
                        }
                        if (material.PartProperties != null && material.PartProperties.Any())
                        {
                            var overviews = new List<PartPropertyViewModel>();
                            materialViewModel.PartProperties = overviews.MapFromModel<PartProperty, PartPropertyViewModel>(material.PartProperties);
                        }
                        if (material.Documents != null && material.Documents.Any())
                        {
                            materialViewModel.Documents = _fileManagerService.GetFiles(material.Documents);
                        }
                        if (material.TechnicalSpecifications != null && material.TechnicalSpecifications.Any())
                        {
                            var techSpecs = new List<TechSpecsViewModel>();
                            materialViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(material.TechnicalSpecifications);
                        }
                        result.Body = materialViewModel;
                    }
                    else
                    {
                        result.Message = MaterialNotification.MaterialNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.NoIdentifierProvided;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.NoIdentifierProvided;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert Material
        /// </summary>
        /// <param name="materialViewModel"></param>
        /// <param name="fileViewModel"></param>
        /// <returns></returns>
        public IResult InsertMaterial(MaterialViewModel materialViewModel, FileDetails fileViewModel)
        {
            materialViewModel.MaterialId = null;
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                long.TryParse(_configuration["AllowedPartImageSize"], out long allowedSize);
                if (fileViewModel?.FileSize > allowedSize)
                {
                    result.Message = string.Format(FileNotification.FileSizeError, allowedSize);
                    result.StatusCode = HttpStatusCode.NotAcceptable;
                    result.Status = Status.Fail;
                    return result;
                }

                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    var material = new Material();
                    material.MapFromViewModel(materialViewModel, (ClaimsIdentity)_principal.Identity);
                    material.PartProperties = new List<PartProperty>();
                    material.Documents = new List<ObjectId>();
                    material.TechnicalSpecifications = new List<TechnicalSpecification>();
                    _materialRepository.InsertOne(material);


                    var resultView = new MaterialViewModel();
                    resultView.MapFromModel(material);
                    #region Insert Material Image

                    if (fileViewModel != null)
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        // insert new image
                        if (file.Content != null)
                        {
                            _fileRepository.InsertOne(file);
                            var updateMaterialFileDefinition = Builders<Material>.Update
                                 .Set(x => x.ImageId, file.FileId)
                                 .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                                 .Set(x => x.ModifiedBy, emailActiveUserId);
                            _materialRepository.UpdateOne(t => t.MaterialId.Equals(ObjectId.Parse(resultView.MaterialId)), updateMaterialFileDefinition);
                        }
                    }

                    #endregion

                    result.Body = resultView;
                    result.Message = MaterialNotification.Created;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Save Material Document
        /// </summary>
        /// <param name = "document" ></param >
        /// <param name="fileList"></param>
        /// < returns ></returns >
        public IResult SaveMaterialDocument(List<FileDetails> fileList, DocumentViewModel document)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var documentIds = new List<ObjectId>();
                var fileDetails = new List<FileDetails>();
                if (fileList != null && fileList.Any())
                {
                    fileList.ForEach(t =>
                    {
                        var file = new File();
                        file.MapFromViewModel(t, (ClaimsIdentity)_principal.Identity);
                        _fileRepository.InsertOne(file);
                        documentIds.Add(file.FileId);

                        var fileDetail = new FileDetails();
                        fileDetail.MapFromModel(file);
                        fileDetail.Content = string.Empty;
                        fileDetails.Add(fileDetail);
                    });
                }

                var updateDefinition = Builders<Material>.Update.Set(t => t.ModifiedDate, GenericHelper.CurrentDate).AddToSetEach(t => t.Documents, documentIds);
                _materialRepository.UpdateOne(t => t.MaterialId.Equals(ObjectId.Parse(document.RegardingId)), updateDefinition);
                result.Operation = Operation.Create;
                result.Message = MaterialNotification.DocumentCreated;
                result.Body = fileDetails;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Update Material
        /// </summary>
        /// <param name="materialViewModel"></param>
        /// <param name="fileViewModel"></param>
        /// <returns></returns>
        public IResult UpdateMaterial(MaterialViewModel materialViewModel, FileDetails fileViewModel)
        {
            var result = new Result
            {
                Operation = Operation.Update,
                Status = Status.Success
            };
            try
            {
                long.TryParse(_configuration["AllowedPartImageSize"], out long allowedSize);
                if (fileViewModel?.FileSize > allowedSize)
                {
                    result.Message = string.Format(FileNotification.FileSizeError, allowedSize);
                    result.StatusCode = HttpStatusCode.NotAcceptable;
                    result.Status = Status.Fail;
                    return result;
                }

                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    var updateDefinition = Builders<Material>.Update
                     .Set(x => x.Materialnumber, materialViewModel.Materialnumber)
                     .Set(x => x.Description, materialViewModel.Description)
                     .Set(x => x.ManufactorPartNumber, materialViewModel.ManufactorPartNumber)
                     .Set(x => x.ManufactorName, materialViewModel.ManufactorName)
                     .Set(x => x.Type, materialViewModel.Type)
                     .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                     .Set(x => x.ModifiedBy, emailActiveUserId);
                    _materialRepository.UpdateOne(t => t.MaterialId.Equals(ObjectId.Parse(materialViewModel.MaterialId)), updateDefinition);

                    #region Update Material Image

                    if (fileViewModel != null)
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        // insert new image
                        if (file.Content != null)
                        {
                            if (!string.IsNullOrEmpty(materialViewModel.ImageId))
                                _fileRepository.DeleteOne(t => t.FileId.Equals(ObjectId.Parse(materialViewModel.ImageId)));
                            _fileRepository.InsertOne(file);
                            var updateMaterialFileDefinition = Builders<Material>.Update
                                 .Set(x => x.ImageId, file.FileId)
                                 .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                                 .Set(x => x.ModifiedBy, emailActiveUserId);
                            _materialRepository.UpdateOne(t => t.MaterialId.Equals(ObjectId.Parse(materialViewModel.MaterialId)), updateMaterialFileDefinition);
                        }
                    }

                    #endregion


                    result.Message = MaterialNotification.Updated;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete a Material
        /// </summary>
        /// <param name="id">material id</param>
        /// <returns></returns>
        public IResult DeleteMaterial(string id)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _materialRepository.DeleteOne(t => t.MaterialId == ObjectId.Parse(id));
                result.Message = MaterialNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert Update the material overview
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public IResult ManageMaterialPartProperties(PartPropertyViewModel viewModel)
        {
            var result = new Result
            {
                Status = Status.Success
            };
            try
            {
                if (string.IsNullOrEmpty(viewModel.PartPropertyId) || viewModel.PartPropertyId == null)
                {
                    viewModel.PartPropertyId = null;
                    var partProperty = new PartProperty();
                    partProperty.MapFromViewModel(viewModel, (ClaimsIdentity)_principal.Identity);
                    partProperty.PartPropertyId = ObjectId.GenerateNewId();
                    var updateDefinition = Builders<Material>.Update.Set(x => x.ModifiedDate, GenericHelper.CurrentDate).AddToSet(t => t.PartProperties, partProperty);
                    _materialRepository.UpdateOne(t => t.MaterialId.Equals(ObjectId.Parse(viewModel.RegardingId)), updateDefinition);
                    viewModel.MapFromModel(partProperty);
                    result.Body = viewModel;
                    result.Message = MaterialNotification.OverviewCreated;
                    result.Operation = Operation.Create;
                }
                else
                {
                    var updateDefinition = Builders<Material>.Update.Set(x => x.ModifiedDate, GenericHelper.CurrentDate).Set(t => t.PartProperties[-1].PropertyName, viewModel.PropertyName).
                        Set(t => t.PartProperties[-1].PropertyValue, viewModel.PropertyValue);
                    _materialRepository.UpdateOne(
                        t => t.MaterialId.Equals(ObjectId.Parse(viewModel.RegardingId)) &&
                             t.PartProperties.Any(o => o.PartPropertyId.Equals(ObjectId.Parse(viewModel.PartPropertyId))),
                        updateDefinition);
                    result.Body = viewModel;
                    result.Message = MaterialNotification.OverviewUpdated;
                    result.Operation = Operation.Update;
                }
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        ///  Get Equipments For Material
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IResult GetEquipmentsForMaterial(string id)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var equipmentViewModels = new List<EquipmentViewModel>();
                var equipments = _equipmentRepository.Filter(t => t.Material == ObjectId.Parse(id)).ToList();
                if (equipments.Any())
                {
                    equipmentViewModels = equipments.Select(t =>
                    {
                        var equipmentViewModel = new EquipmentViewModel();
                        equipmentViewModel.MapFromModel(t);
                        if (t.TechnicalSpecifications == null || !t.TechnicalSpecifications.Any())
                            return equipmentViewModel;
                        var techSpecs = new List<TechSpecsViewModel>();
                        equipmentViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(t.TechnicalSpecifications);
                        return equipmentViewModel;
                    }).ToList();
                }
                result.Body = equipmentViewModels;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert update the technical specifications
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public IResult ManageMaterialTechnicalSpecs(TechSpecsViewModel viewModel)
        {
            var result = new Result
            {
                Status = Status.Success
            };
            try
            {

                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    if (string.IsNullOrEmpty(viewModel.TechSpecId) || viewModel.TechSpecId == null)
                    {
                        viewModel.TechSpecId = null;
                        var technicalSpecification = new TechnicalSpecification();
                        technicalSpecification.MapFromViewModel(viewModel, (ClaimsIdentity)_principal.Identity);
                        technicalSpecification.TechSpecId = ObjectId.GenerateNewId();
                        technicalSpecification.IsManuallyAdded = true;
                        var updateDefinition = Builders<Material>.Update
                            .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                            .AddToSet(t => t.TechnicalSpecifications, technicalSpecification);
                        _materialRepository.UpdateOne(t => t.MaterialId.Equals(ObjectId.Parse(viewModel.RegardingId)), updateDefinition);
                        result.Body = viewModel.MapFromModel(technicalSpecification);
                        result.Message = MaterialNotification.TechSpecCreated;
                        result.Operation = Operation.Create;
                    }
                    else
                    {
                        var updateDefinition = Builders<Material>.Update
                            .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                            .Set(x => x.ModifiedBy, emailActiveUserId)
                            .Set(t => t.TechnicalSpecifications[-1].TechSpecName, viewModel.TechSpecName)
                            .Set(t => t.TechnicalSpecifications[-1].Value, viewModel.Value)
                            .Set(t => t.TechnicalSpecifications[-1].IncludeInOverview, viewModel.IncludeInOverview);

                        _materialRepository.UpdateOne(
                            t => t.MaterialId.Equals(ObjectId.Parse(viewModel.RegardingId)) &&
                                 t.TechnicalSpecifications.Any(o => o.TechSpecId.Equals(ObjectId.Parse(viewModel.TechSpecId))),
                            updateDefinition);
                        result.Body = viewModel;
                        result.Message = MaterialNotification.TechSpecUpdated;
                        result.Operation = Operation.Update;
                    }
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert Material Request
        /// </summary>
        /// <param name="fileList"></param>
        /// <param name="materialRequestViewModel"></param>
        /// <returns></returns>
        public IResult InsertMaterialRequest(List<FileDetails> fileList, MaterialRequestViewModel materialRequestViewModel)
        {
            materialRequestViewModel.RequestId = null;
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var materialRequest = new Request();
                materialRequest.MapFromViewModel(materialRequestViewModel, (ClaimsIdentity)_principal.Identity);

                materialRequest.MailUsers = new List<MailUserDetails>();
                if (materialRequestViewModel.MailUsers != null && materialRequestViewModel.MailUsers.Any())
                {
                    materialRequest.MailUsers = materialRequestViewModel.MailUsers.Select(user =>
                    {
                        var mailUser = new MailUserDetails();
                        mailUser.MapFromViewModel(user);
                        return mailUser;
                    }).ToList();
                }

                if (!string.IsNullOrEmpty(materialRequestViewModel.RegardingId))
                {
                    materialRequest.RegardingId = ObjectId.Parse(materialRequestViewModel.RegardingId);
                }
                _requestRepository.InsertOne(materialRequest);

                if (fileList != null && fileList.Any())
                {
                    materialRequest.Files = fileList.Select(fileViewModel =>
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        _fileRepository.InsertOne(file);
                        return file.FileId;
                    }).ToList();
                }

                var updateDefinition = Builders<Request>.Update.Set(t => t.Files, materialRequest.Files);
                _requestRepository.UpdateOne(t => t.RequestId.Equals(materialRequest.RequestId), updateDefinition);

                if (materialRequest.Files != null && materialRequest.Files.Any())
                {
                    materialRequestViewModel.Files = new List<string>();
                    materialRequest.Files.ForEach(x => materialRequestViewModel.Files.Add(x.ToString()));
                }
                result.Body = materialRequestViewModel.MapFromModel(materialRequest);
                result.Message = RequestNotification.Created;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete All Material.
        /// </summary>
        /// <returns></returns>
        public IResult DeleteAllMaterial()
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _materialRepository.DeleteMany();
                result.Message = MaterialNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete Material Techincal Specification.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="techSpecId"></param>
        /// <returns></returns>
        public IResult DeleteMaterialTechnicalSpecification(string id, string techSpecId)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    var material = _materialRepository.GetOne(t => t.MaterialId == ObjectId.Parse(id));
                    if (material != null)
                    {
                        var updateDefinition = Builders<Material>.Update
                         .PullFilter(t => t.TechnicalSpecifications, y => y.TechSpecId.Equals(ObjectId.Parse(techSpecId)))
                         .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                         .Set(x => x.ModifiedBy, emailActiveUserId);

                        _materialRepository.UpdateOne(t => t.MaterialId.Equals(ObjectId.Parse(id)),
                               updateDefinition);
                        result.Message = MaterialNotification.Deleted;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }


            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }



        /// <summary>
        /// Total (the total number of materials in the database)
        /// </summary>
        /// <returns></returns>
        public int CountNumMaterials()
        {
            var count = _materialRepository.Query.Count(t => true);
            return count;
        }


        /// <summary>
        /// the number of materials with at least one element in the property Documents
        /// </summary>
        /// <returns></returns>
        public int CountNumMaterialsWithDocument()
        {
            var count = _materialRepository.Query.Count(t => t.Documents.Any());
            return count;
        }

        /// <summary>
        /// the number of materials that have been created during past 7 days by createdDate
        /// </summary>
        /// <returns></returns>
        public int CountNumMaterialsAddedLastWeek()
        {
            return (int)_materialRepository.GetRecentAddedMaterials();
        }

        /// <summary>
        /// Get List of Materials for corresponding identifiers.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        public List<MaterialViewModel> GetMaterialsByIds(SearchSortModel search, List<ObjectId> ids)
        {
            var materialViewModels = new List<MaterialViewModel>();
            if (ids != null && ids.Any())
            {
                if (string.IsNullOrEmpty(search.SortColumn))
                {
                    search.SortColumn = Constants.CreatedDate;
                }
                var allMaterial = _materialRepository.GetAllMaterials(search, false, ids);
                materialViewModels = materialViewModels.MapFromModel<Material, MaterialViewModel>(allMaterial);
            }
            return materialViewModels;
        }

        /// <summary>
        /// Get materials by ids
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public List<MaterialViewModel> GetMaterialsByIds(List<ObjectId> ids)
        {
            var materialViewModels = new List<MaterialViewModel>();
            if (ids != null && ids.Any())
            {
                var allMaterial = _materialRepository.Query.Where(t => ids.Contains(t.MaterialId)).ToList();
                materialViewModels = materialViewModels.MapFromModel<Material, MaterialViewModel>(allMaterial);
            }
            return materialViewModels;
        }


        /// <summary>
        /// Get list of material number that are already present in db
        /// </summary>
        /// <param name="materialNums"></param>
        /// <returns></returns>
        public List<string> GetAlreadyAddedMaterialNumber(List<string> materialNums)
        {
            var materialNumDb = new List<string>();
            var data = _materialRepository.Query.Where(t => materialNums.Contains(t.Materialnumber)).ToList();
            if (data.Any())
            {
                materialNumDb = data.Select(t => t.Materialnumber).ToList();
            }
            return materialNumDb;
        }

        /// <summary>
        /// Import material data
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        public IResult ImportMaterials(IFormFile uploadFile)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                if (System.IO.Path.GetExtension(uploadFile.FileName) == ".csv")
                {
                    var dataToImport = new CsvFileReader().ProcessFile(uploadFile.OpenReadStream());
                    var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                    if (!string.IsNullOrEmpty(emailActiveUserId))
                    {
                        var isEdit = false;
                        var mainFields = new List<string> { "Material", "Description", "Manufacturer Part no", "Manufacturer Name", "Manufacturer Serial Number", "Owner", "Name of field", "Type" };

                        if (CsvVerified(dataToImport.Headers, mainFields, ref result))
                        {
                            // 1. Map the incoming data to models
                            var mappedMaterialModels =
                                MapImportedMaterialToModel(dataToImport, mainFields, emailActiveUserId, ref isEdit);

                            // 2. Check for material numbers in db if same file is again uploaded
                            var materialInDb = new List<string>();
                            var materialFromImport = !isEdit
                                ? mappedMaterialModels.Where(e => !e.IsDeleted).Select(e => e.Materialnumber).Distinct().ToList()
                               : mappedMaterialModels.Where(e => e.MaterialId == ObjectId.Empty && !e.IsDeleted).Select(e => e.Materialnumber).Distinct().ToList();
                            if (materialFromImport.Any())
                            {
                                // materials found from db
                                var materialFound = _materialRepository.Query.Where(e => materialFromImport.Contains(e.Materialnumber)).ToList();
                                if (materialFound.Any())
                                {
                                    materialInDb = materialFound.Select(t => t.Materialnumber).ToList();
                                }
                            }

                            // 3. Get the list of new materials as whole.
                            var materialsForInsert = new List<Material>();
                            var materialsForUpdate = new List<Material>();
                            var materialsForDeletion = new List<ObjectId>();
                            if (mappedMaterialModels.Any())
                            {
                                materialsForDeletion = mappedMaterialModels.Where(e => e.IsDeleted).Select(t => t.MaterialId).ToList();
                                materialsForInsert = mappedMaterialModels.Where(t => t.MaterialId == ObjectId.Empty && !materialInDb.Contains(t.Materialnumber) && !t.IsDeleted)
                                    .ToList();
                                materialsForUpdate = mappedMaterialModels.Where(t => t.MaterialId != ObjectId.Empty && !t.IsDeleted)
                                    .ToList();
                            }

                            // 4. Insert the material in bulk to db except the already exist
                            if (materialsForInsert.Any())
                                _materialRepository.InsertMany(materialsForInsert);

                            // 5. Update the Already exist materials
                            if (materialsForUpdate.Any())
                            {
                                materialsForUpdate.ForEach(m =>
                                {
                                    var updateDefinition = Builders<Material>.Update
                                        .Set(x => x.Materialnumber, m.Materialnumber)
                                        .Set(x => x.Description, m.Description)
                                        .Set(x => x.ManufactorPartNumber, m.ManufactorPartNumber)
                                        .Set(x => x.ManufactorSerialNumber, m.ManufactorSerialNumber)
                                        .Set(x => x.ManufactorName, m.ManufactorName)
                                        .Set(x => x.Owner, m.Owner)
                                        .Set(x => x.Location, m.Location)
                                        .Set(x => x.Type, m.Type)
                                        .Set(x => x.ModifiedDate, m.ModifiedDate)
                                        .Set(x => x.ModifiedBy, m.ModifiedBy)
                                        .Set(x => x.TechnicalSpecifications, m.TechnicalSpecifications);
                                    _materialRepository.UpdateOne(t => t.MaterialId.Equals(m.MaterialId), updateDefinition);
                                });
                            }

                            // Delete materials
                            if (materialsForDeletion.Any())
                            {
                                _materialRepository.DeleteMany(t => materialsForDeletion.Contains(t.MaterialId));
                            }

                            // 6. Map the result with viewmodel
                            var importResult = new ImportResultViewModel
                            {
                                InsertedCount = materialsForInsert.Count,
                                UpdatedCount = materialsForUpdate.Count,
                                RecordsReUploaded = materialInDb.Count,
                                ErrorCount = dataToImport.Errors.Count,
                                RecordsForDeletion = materialsForDeletion.Count,
                                Errors = dataToImport.Errors
                            };

                            result.Body = importResult;
                            result.StatusCode = HttpStatusCode.OK;
                        }
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = CommonErrorMessages.MailNotFound;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.UnSupportedFileFormat;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableFormat;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get all materials for export
        /// </summary>
        /// <returns></returns>
        public IResult ExportMaterial()
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var materials = _materialRepository.Query.OrderByDescending(t => t.CreatedDate)
                    .ThenByDescending(t => t.ModifiedDate).ToList();
                var dataForExport = new List<MaterialExportViewModel>();
                if (materials.Any())
                {
                    dataForExport = materials.Select(m =>
                    {
                        var materialExportViewModel = new MaterialExportViewModel();
                        materialExportViewModel.MapFromModel(m);
                        if (m.TechnicalSpecifications == null || !m.TechnicalSpecifications.Any())
                            return materialExportViewModel;
                        var techSpecs = new List<TechSpecsViewModel>();
                        materialExportViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(m.TechnicalSpecifications);
                        return materialExportViewModel;

                    }).ToList();
                }
                result.Body = dataForExport;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;

        }

        /// <summary>
        /// Get the distinct column values
        /// </summary>
        /// <param name="searchSort"></param>
        /// <returns></returns>
        public IResult GetDistinctMaterialColumnValues(SearchSortModel searchSort)
        {
            if (string.IsNullOrEmpty(searchSort.SortColumn))
            {
                searchSort.SortColumn = Constants.CreatedDate;
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var data = _materialRepository.GetFilteredSingleColumnValues(searchSort);
                result.Body = data;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        #region Private Method

        /// <summary>
        /// Verify the uploaded csv
        /// </summary>
        /// <param name="headers"></param>
        /// <param name="mainFields"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        private bool CsvVerified(List<string> headers, List<string> mainFields, ref Result result)
        {
            var returnVal = true;
            if (headers.Any())
            {
                if (mainFields.Count != headers.Count(mainFields.Contains))
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.CsvReqHeadersNotPresent;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                    returnVal = false;
                }
            }
            else
            {
                result.Status = Status.Fail;
                result.Message = CommonErrorMessages.CsvHeadersNotPresent;
                result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                returnVal = false;
            }
            return returnVal;
        }

        /// <summary>
        /// Map imported row key value pair to material model
        /// </summary>
        /// <param name="dataToImport"></param>
        /// <param name="mainFields"></param>
        /// <param name="emailActiveUserId"></param>
        /// <param name="isEdit"></param>
        /// <returns></returns>
        private List<Material> MapImportedMaterialToModel(ImportedData dataToImport, List<string> mainFields, string emailActiveUserId, ref bool isEdit)
        {
            List<string> techSpecFields = null;
            if (dataToImport.Headers.Any())
            {
                // 1. Check for Id field for add/Edit
                isEdit = dataToImport.Headers.Any(t => t.Equals("Id"));
                if (isEdit)
                    mainFields.Add("Id");

                if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                    mainFields.Add("IsDeleted");

                techSpecFields = dataToImport.Headers.Where(t => !mainFields.Contains(t)).ToList();
            }

            var materials = new List<Material>();
            if (dataToImport.RowData != null && dataToImport.RowData.Any())
            {
                var edit = isEdit;
                var rowNum = 0;
                materials = dataToImport.RowData.Select(row =>
                {
                    rowNum++;
                    try
                    {
                        var materialModel = new Material
                        {
                            Materialnumber = row[mainFields[0]],
                            Description = row[mainFields[1]],
                            ManufactorPartNumber = row[mainFields[2]],
                            ManufactorName = row[mainFields[3]],
                            ManufactorSerialNumber = row[mainFields[4]],
                            Owner = row[mainFields[5]],
                            Location = row[mainFields[6]],
                            Type = row[mainFields[7]],
                            TechnicalSpecifications = MapImportedTechSpecs(row, techSpecFields, emailActiveUserId, GenericHelper.CurrentDate),
                            IsActive = true,
                            PartProperties = new List<PartProperty>(),
                            Documents = new List<ObjectId>(),
                            CreatedBy = emailActiveUserId,
                            CreatedDate = GenericHelper.CurrentDate,
                            ModifiedBy = emailActiveUserId,
                            ModifiedDate = GenericHelper.CurrentDate,

                        };
                        if (edit)
                        {
                            if (!string.IsNullOrEmpty(row[mainFields[8]]))
                                materialModel.MaterialId = ObjectId.Parse(row[mainFields[8]]);
                            if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                                if (!string.IsNullOrEmpty(row[mainFields[9]]))
                                    materialModel.IsDeleted = Convert.ToBoolean(row[mainFields[9]]);
                        }
                        else
                        {
                            if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                                if (!string.IsNullOrEmpty(row[mainFields[8]]))
                                    materialModel.IsDeleted = Convert.ToBoolean(row[mainFields[8]]);
                        }
                        return materialModel;
                    }
                    catch (Exception ex)
                    {
                        dataToImport.Errors.Add(new DataParsingError
                        {
                            ErrorRow = rowNum,
                            Row = string.Format(CommonErrorMessages.DataMappingErrorAtRow, rowNum),
                            ErrorString = string.Format(CommonErrorMessages.DataMappingError, ex.Message)
                        });
                    }
                    return null;
                }).ToList();
            }
            return materials.Where(m => m != null).ToList();
        }

        /// <summary>
        /// Prepare the technical specifications from imported data
        /// </summary>
        /// <param name="rowData"></param>
        /// <param name="techSpecFields"></param>
        /// <param name="emailActiveUserId"></param>
        /// <param name="addedDate"></param>
        /// <returns></returns>
        private List<TechnicalSpecification> MapImportedTechSpecs(IReadOnlyDictionary<string, string> rowData, List<string> techSpecFields, string emailActiveUserId, DateTime addedDate)
        {
            var fixedTechSpecs = new List<string>
            {
                "Gross Weight",
                "Size/dimens.",
                "Net Weight",
               "Maint. Concept",
                "Catalog profile",
                "Long text",
                "Alternative part no",
                "Alternative part no - description",
                "Alternative part no - info",
                "SubQuip Rate",
                "Equipment Category",
                "Equipment group",
                "Generation",
                "Number in storage",
                "Spare part"
            };

            var techSpecs = new List<TechnicalSpecification>();
            if (techSpecFields.Any())
            {
                techSpecs.AddRange(techSpecFields.Select(techSpecField =>
                new TechnicalSpecification
                {
                    TechSpecId = ObjectId.GenerateNewId(),
                    TechSpecName = techSpecField,
                    Value = rowData[techSpecField],
                    CreatedDate = addedDate,
                    CreatedBy = emailActiveUserId,
                    ModifiedDate = addedDate,
                    ModifiedBy = emailActiveUserId,
                    IsActive = true,
                    IncludeInOverview = false,
                    IsManuallyAdded = !fixedTechSpecs.Any(t => t.Equals(techSpecField))
                }));
            }
            return techSpecs;
        }

        #endregion
    }
}
