﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using SubQuip.Common.Extensions;
using SubQuip.Data.Interfaces;
using SubQuip.Entity.Models;
using SubQuip.ViewModel.Equipment;
using System.Linq;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.PartProperties;
using SubQuip.ViewModel.TechSpecs;
using Microsoft.Extensions.Configuration;
using SubQuip.Common.Importer;
using SubQuip.ViewModel.Statistics;
using SubQuip.ViewModel.Request;
using System.Net;
using Microsoft.AspNetCore.Http;
using SubQuip.ViewModel.ImportViewModel;

namespace SubQuip.Business.Logic
{
    public class EquipmentService : IEquipmentService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly IEquipmentRepository _equipmentRepository;
        private readonly IMaterialRepository _materialRepository;
        private readonly IPartnerRepository _partnerRepository;
        private readonly IRequestRepository _requestRepository;
        private readonly IFileRepository _fileRepository;
        private readonly IFileService _fileManagerService;
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the EquipmentManagerService
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="equipmentRepository"></param>
        /// <param name="materialRepository"></param>
        /// <param name="fileRepository"></param>
        /// <param name="fileManagerService"></param>
        /// <param name="configuration"></param>
        /// <param name="partnerRepository"></param>
        /// <param name="requestRepository"></param>
        public EquipmentService(IPrincipal principal, IEquipmentRepository equipmentRepository, IMaterialRepository materialRepository,
            IFileRepository fileRepository, IFileService fileManagerService, IConfiguration configuration,
            IPartnerRepository partnerRepository, IRequestRepository requestRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _equipmentRepository = equipmentRepository;
            _materialRepository = materialRepository;
            _fileRepository = fileRepository;
            _fileManagerService = fileManagerService;
            _configuration = configuration;
            _partnerRepository = partnerRepository;
            _requestRepository = requestRepository;
        }

        /// <summary>
        /// Get All Equipment Info
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IResult GetAllEquipments(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = Constants.CreatedDate;
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var equipmentViewModels = new List<EquipmentViewModel>();
                var equipments = _equipmentRepository.GetAllEquipments(search, search.IstechSpecRequired);
                if (equipments != null && equipments.Any())
                {
                    if (!search.IstechSpecRequired)
                    {
                        search.SearchResult = equipmentViewModels.MapFromModel<Equipment, EquipmentViewModel>(equipments);
                    }
                    else
                    {
                        equipmentViewModels = equipments.Select(t =>
                           {
                               var equipmentViewModel = new EquipmentViewModel();
                               equipmentViewModel.MapFromModel(t);
                               if (t.TechnicalSpecifications == null || !t.TechnicalSpecifications.Any())
                                   return equipmentViewModel;
                               var techSpecs = new List<TechSpecsViewModel>();
                               equipmentViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(t.TechnicalSpecifications);
                               return equipmentViewModel;
                           }).ToList();
                        search.SearchResult = equipmentViewModels;
                    }
                }
                else
                {
                    search.SearchResult = equipmentViewModels;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = search;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get a single Equipment
        /// </summary>
        /// <param name="id">equipment id</param>
        /// <returns></returns>
        public IResult GetEquipmentById(string id)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    var equipment = _equipmentRepository.GetOne(t => t.EquipmentId == ObjectId.Parse(id));
                    if (equipment != null)
                    {
                        var equipmentViewModel = new EquipmentViewModel();
                        equipmentViewModel.MapFromModel(equipment);
                        if (equipment.ImageId != null)
                        {
                            var file = _fileRepository.GetOne(t => t.FileId == equipment.ImageId);
                            equipmentViewModel.ImageId = equipment.ImageId.ToString();
                            equipmentViewModel.ImageContent = (file != null) ? file.Content : string.Empty;
                        }
                        if (equipment.PartProperties != null && equipment.PartProperties.Any())
                        {
                            var overviews = new List<PartPropertyViewModel>();
                            equipmentViewModel.PartProperties = overviews.MapFromModel<PartProperty, PartPropertyViewModel>(equipment.PartProperties);
                        }
                        if (equipment.Documents != null && equipment.Documents.Any())
                        {
                            equipmentViewModel.Documents = _fileManagerService.GetFiles(equipment.Documents);
                        }
                        if (equipment.TechnicalSpecifications != null && equipment.TechnicalSpecifications.Any())
                        {
                            var techSpecs = new List<TechSpecsViewModel>();
                            equipmentViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(equipment.TechnicalSpecifications);
                        }
                        result.Body = equipmentViewModel;
                    }
                    else
                    {
                        result.Message = EquipmentNotification.EquipmentNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.NoIdentifierProvided;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.NoIdentifierProvided;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert Equipment
        /// </summary>
        /// <param name="equipmentViewModel"></param>
        /// <param name="fileViewModel"></param>
        /// <returns></returns>
        public IResult InsertEquipment(EquipmentViewModel equipmentViewModel, FileDetails fileViewModel)
        {
            equipmentViewModel.EquipmentId = null;
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                long.TryParse(_configuration["AllowedPartImageSize"], out long allowedSize);
                if (fileViewModel?.FileSize > allowedSize)
                {
                    result.Message = string.Format(FileNotification.FileSizeError, allowedSize);
                    result.StatusCode = HttpStatusCode.NotAcceptable;
                    result.Status = Status.Fail;
                    return result;
                }

                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    if (!string.IsNullOrEmpty(equipmentViewModel.Material))
                    {
                        var equipment = new Equipment();
                        equipment.MapFromViewModel(equipmentViewModel, (ClaimsIdentity)_principal.Identity);
                        equipment.PartProperties = new List<PartProperty>();
                        equipment.Documents = new List<ObjectId>();
                        equipment.TechnicalSpecifications = new List<TechnicalSpecification>();
                        _equipmentRepository.InsertOne(equipment);

                        var resultView = new EquipmentViewModel();
                        resultView.MapFromModel(equipment);

                        #region Insert Equipment Image

                        if (fileViewModel != null)
                        {
                            var file = new File();
                            file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                            // insert new image
                            if (file.Content != null)
                            {
                                _fileRepository.InsertOne(file);
                                var updateEquipmentFileDefinition = Builders<Equipment>.Update
                                     .Set(x => x.ImageId, file.FileId)
                                     .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                                     .Set(x => x.ModifiedBy, emailActiveUserId);
                                _equipmentRepository.UpdateOne(t => t.EquipmentId.Equals(ObjectId.Parse(resultView.EquipmentId)),
                                    updateEquipmentFileDefinition);
                            }
                        }

                        #endregion


                        result.Body = resultView;
                        result.Message = EquipmentNotification.Created;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = EquipmentNotification.MaterialNotProvided;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.NoIdentifierProvided;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Save Equipment Document
        /// </summary>
        /// <param name="fileList"></param>
        /// <param name="document"></param>
        /// <returns></returns>
        public IResult SaveEquipmentDocument(List<FileDetails> fileList, DocumentViewModel document)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var documentIds = new List<ObjectId>();
                var fileDetails = new List<FileDetails>();
                if (fileList != null && fileList.Any())
                {
                    fileList.ForEach(fileViewModel =>
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        _fileRepository.InsertOne(file);
                        documentIds.Add(file.FileId);

                        var fileDetail = new FileDetails();
                        fileDetail.MapFromModel(file);
                        fileDetail.Content = string.Empty;
                        fileDetails.Add(fileDetail);

                    });
                }

                var updateDefinition = Builders<Equipment>.Update.Set(t => t.ModifiedDate, GenericHelper.CurrentDate).AddToSetEach(t => t.Documents, documentIds);
                _equipmentRepository.UpdateOne(t => t.EquipmentId.Equals(ObjectId.Parse(document.RegardingId)), updateDefinition);
                result.Operation = Operation.Create;
                result.Message = EquipmentNotification.DocumentCreated;
                result.Body = fileDetails;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Update Equipment
        /// </summary>
        /// <param name="equipmentViewModel"></param>
        /// <param name="fileViewModel"></param>
        /// <returns></returns>
        public IResult UpdateEquipment(EquipmentViewModel equipmentViewModel, FileDetails fileViewModel)
        {
            var result = new Result
            {
                Operation = Operation.Update,
                Status = Status.Success
            };
            try
            {
                long.TryParse(_configuration["AllowedPartImageSize"], out long allowedSize);
                if (fileViewModel?.FileSize > allowedSize)
                {
                    result.Message = string.Format(FileNotification.FileSizeError, allowedSize);
                    result.StatusCode = HttpStatusCode.NotAcceptable;
                    result.Status = Status.Fail;
                    return result;
                }

                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    var updateDefinition = Builders<Equipment>.Update
                  .Set(x => x.EquipmentNumber, equipmentViewModel.EquipmentNumber)
                  .Set(x => x.ManufactorName, equipmentViewModel.ManufactorName)
                  .Set(x => x.ManufactorPartNumber, equipmentViewModel.ManufactorPartNumber)
                  .Set(x => x.ManufactorSerialNumber, equipmentViewModel.ManufactorSerialNumber)
                  .Set(x => x.Vendor, equipmentViewModel.Vendor)
                  .Set(x => x.VendorPartNumber, equipmentViewModel.VendorPartNumber)
                  .Set(x => x.VendorSerialNumber, equipmentViewModel.VendorSerialNumber)
                  .Set(x => x.Location, equipmentViewModel.Location)
                  .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                  .Set(x => x.Material, ObjectId.Parse(equipmentViewModel.Material))
                  .Set(x => x.ModifiedBy, emailActiveUserId);

                    _equipmentRepository.UpdateOne(t => t.EquipmentId == ObjectId.Parse(equipmentViewModel.EquipmentId), updateDefinition);


                    #region Update Equipment Image

                    if (fileViewModel != null)
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        // insert new image
                        if (file.Content != null)
                        {
                            if (!string.IsNullOrEmpty(equipmentViewModel.ImageId))
                                _fileRepository.DeleteOne(t => t.FileId.Equals(ObjectId.Parse(equipmentViewModel.ImageId)));
                            _fileRepository.InsertOne(file);
                            var updateEquipmentFileDefinition = Builders<Equipment>.Update
                                 .Set(x => x.ImageId, file.FileId)
                                 .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                                 .Set(x => x.ModifiedBy, emailActiveUserId);
                            _equipmentRepository.UpdateOne(t => t.EquipmentId.Equals(ObjectId.Parse(equipmentViewModel.EquipmentId)), updateEquipmentFileDefinition);
                        }
                    }

                    #endregion

                    result.Message = EquipmentNotification.Updated;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert Update the equipment overview
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public IResult ManageEquipmentPartProperties(PartPropertyViewModel viewModel)
        {
            var result = new Result
            {
                Status = Status.Success
            };
            try
            {
                if (string.IsNullOrEmpty(viewModel.PartPropertyId) || viewModel.PartPropertyId == null)
                {
                    viewModel.PartPropertyId = null;
                    var partProperty = new PartProperty();
                    partProperty.MapFromViewModel(viewModel, (ClaimsIdentity)_principal.Identity);
                    partProperty.PartPropertyId = ObjectId.GenerateNewId();
                    var updateDefinition = Builders<Equipment>.Update.Set(t => t.ModifiedDate, GenericHelper.CurrentDate).AddToSet(t => t.PartProperties, partProperty);
                    _equipmentRepository.UpdateOne(t => t.EquipmentId.Equals(ObjectId.Parse(viewModel.RegardingId)), updateDefinition);
                    viewModel.MapFromModel(partProperty);
                    result.Body = viewModel;
                    result.Message = EquipmentNotification.OverviewCreated;
                    result.Operation = Operation.Create;
                }
                else
                {
                    var updateDefinition = Builders<Equipment>.Update.Set(t => t.ModifiedDate, GenericHelper.CurrentDate).Set(t => t.PartProperties[-1].PropertyName, viewModel.PropertyName).
                        Set(t => t.PartProperties[-1].PropertyValue, viewModel.PropertyValue);
                    _equipmentRepository.UpdateOne(
                        t => t.EquipmentId.Equals(ObjectId.Parse(viewModel.RegardingId)) &&
                             t.PartProperties.Any(o => o.PartPropertyId.Equals(ObjectId.Parse(viewModel.PartPropertyId))),
                        updateDefinition);
                    result.Body = viewModel;
                    result.Message = EquipmentNotification.OverviewUpdated;
                    result.Operation = Operation.Update;
                    result.StatusCode = HttpStatusCode.OK;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert update the technical specifications
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public IResult ManageEquipmentTechnicalSpecs(TechSpecsViewModel viewModel)
        {
            var result = new Result
            {
                Status = Status.Success
            };
            try
            {
                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    if (string.IsNullOrEmpty(viewModel.TechSpecId) || viewModel.TechSpecId == null)
                    {
                        viewModel.TechSpecId = null;
                        var technicalSpecification = new TechnicalSpecification();
                        technicalSpecification.MapFromViewModel(viewModel, (ClaimsIdentity)_principal.Identity);
                        technicalSpecification.TechSpecId = ObjectId.GenerateNewId();
                        technicalSpecification.IsManuallyAdded = true;
                        var updateDefinition = Builders<Equipment>.Update.Set(t => t.ModifiedDate, GenericHelper.CurrentDate).AddToSet(t => t.TechnicalSpecifications, technicalSpecification);
                        _equipmentRepository.UpdateOne(t => t.EquipmentId.Equals(ObjectId.Parse(viewModel.RegardingId)), updateDefinition);
                        result.Body = viewModel.MapFromModel(technicalSpecification);
                        result.Message = EquipmentNotification.TechSpecCreated;
                        result.Operation = Operation.Create;
                    }
                    else
                    {
                        var updateDefinition = Builders<Equipment>.Update
                            .Set(t => t.ModifiedDate, GenericHelper.CurrentDate)
                            .Set(x => x.ModifiedBy, emailActiveUserId)
                            .Set(t => t.TechnicalSpecifications[-1].TechSpecName, viewModel.TechSpecName)
                            .Set(t => t.TechnicalSpecifications[-1].Value, viewModel.Value)
                            .Set(t => t.TechnicalSpecifications[-1].IncludeInOverview, viewModel.IncludeInOverview);

                        _equipmentRepository.UpdateOne(
                            t => t.EquipmentId.Equals(ObjectId.Parse(viewModel.RegardingId)) &&
                                 t.TechnicalSpecifications.Any(o => o.TechSpecId.Equals(ObjectId.Parse(viewModel.TechSpecId))),
                            updateDefinition);
                        result.Body = viewModel;
                        result.Message = EquipmentNotification.TechSpecUpdated;
                        result.Operation = Operation.Update;
                    }
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete a single Equipment
        /// </summary>
        /// <param name="id">equipment id</param>
        /// <returns></returns>
        public IResult DeleteEquipment(string id)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _equipmentRepository.DeleteOne(t => t.EquipmentId == ObjectId.Parse(id));
                result.Message = EquipmentNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete All Equipments.
        /// </summary>
        /// <returns></returns>
        public IResult DeleteAllEquipment()
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _equipmentRepository.DeleteMany();
                result.Message = EquipmentNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }


        /// <summary>
        /// Delete Equipment Techincal Specification.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="techSpecId"></param>
        /// <returns></returns>
        public IResult DeleteEquipmentTechnicalSpecification(string id, string techSpecId)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    var equipment = _equipmentRepository.GetOne(t => t.EquipmentId == ObjectId.Parse(id));
                    if (equipment != null)
                    {
                        var updateDefinition = Builders<Equipment>.Update
                         .PullFilter(t => t.TechnicalSpecifications, y => y.TechSpecId.Equals(ObjectId.Parse(techSpecId)))
                         .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                         .Set(x => x.ModifiedBy, emailActiveUserId);

                        _equipmentRepository.UpdateOne(t => t.EquipmentId.Equals(ObjectId.Parse(id)),
                               updateDefinition);
                        result.Message = EquipmentNotification.Deleted;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }


        /// <summary>
        /// Insert Equipment Request
        /// </summary>
        /// <param name="fileList"></param>
        /// <param name="equipmentRequestViewModel"></param>
        /// <returns></returns>
        public IResult InsertEquipmentRequest(List<FileDetails> fileList, EquipmentRequestViewModel equipmentRequestViewModel)
        {
            equipmentRequestViewModel.RequestId = null;
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var equipmentRequest = new Request();
                equipmentRequest.MapFromViewModel(equipmentRequestViewModel, (ClaimsIdentity)_principal.Identity);

                equipmentRequest.MailUsers = new List<MailUserDetails>();
                if (equipmentRequestViewModel.MailUsers != null && equipmentRequestViewModel.MailUsers.Any())
                {
                    equipmentRequest.MailUsers = equipmentRequestViewModel.MailUsers.Select(user =>
                    {
                        var mailUser = new MailUserDetails();
                        mailUser.MapFromViewModel(user);
                        return mailUser;
                    }).ToList();
                }

                if (!string.IsNullOrEmpty(equipmentRequestViewModel.RegardingId))
                {
                    equipmentRequest.RegardingId = ObjectId.Parse(equipmentRequestViewModel.RegardingId);
                }
                _requestRepository.InsertOne(equipmentRequest);

                if (fileList != null && fileList.Any())
                {
                    equipmentRequest.Files = fileList.Select(fileViewModel =>
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        _fileRepository.InsertOne(file);
                        return file.FileId;
                    }).ToList();
                }

                var updateDefinition = Builders<Request>.Update.Set(t => t.Files, equipmentRequest.Files);
                _requestRepository.UpdateOne(t => t.RequestId.Equals(equipmentRequest.RequestId), updateDefinition);

                if (equipmentRequest.Files != null && equipmentRequest.Files.Any())
                {
                    equipmentRequestViewModel.Files = new List<string>();
                    equipmentRequest.Files.ForEach(x => equipmentRequestViewModel.Files.Add(x.ToString()));
                }
                result.Body = equipmentRequestViewModel.MapFromModel(equipmentRequest);
                result.Message = RequestNotification.Created;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Equipment stats
        /// </summary>
        /// <returns></returns>
        public IResult EquipmentStats()
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var equipmentStats = new EquipmentStats();
                {
                    // Total (the total number of equipments in the database)
                    equipmentStats.NumEquipments = _equipmentRepository.Query.Count();

                    // the number of equipments with at least one element in the property Documents
                    equipmentStats.NumEquipmentsWithDocumentation = _equipmentRepository.Query.Count(t => t.Documents.Any());

                    // the number of equipments that has the Owner fiel as the logged in user or her company
                    var partnerStatList = new List<PartnerStatistics>();
                    var partners = _partnerRepository.Query.ToList();
                    partners.ForEach(t =>
                    {
                        var partnerStat = new PartnerStatistics
                        {
                            Name = t.Name,
                            Email = t.Email,
                            EquipmentCount = _equipmentRepository.Query.Count(x => (x.Owner.Contains(t.Name)))
                        };
                        partnerStatList.Add(partnerStat);
                    });
                    equipmentStats.NumEquipmentForPartner = partnerStatList;

                    // the number of equipments that have been created the previous 7 days by cretaedDate
                    equipmentStats.NumRecentEquipments = (int)_equipmentRepository.GetRecentAddedEquipment();
                }
                result.Body = equipmentStats;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Get List of Equipments for corresponding identifiers.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        public List<EquipmentViewModel> GetEquipmentsByIds(SearchSortModel search, List<ObjectId> ids)
        {
            var equipmentViewModels = new List<EquipmentViewModel>();
            if (ids != null && ids.Any())
            {
                if (string.IsNullOrEmpty(search.SortColumn))
                {
                    search.SortColumn = Constants.CreatedDate;
                }
                var allEquipments = _equipmentRepository.GetAllEquipments(search, false, ids);
                equipmentViewModels = equipmentViewModels.MapFromModel<Equipment, EquipmentViewModel>(allEquipments);
            }
            return equipmentViewModels;
        }

        /// <summary>
        /// Get List of Equipments for corresponding identifiers.
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="techSpecsRequired"></param>
        /// <returns></returns>
        public List<EquipmentViewModel> GetEquipmentsByIds(List<ObjectId> ids, bool techSpecsRequired = false)
        {
            var equipmentViewModels = new List<EquipmentViewModel>();
            if (ids != null && ids.Any())
            {
                var allEquipments = _equipmentRepository.Query.Where(t => ids.Contains(t.EquipmentId)).ToList();
                if (techSpecsRequired)
                {
                    //fetching technical specifications also
                    equipmentViewModels = allEquipments.Select(t =>
                    {
                        var equipmentViewModel = new EquipmentViewModel();
                        equipmentViewModel.MapFromModel(t);
                        if (t.TechnicalSpecifications == null || !t.TechnicalSpecifications.Any())
                            return equipmentViewModel;
                        var techSpecs = new List<TechSpecsViewModel>();
                        equipmentViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(t.TechnicalSpecifications);
                        return equipmentViewModel;
                    }).ToList();
                }
                else
                {
                    equipmentViewModels = equipmentViewModels.MapFromModel<Equipment, EquipmentViewModel>(allEquipments);
                }
            }
            return equipmentViewModels;
        }

        /// <summary>
        /// Import equipment data
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        public IResult ImportEquipments(IFormFile uploadFile)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                if (System.IO.Path.GetExtension(uploadFile.FileName) == ".csv")
                {
                    var dataToImport = new CsvFileReader().ProcessFile(uploadFile.OpenReadStream());
                    var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                    if (!string.IsNullOrEmpty(emailActiveUserId))
                    {
                        var isEdit = false;
                        var mainFields = new List<string> { "Equipment No_Owner", "Material", "Description", "Manufacturer Part no", "Manufacturer Name", "Manufacturer Serial Number", "Owner", "Name of field", "Vendor", "Vendor PartNo", "Vendor SerialNo" };
                        if (CsvVerified(dataToImport.Headers, mainFields, ref result))
                        {
                            var equipmentsForInsert = new List<Equipment>();

                            // 1. Map the incoming data to models
                            var mappedEqupmentModels = MapImportedEquipmentToModel(dataToImport, mainFields, emailActiveUserId, ref isEdit);

                            // 2. Check for equipment numbers in db if same file is again uploaded
                            var equipmentInDb = new List<string>();
                            var equipsFromImport = !isEdit
                                ? mappedEqupmentModels.Where(e => !e.IsDeleted).Select(e => e.EquipmentNumber).Distinct().ToList()
                                : mappedEqupmentModels.Where(e => e.EquipmentId == ObjectId.Empty && !e.IsDeleted).Select(e => e.EquipmentNumber).Distinct().ToList();

                            if (equipsFromImport.Any())
                            {
                                // Equipments found from db
                                var equipmentFound = _equipmentRepository.Query.Where(e => equipsFromImport.Contains(e.EquipmentNumber)).ToList();
                                if (equipmentFound.Any())
                                {
                                    equipmentInDb = equipmentFound.Select(t => t.EquipmentNumber).ToList();
                                }
                            }

                            // 3. Get the list of distinct material number. Either from equipment found from db or from imported
                            var materialNumsToLook = equipmentInDb.Any()
                                ? mappedEqupmentModels.Where(e => !equipmentInDb.Contains(e.EquipmentNumber)).Select(e => e.MaterialNumber).Distinct().ToList()
                                : mappedEqupmentModels.Select(e => e.MaterialNumber).Distinct().ToList();

                            // 4. Get material for corresponding to material numbers.
                            var matrialsFromDb = new List<Material>();
                            if (materialNumsToLook.Any())
                            {
                                matrialsFromDb = _materialRepository.Query.Where(m => materialNumsToLook.Contains(m.Materialnumber)).ToList();
                            }

                            // 5. Now replace/assign material id against material number.
                            if (matrialsFromDb.Any())
                            {
                                matrialsFromDb.ForEach(m =>
                                {
                                    var equipmentT = mappedEqupmentModels.Where(e => e.MaterialNumber == m.Materialnumber).ToList();
                                    equipmentT.ForEach(e => e.Material = m.MaterialId);
                                });
                            }

                            // 6. Get the list of new/edit equipmenst as whole.
                            var equipmentsForUpdate = new List<Equipment>();
                            var equipmentsWithNotMappedMaterial = new List<Equipment>();
                            var equipmentsForDeletion = new List<ObjectId>();
                            if (mappedEqupmentModels.Any())
                            {
                                equipmentsForDeletion = mappedEqupmentModels.Where(e => e.IsDeleted).Select(t => t.EquipmentId).ToList();
                                equipmentsForInsert = mappedEqupmentModels.Where(e => e.EquipmentId == ObjectId.Empty && e.Material != ObjectId.Empty && !equipmentInDb.Contains(e.EquipmentNumber) && !e.IsDeleted).ToList();
                                equipmentsForUpdate = mappedEqupmentModels.Where(e => e.EquipmentId != ObjectId.Empty && e.Material != ObjectId.Empty && !e.IsDeleted).ToList();
                                equipmentsWithNotMappedMaterial = mappedEqupmentModels.Where(e => e.Material == ObjectId.Empty && !equipmentInDb.Contains(e.EquipmentNumber) && !e.IsDeleted).ToList();
                            }

                            // 7. Insert into DB
                            if (equipmentsForInsert.Any())
                                _equipmentRepository.InsertMany(equipmentsForInsert);

                            // 8. Update the Already exist equipments
                            if (equipmentsForUpdate.Any())
                            {
                                equipmentsForUpdate.ForEach(m =>
                                {
                                    var updateDefinition = Builders<Equipment>.Update
                                        .Set(x => x.EquipmentNumber, m.EquipmentNumber)
                                        .Set(x => x.Material, m.Material)
                                        .Set(x => x.Description, m.Description)
                                        .Set(x => x.ManufactorPartNumber, m.ManufactorPartNumber)
                                        .Set(x => x.ManufactorSerialNumber, m.ManufactorSerialNumber)
                                        .Set(x => x.ManufactorName, m.ManufactorName)
                                        .Set(x => x.Vendor, m.Vendor)
                                        .Set(x => x.VendorPartNumber, m.VendorPartNumber)
                                        .Set(x => x.VendorSerialNumber, m.VendorSerialNumber)
                                        .Set(x => x.Owner, m.Owner)
                                        .Set(x => x.Location, m.Location)
                                        .Set(x => x.ModifiedDate, m.ModifiedDate)
                                        .Set(x => x.ModifiedBy, m.ModifiedBy)
                                        .Set(x => x.TechnicalSpecifications, m.TechnicalSpecifications);
                                    _equipmentRepository.UpdateOne(t => t.EquipmentId.Equals(m.EquipmentId), updateDefinition);
                                });
                            }

                            // Delete equipments
                            if (equipmentsForDeletion.Any())
                            {
                                _equipmentRepository.DeleteMany(t => equipmentsForDeletion.Contains(t.EquipmentId));
                            }

                            // 9. Prepare import result overview
                            var importResult = new EquipmentImportResult
                            {
                                InsertedCount = equipmentsForInsert.Count,
                                UpdatedCount = equipmentsForUpdate.Count,
                                RecordsReUploaded = equipmentInDb.Count,
                                RecordsWithInvalidMaterial = equipmentsWithNotMappedMaterial.Count,
                                ErrorCount = dataToImport.Errors.Count,
                                RecordsForDeletion = equipmentsForDeletion.Count,
                                Errors = dataToImport.Errors
                            };
                            result.Message = "Import Summary";
                            result.Body = importResult;
                            result.StatusCode = HttpStatusCode.OK;
                        }
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = CommonErrorMessages.MailNotFound;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.UnSupportedFileFormat;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableFormat;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get all equipments for export
        /// </summary>
        /// <returns></returns>
        public IResult ExportEquipment()
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var equipments = _equipmentRepository.Query.OrderByDescending(t => t.CreatedDate)
                    .ThenByDescending(t => t.ModifiedDate).ToList();
                var dataForExport = new List<EquipmentExportViewModel>();
                if (equipments.Any())
                {
                    dataForExport = equipments.Select(e =>
                    {
                        var equipmentExportViewModel = new EquipmentExportViewModel();
                        equipmentExportViewModel.MapFromModel(e);
                        if (e.TechnicalSpecifications == null || !e.TechnicalSpecifications.Any())
                            return equipmentExportViewModel;
                        var techSpecs = new List<TechSpecsViewModel>();
                        equipmentExportViewModel.TechnicalSpecifications = techSpecs.MapFromModel<TechnicalSpecification, TechSpecsViewModel>(e.TechnicalSpecifications);
                        return equipmentExportViewModel;

                    }).ToList();
                }
                result.Body = dataForExport;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;

        }

        /// <summary>
        /// Get the distinct column values
        /// </summary>
        /// <param name="searchSort"></param>
        /// <returns></returns>
        public IResult GetDistinctEquipmentColumnValues(SearchSortModel searchSort)
        {
            if (string.IsNullOrEmpty(searchSort.SortColumn))
            {
                searchSort.SortColumn = Constants.CreatedDate;
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var data = _equipmentRepository.GetFilteredSingleColumnValues(searchSort);
                result.Body = data;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        #region Private methods

        /// <summary>
        /// Verify the uploaded csv
        /// </summary>
        /// <param name="headers"></param>
        /// <param name="mainFields"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        private bool CsvVerified(List<string> headers, List<string> mainFields, ref Result result)
        {
            var returnVal = true;
            if (headers.Any())
            {
                if (mainFields.Count != headers.Count(mainFields.Contains))
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.CsvReqHeadersNotPresent;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                    returnVal = false;
                }
            }
            else
            {
                result.Status = Status.Fail;
                result.Message = CommonErrorMessages.CsvHeadersNotPresent;
                result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                returnVal = false;
            }
            return returnVal;
        }

        /// <summary>
        /// Map imported data to equipment model
        /// </summary>
        /// <param name="dataToImport"></param>
        /// <param name="mainFields"></param>
        /// <param name="emailActiveUserId"></param>
        /// <param name="isEdit"></param>
        /// <returns></returns>
        private List<Equipment> MapImportedEquipmentToModel(ImportedData dataToImport, List<string> mainFields, string emailActiveUserId, ref bool isEdit)
        {
            List<string> techSpecFields = null;
            if (dataToImport.Headers.Any())
            {
                // 1. Check for Id field for add/Edit
                isEdit = dataToImport.Headers.Any(t => t.Equals("Id"));
                if (isEdit)
                    mainFields.Add("Id");

                if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                    mainFields.Add("IsDeleted");

                techSpecFields = dataToImport.Headers.Where(t => !mainFields.Contains(t)).ToList();
            }

            var equipments = new List<Equipment>();
            if (dataToImport.RowData != null && dataToImport.RowData.Any())
            {
                var edit = isEdit;
                var rowNum = 0;
                equipments = dataToImport.RowData.Select(row =>
                {
                    rowNum++;
                    try
                    {
                        var equipmentModel = new Equipment
                        {
                            // { "Equipment No_Owner", "Material", "Description", "Manufacturer Part no", "Manufacturer Name", "Manufacturer Serial Number", "Owner", "Name of field", "Vendor", "Vendor PartNo", "Vendor SerialNo" };
                            EquipmentNumber = row[mainFields[0]],
                            MaterialNumber = row[mainFields[1]], // it is the lookup identifer for material id from material
                            Description = row[mainFields[2]],
                            ManufactorPartNumber = row[mainFields[3]],
                            ManufactorName = row[mainFields[4]],
                            ManufactorSerialNumber = row[mainFields[5]],
                            Owner = row[mainFields[6]],
                            Location = row[mainFields[7]],
                            Vendor = row[mainFields[8]],
                            VendorPartNumber = row[mainFields[9]],
                            VendorSerialNumber = row[mainFields[10]],
                            IsActive = true,
                            TechnicalSpecifications = MapImportedTechSpecs(row, techSpecFields, emailActiveUserId, GenericHelper.CurrentDate),
                            PartProperties = new List<PartProperty>(),
                            Documents = new List<ObjectId>(),
                            CreatedBy = emailActiveUserId,
                            CreatedDate = GenericHelper.CurrentDate,
                            ModifiedBy = emailActiveUserId,
                            ModifiedDate = GenericHelper.CurrentDate
                        };
                        if (edit)
                        {
                            if (!string.IsNullOrEmpty(row[mainFields[11]]))
                                equipmentModel.EquipmentId = ObjectId.Parse(row[mainFields[11]]);
                            if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                                if (!string.IsNullOrEmpty(row[mainFields[12]]))
                                    equipmentModel.IsDeleted = Convert.ToBoolean(row[mainFields[12]]);
                        }
                        else
                        {
                            if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                                if (!string.IsNullOrEmpty(row[mainFields[11]]))
                                    equipmentModel.IsDeleted = Convert.ToBoolean(row[mainFields[11]]);
                        }
                        return equipmentModel;
                    }
                    catch (Exception ex)
                    {
                        dataToImport.Errors.Add(new DataParsingError
                        {
                            ErrorRow = rowNum,
                            Row = "Error while data mapping at row : " + rowNum,
                            ErrorString = "Data Mapping : Error while Data mapping. System : " + ex.Message
                        });
                    }
                    return null;
                }).ToList();
            }
            return equipments.Where(e => e != null).ToList();
        }

        /// <summary>
        /// Prepare the technical specifications from imported data
        /// </summary>
        /// <param name="rowData"></param>
        /// <param name="techSpecFields"></param>
        /// <param name="emailActiveUserId"></param>
        /// <param name="addedDate"></param>
        /// <returns></returns>
        private List<TechnicalSpecification> MapImportedTechSpecs(IReadOnlyDictionary<string, string> rowData, List<string> techSpecFields, string emailActiveUserId, DateTime addedDate)
        {
            var fixedTechSpecs = new List<string>
            {
                "Normal locaton",
                "Gross Weight",
                "Net Weight",
                "Size/dimens.",
                "Maint. Concept",
                "Catalog profile",
                "Long text",
                "Alternative part no",
                "Alternative part no - description",
                "Alternative part no - info",
                "SubQuip Rate",
                "Equipment Category",
                "Equipment group",
                "Generation"
            };

            var techSpecs = new List<TechnicalSpecification>();
            if (techSpecFields.Any())
            {
                techSpecs.AddRange(techSpecFields.Select(techSpecField =>
                    new TechnicalSpecification
                    {
                        TechSpecId = ObjectId.GenerateNewId(),
                        TechSpecName = techSpecField,
                        Value = rowData[techSpecField],
                        CreatedDate = addedDate,
                        CreatedBy = emailActiveUserId,
                        ModifiedDate = addedDate,
                        ModifiedBy = emailActiveUserId,
                        IsActive = true,
                        IncludeInOverview = false,
                        IsManuallyAdded = !fixedTechSpecs.Any(t => t.Equals(techSpecField))
                    }));
            }
            return techSpecs;
        }

        #endregion
    }
}
