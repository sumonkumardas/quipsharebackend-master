﻿using SubQuip.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.Common.CommonData;
using SubQuip.ViewModel.Partner;
using SubQuip.Common.Enums;
using SubQuip.Entity.Models;
using SubQuip.Common.Extensions;
using System.Security.Principal;
using System.Security.Claims;
using SubQuip.Data.Interfaces;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Http;
using SubQuip.Common.Importer;
using SubQuip.ViewModel.ImportViewModel;
using SubQuip.ViewModel.Licence;

namespace SubQuip.Business.Logic
{
    public class PartnerService : IPartnerService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly IPartnerRepository _partnerRepository;

        /// <summary>
        ///  Initializes a new instance of the PartnerManagerService
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="partnerRepository"></param>
        public PartnerService(IPrincipal principal, IPartnerRepository partnerRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _partnerRepository = partnerRepository;
        }

        /// <summary>
        /// Get All Partners.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IResult GetAllPartners(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = Constants.CreatedDate;
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var partnerViewModels = new List<PartnerViewModel>();
                var allPartner = _partnerRepository.GetAllPartners(search);
                if (allPartner != null && allPartner.Any())
                {
                    search.SearchResult = partnerViewModels.MapFromModel<Partner, PartnerViewModel>(allPartner);
                }
                else
                {
                    search.SearchResult = partnerViewModels;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = search;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get Specific Partner.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IResult GetPartnerById(string id)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    var partner = _partnerRepository.GetOne(t => t.PartnerId == ObjectId.Parse(id));
                    if (partner != null)
                    {
                        var partnerViewModel = new PartnerViewModel();
                        result.Body = partnerViewModel.MapFromModel(partner);
                    }
                    else
                    {
                        result.Message = PartnerNotification.PartnerNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.NoIdentifierProvided;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.NoIdentifierProvided;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert Partner
        /// </summary>
        /// <param name="partnerViewModel"></param>
        /// <returns></returns>
        public IResult Create(PartnerViewModel partnerViewModel)
        {
            partnerViewModel.PartnerId = null;
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var partner = new Partner();
                partner.MapFromViewModel(partnerViewModel, (ClaimsIdentity)_principal.Identity);
                _partnerRepository.InsertOne(partner);
                result.Body = partnerViewModel.MapFromModel(partner);
                result.Message = PartnerNotification.Created;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Update Partner
        /// </summary>
        /// <param name="partnerViewModel"></param>
        /// <returns></returns>
        public IResult Update(PartnerViewModel partnerViewModel)
        {
            var result = new Result
            {
                Operation = Operation.Update,
                Status = Status.Success
            };
            try
            {
                var updateDefinition = Builders<Partner>.Update
                    .Set(x => x.Name, partnerViewModel.Name)
                    .Set(x => x.Email, partnerViewModel.Email)
                    .Set(x => x.ModifiedDate, GenericHelper.CurrentDate);

                _partnerRepository.UpdateOne(t => t.PartnerId == ObjectId.Parse(partnerViewModel.PartnerId), updateDefinition);
                result.Message = PartnerNotification.Updated;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete a Partner.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IResult Delete(string id)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _partnerRepository.DeleteOne(t => t.PartnerId == ObjectId.Parse(id));
                result.Message = PartnerNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete All Partners.
        /// </summary>
        /// <returns></returns>
        public IResult DeleteAllPartners()
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _partnerRepository.DeleteMany();
                result.Message = PartnerNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Import licence
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        public IResult ImportPartners(IFormFile uploadFile)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                if (System.IO.Path.GetExtension(uploadFile.FileName) == ".csv")
                {
                    var dataToImport = new CsvFileReader().ProcessFile(uploadFile.OpenReadStream());
                    var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                    if (!string.IsNullOrEmpty(emailActiveUserId))
                    {
                        var isEdit = false;
                        var mainFields = new List<string> { "Name", "Email" };

                        if (CsvVerified(dataToImport.Headers, mainFields, ref result))
                        {
                            // 1. Map the incoming data to models
                            var mappedModels =
                                MapImportedToModel(dataToImport, mainFields, emailActiveUserId, ref isEdit);

                            // 2. Check for partners in db if same file is again uploaded
                            var partnerInDb = new List<string>();
                            var partnerFromImport = !isEdit
                                ? mappedModels.Where(e => !e.IsDeleted).Select(e => e.Email).Distinct().ToList()
                                : mappedModels.Where(e => e.PartnerId == ObjectId.Empty && !e.IsDeleted).Select(e => e.Email).Distinct().ToList();
                            if (partnerFromImport.Any())
                            {
                                // partner found from db
                                var partnerFound = _partnerRepository.Query.Where(e => partnerFromImport.Contains(e.Email)).ToList();
                                if (partnerFound.Any())
                                {
                                    partnerInDb = partnerFound.Select(t => t.Email).ToList();
                                }
                            }

                            // 3. Get the list of new partner as whole.
                            var partnerForInsert = new List<Partner>();
                            var partnersForUpdate = new List<Partner>();
                            var partnersForDeletion = new List<ObjectId>();
                            if (mappedModels.Any())
                            {
                                partnersForDeletion = mappedModels.Where(e => e.IsDeleted).Select(t => t.PartnerId).ToList();
                                partnerForInsert = mappedModels.Where(t => t.PartnerId == ObjectId.Empty && !partnerInDb.Contains(t.Email) && !t.IsDeleted)
                                    .ToList();
                                partnersForUpdate = mappedModels.Where(t => t.PartnerId != ObjectId.Empty && !t.IsDeleted)
                                    .ToList();
                            }

                            // 4. Insert the partner in bulk to db except the already exist
                            if (partnerForInsert.Any())
                                _partnerRepository.InsertMany(partnerForInsert);

                            // 5. Update the Already exist partner
                            if (partnersForUpdate.Any())
                            {
                                partnersForUpdate.ForEach(m =>
                                {
                                    var updateDefinition = Builders<Partner>.Update
                                        .Set(x => x.Email, m.Email)
                                        .Set(x => x.Name, m.Name)
                                        .Set(x => x.ModifiedDate, m.ModifiedDate)
                                        .Set(x => x.ModifiedBy, m.ModifiedBy);
                                    _partnerRepository.UpdateOne(t => t.PartnerId.Equals(m.PartnerId), updateDefinition);
                                });
                            }

                            // Delete partners
                            if (partnersForDeletion.Any())
                            {
                                _partnerRepository.DeleteMany(t => partnersForDeletion.Contains(t.PartnerId));
                            }

                            // 6. Map the result with viewmodel
                            var importResult = new ImportResultViewModel
                            {
                                InsertedCount = partnerForInsert.Count,
                                UpdatedCount = partnersForUpdate.Count,
                                RecordsReUploaded = partnerInDb.Count,
                                ErrorCount = dataToImport.Errors.Count,
                                RecordsForDeletion = partnersForDeletion.Count,
                                Errors = dataToImport.Errors
                            };

                            result.Body = importResult;
                            result.StatusCode = HttpStatusCode.OK;
                        }
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = CommonErrorMessages.MailNotFound;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.UnSupportedFileFormat;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableFormat;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Export Licence
        /// </summary>
        /// <returns></returns>
        public IResult ExportPartners()
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var partners = _partnerRepository.Query.OrderByDescending(t => t.CreatedDate)
                    .ThenByDescending(t => t.ModifiedDate).ToList();
                var dataForExport = new List<PartnerExportViewModel>();
                if (partners.Any())
                {
                    dataForExport = partners.Select(m =>
                    {
                        var partnerExportViewModel = new PartnerExportViewModel();
                        partnerExportViewModel.MapFromModel(m);
                        return partnerExportViewModel;
                    }).ToList();
                }
                result.Body = dataForExport;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        #region Private Method

        /// <summary>
        /// Verify the uploaded csv
        /// </summary>
        /// <param name="headers"></param>
        /// <param name="mainFields"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        private bool CsvVerified(List<string> headers, List<string> mainFields, ref Result result)
        {
            var returnVal = true;
            if (headers.Any())
            {
                if (mainFields.Count != headers.Count(mainFields.Contains))
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.CsvReqHeadersNotPresent;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                    returnVal = false;
                }
            }
            else
            {
                result.Status = Status.Fail;
                result.Message = CommonErrorMessages.CsvHeadersNotPresent;
                result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                returnVal = false;
            }
            return returnVal;
        }

        /// <summary>
        /// Map imported row key value pair to material model
        /// </summary>
        /// <param name="dataToImport"></param>
        /// <param name="mainFields"></param>
        /// <param name="emailActiveUserId"></param>
        /// <param name="isEdit"></param>
        /// <returns></returns>
        private List<Partner> MapImportedToModel(ImportedData dataToImport, List<string> mainFields, string emailActiveUserId, ref bool isEdit)
        {
            if (dataToImport.Headers.Any())
            {
                // 1. Check for Id field for add/Edit
                isEdit = dataToImport.Headers.Any(t => t.Equals("Id"));
                if (isEdit)
                {
                    mainFields.Add("Id");
                    if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                        mainFields.Add("IsDeleted");
                }
            }

            var partners = new List<Partner>();
            if (dataToImport.RowData != null && dataToImport.RowData.Any())
            {
                var edit = isEdit;
                var rowNum = 0;
                partners = dataToImport.RowData.Select(row =>
                {
                    rowNum++;
                    try
                    {
                        var partnerModel = new Partner
                        {
                            Name = row[mainFields[0]],
                            Email = row[mainFields[1]],
                            IsActive = true,
                            CreatedBy = emailActiveUserId,
                            CreatedDate = GenericHelper.CurrentDate,
                            ModifiedBy = emailActiveUserId,
                            ModifiedDate = GenericHelper.CurrentDate
                        };
                        if (edit)
                        {
                            if (!string.IsNullOrEmpty(row[mainFields[2]]))
                                partnerModel.PartnerId = ObjectId.Parse(row[mainFields[2]]);
                            if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                                if (!string.IsNullOrEmpty(row[mainFields[3]]))
                                    partnerModel.IsDeleted = Convert.ToBoolean(row[mainFields[3]]);
                        }
                        return partnerModel;
                    }
                    catch (Exception ex)
                    {
                        dataToImport.Errors.Add(new DataParsingError
                        {
                            ErrorRow = rowNum,
                            Row = string.Format(CommonErrorMessages.DataMappingErrorAtRow, rowNum),
                            ErrorString = string.Format(CommonErrorMessages.DataMappingError, ex.Message)
                        });
                    }
                    return null;
                }).ToList();
            }
            return partners.Where(m => m != null).ToList();
        }

        #endregion

    }
}
