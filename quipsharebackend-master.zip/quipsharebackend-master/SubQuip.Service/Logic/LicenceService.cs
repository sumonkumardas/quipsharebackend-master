﻿using SubQuip.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.Common.CommonData;
using SubQuip.Data.Interfaces;
using SubQuip.Common.Enums;
using System.Linq;
using SubQuip.Common.Extensions;
using SubQuip.Entity.Models;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using Microsoft.AspNetCore.Http;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Common.Importer;
using SubQuip.ViewModel.ImportViewModel;
using SubQuip.ViewModel.Licence;
using SubQuip.ViewModel.Material;

namespace SubQuip.Business.Logic
{
    public class LicenceService : ILicenceService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly ILicenceRepository _licenceRepository;

        /// <summary>
        /// Initializes a new instance of the LicenceManagerService.
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="licenceRepository"></param>
        public LicenceService(IPrincipal principal, ILicenceRepository licenceRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _licenceRepository = licenceRepository;
        }

        /// <summary>
        /// Get all Licence.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IResult GetAllLicence(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = "CreatedDate";
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var licenceViewModels = new List<LicenceViewModel>();
                var licences = _licenceRepository.GetAllLicence(search);
                if (licences != null && licences.Any())
                {
                    search.SearchResult = licenceViewModels.MapFromModel<Licence, LicenceViewModel>(licences);
                }
                else
                {
                    search.SearchResult = licenceViewModels;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = search;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Import licence
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        public IResult ImportLicences(IFormFile uploadFile)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                if (System.IO.Path.GetExtension(uploadFile.FileName) == ".csv")
                {
                    var dataToImport = new CsvFileReader().ProcessFile(uploadFile.OpenReadStream());
                    var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                    if (!string.IsNullOrEmpty(emailActiveUserId))
                    {
                        var isEdit = false;
                        var mainFields = new List<string> { "LicenceNumber" };

                        if (CsvVerified(dataToImport.Headers, mainFields, ref result))
                        {
                            // 1. Map the incoming data to models
                            var mappedModels =
                                MapImportedToModel(dataToImport, mainFields, emailActiveUserId, ref isEdit);

                            // 2. Check for licence in db if same file is again uploaded
                            var licenceInDb = new List<string>();
                            var licenceFromImport = !isEdit
                                ? mappedModels.Where(e => !e.IsDeleted).Select(e => e.LicenceNumber).Distinct().ToList()
                                : mappedModels.Where(e => e.LicenceId == ObjectId.Empty && !e.IsDeleted).Select(e => e.LicenceNumber).Distinct().ToList();
                            if (licenceFromImport.Any())
                            {
                                // licence found from db
                                var licenceFound = _licenceRepository.Query.Where(e => licenceFromImport.Contains(e.LicenceNumber)).ToList();
                                if (licenceFound.Any())
                                {
                                    licenceInDb = licenceFound.Select(t => t.LicenceNumber).ToList();
                                }
                            }

                            // 3. Get the list of new licence as whole.
                            var licencesForInsert = new List<Licence>();
                            var licencesForUpdate = new List<Licence>();
                            var licencesForDeletion = new List<ObjectId>();
                            if (mappedModels.Any())
                            {
                                licencesForDeletion = mappedModels.Where(e => e.IsDeleted).Select(t => t.LicenceId).ToList();
                                licencesForInsert = mappedModels.Where(t => t.LicenceId == ObjectId.Empty && !licenceInDb.Contains(t.LicenceNumber) && !t.IsDeleted)
                                    .ToList();
                                licencesForUpdate = mappedModels.Where(t => t.LicenceId != ObjectId.Empty && !t.IsDeleted)
                                    .ToList();
                            }

                            // 4. Insert the licence in bulk to db except the already exist
                            if (licencesForInsert.Any())
                                _licenceRepository.InsertMany(licencesForInsert);

                            // 5. Update the Already exist licence
                            if (licencesForUpdate.Any())
                            {
                                licencesForUpdate.ForEach(m =>
                                {
                                    var updateDefinition = Builders<Licence>.Update
                                        .Set(x => x.LicenceNumber, m.LicenceNumber)
                                        .Set(x => x.ModifiedDate, m.ModifiedDate)
                                        .Set(x => x.ModifiedBy, m.ModifiedBy);
                                    _licenceRepository.UpdateOne(t => t.LicenceId.Equals(m.LicenceId), updateDefinition);
                                });
                            }

                            // Delete Licence
                            if (licencesForDeletion.Any())
                            {
                                _licenceRepository.DeleteMany(t => licencesForDeletion.Contains(t.LicenceId));
                            }

                            // 6. Map the result with viewmodel
                            var importResult = new ImportResultViewModel
                            {
                                InsertedCount = licencesForInsert.Count,
                                UpdatedCount = licencesForUpdate.Count,
                                RecordsReUploaded = licenceInDb.Count,
                                ErrorCount = dataToImport.Errors.Count,
                                RecordsForDeletion = licencesForDeletion.Count,
                                Errors = dataToImport.Errors
                            };

                            result.Body = importResult;
                            result.StatusCode = HttpStatusCode.OK;
                        }
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = CommonErrorMessages.MailNotFound;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.UnSupportedFileFormat;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableFormat;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Export Licence
        /// </summary>
        /// <returns></returns>
        public IResult ExportLicence()
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var licences = _licenceRepository.Query.OrderByDescending(t => t.CreatedDate)
                    .ThenByDescending(t => t.ModifiedDate).ToList();
                var dataForExport = new List<LicenceExportViewModel>();
                if (licences.Any())
                {
                    dataForExport = licences.Select(m =>
                    {
                        var licenceExportViewModel = new LicenceExportViewModel();
                        licenceExportViewModel.MapFromModel(m);
                        return licenceExportViewModel;
                    }).ToList();
                }
                result.Body = dataForExport;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        #region Private Method

        /// <summary>
        /// Verify the uploaded csv
        /// </summary>
        /// <param name="headers"></param>
        /// <param name="mainFields"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        private bool CsvVerified(List<string> headers, List<string> mainFields, ref Result result)
        {
            var returnVal = true;
            if (headers.Any())
            {
                if (mainFields.Count != headers.Count(mainFields.Contains))
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.CsvReqHeadersNotPresent;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                    returnVal = false;
                }
            }
            else
            {
                result.Status = Status.Fail;
                result.Message = CommonErrorMessages.CsvHeadersNotPresent;
                result.StatusCode = (HttpStatusCode)CustomStatusCode.UnAcceptableData;
                returnVal = false;
            }
            return returnVal;
        }

        /// <summary>
        /// Map imported row key value pair to material model
        /// </summary>
        /// <param name="dataToImport"></param>
        /// <param name="mainFields"></param>
        /// <param name="emailActiveUserId"></param>
        /// <param name="isEdit"></param>
        /// <returns></returns>
        private List<Licence> MapImportedToModel(ImportedData dataToImport, List<string> mainFields, string emailActiveUserId, ref bool isEdit)
        {
            if (dataToImport.Headers.Any())
            {
                // 1. Check for Id field for add/Edit
                isEdit = dataToImport.Headers.Any(t => t.Equals("Id"));
                if (isEdit)
                {
                    mainFields.Add("Id");
                    if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                        mainFields.Add("IsDeleted");
                }
            }

            var licences = new List<Licence>();
            if (dataToImport.RowData != null && dataToImport.RowData.Any())
            {
                var edit = isEdit;
                var rowNum = 0;
                licences = dataToImport.RowData.Select(row =>
                {
                    rowNum++;
                    try
                    {
                        var licenceModel = new Licence
                        {
                            LicenceNumber = row[mainFields[0]],
                            IsActive = true,
                            CreatedBy = emailActiveUserId,
                            CreatedDate = GenericHelper.CurrentDate,
                            ModifiedBy = emailActiveUserId,
                            ModifiedDate = GenericHelper.CurrentDate
                        };
                        if (edit)
                        {
                            if (!string.IsNullOrEmpty(row[mainFields[1]]))
                                licenceModel.LicenceId = ObjectId.Parse(row[mainFields[1]]);
                            if (dataToImport.Headers.Any(t => t.Equals("IsDeleted")))
                                if (!string.IsNullOrEmpty(row[mainFields[2]]))
                                    licenceModel.IsDeleted = Convert.ToBoolean(row[mainFields[2]]);
                        }
                        return licenceModel;
                    }
                    catch (Exception ex)
                    {
                        dataToImport.Errors.Add(new DataParsingError
                        {
                            ErrorRow = rowNum,
                            Row = string.Format(CommonErrorMessages.DataMappingErrorAtRow, rowNum),
                            ErrorString = string.Format(CommonErrorMessages.DataMappingError, ex.Message)
                        });
                    }
                    return null;
                }).ToList();
            }
            return licences.Where(m => m != null).ToList();
        }

        #endregion
    }
}
