﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Business.Interfaces;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;
using SubQuip.Common.Extensions;
using SubQuip.Data.Interfaces;
using SubQuip.Entity.Models;
using SubQuip.Entity.Models.BillOfMaterials;
using SubQuip.ViewModel.BillOfMaterial;
using SubQuip.ViewModel.Equipment;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SubQuip.ViewModel.Material;
using SubQuip.ViewModel.Request;
using System.Net;
using SubQuip.ViewModel.Statistics;
using System.Threading.Tasks;
using MongoDB.Driver.Linq;

namespace SubQuip.Business.Logic
{
    public class BillOfMaterialService : IBillOfMaterialService
    {
        private readonly IConfiguration _configuration;
        private readonly ClaimsPrincipal _principal;
        private readonly IBillOfMaterialRepository _bomRepository;
        private readonly IFileRepository _fileRepository;
        private readonly IGraphRepository _graphRepository;
        private readonly IRequestRepository _requestRepository;
        private readonly IMaterialService _materialManager;
        private readonly IEquipmentService _equipmentManager;

        /// <summary>
        /// Initializes a new instance of the BillOfMaterialsManagerService
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="bomRepository"></param>
        /// <param name="configuration"></param>
        /// <param name="fileRepository"></param>
        /// <param name="graphRepository"></param>
        /// <param name="requestRepository"></param>
        /// <param name="materialManager"></param>
        /// <param name="equipmentManager"></param>
        public BillOfMaterialService(IPrincipal principal, IBillOfMaterialRepository bomRepository, IConfiguration configuration,
            IFileRepository fileRepository, IGraphRepository graphRepository, IRequestRepository requestRepository, IMaterialService materialManager,
            IEquipmentService equipmentManager)
        {
            _principal = principal as ClaimsPrincipal;
            _bomRepository = bomRepository;
            _configuration = configuration;
            _fileRepository = fileRepository;
            _graphRepository = graphRepository;
            _requestRepository = requestRepository;
            _materialManager = materialManager;
            _equipmentManager = equipmentManager;
        }

        /// <summary>
        /// Get Bill Of Material For Particular User.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public async Task<IResult> GetBillOfMaterialsForUser(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = Constants.CreatedDate;
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var userid = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(userid))
                {
                    var bomViewModels = await GetSearchedBom(search, userid);
                    if (!bomViewModels.Any())
                    {
                        result.Message = CommonErrorMessages.NoResultFound;
                    }
                    search.SearchResult = bomViewModels;
                    result.Body = search;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get list of bom's viewmodel for logged user
        /// </summary>
        /// <param name="search"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public async Task<List<BillOfMaterialViewModel>> GetSearchedBom(SearchSortModel search, string userid)
        {
            var bomViewModels = new List<BillOfMaterialViewModel>();

            var isAdmin = false;
            if (!string.IsNullOrEmpty(userid))
            {
                isAdmin = _configuration["AuthMethod"] == "local" || (await _graphRepository.FindExternalUser(userid)).IsAdmin;
            }
            var allBoms = _bomRepository.GetAllBillOfMaterial(search, userid, isAdmin);

            if (allBoms.Any())
            {
                bomViewModels = allBoms.Select(t =>
                 {
                     var bomViewModel = new BillOfMaterialViewModel();
                     bomViewModel.MapFromModel(t);
                     bomViewModel.TemplateId = t.TemplateId.ToString();

                     if (t.BomUser == null) return bomViewModel;
                     var bomUserViewModel = new BomUserViewModel();
                     bomViewModel.BomUser = (BomUserViewModel)bomUserViewModel.MapFromModel(t.BomUser);

                     if (t.Option == null) return bomViewModel;
                     var bomOptionViewModel = new BomOptionViewModel();
                     if (t.Option.License != null)
                     {
                         bomOptionViewModel.License = t.Option.License.ToString();
                         bomOptionViewModel.LicenseName = t.License;
                     }
                     if (t.Option.Owner != null)
                     {
                         bomOptionViewModel.Owner = t.Option.Owner.ToString();
                         bomOptionViewModel.OwnerName = t.Owner;
                     }
                     if (t.Option.Location != null)
                     {
                         bomOptionViewModel.Location = t.Option.Location.ToString();
                         bomOptionViewModel.LocationName = t.Location;
                     }
                     bomViewModel.Option = bomOptionViewModel;
                     return bomViewModel;
                 }).ToList();
            }
            return bomViewModels;
        }

        /// <summary>
        /// Get Specific Bill Of Material.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IResult GetBillOfMaterialById(string id)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    var bom = _bomRepository.GetOne(t => t.BomId == ObjectId.Parse(id));
                    if (bom != null)
                    {
                        var bomViewModel = MapBomToViewModel(bom);
                        if (bom.Image != null)
                        {
                            var file = _fileRepository.GetOne(t => t.FileId == bom.Image);
                            bomViewModel.Image = bom.Image.ToString();
                            bomViewModel.ImageContent = (file != null) ? file.Content : string.Empty;
                        }

                        result.Body = bomViewModel;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    else
                    {
                        result.Message = BomNotification.BOMNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.NoIdentifierProvided;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.NoIdentifierProvided;
                }

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get Added Items of BOM.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="bomId"></param>
        /// <returns></returns>
        public IResult GetAddedItemsOfBom(SearchSortModel search, string bomId)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                if (!string.IsNullOrEmpty(bomId))
                {
                    var bom = _bomRepository.GetChildDocument(x => x.BomId == ObjectId.Parse(bomId), "AddedItems", "BomId");
                    if (bom.AddedItems != null && bom.AddedItems.Any())
                    {
                        var item = new Item();
                        var materialIds = bom.AddedItems.Where(x => x.ItemType == BomItemType.Material).Select(x => x.RegardingId).ToList();
                        var equipmentIds = bom.AddedItems.Where(x => x.ItemType == BomItemType.Equipment).Select(x => x.RegardingId).ToList();

                        var materialList = _materialManager.GetMaterialsByIds(search, materialIds);
                        if (materialList != null && materialList.Any())
                        {
                            item.TotalMaterials = materialList.Count;
                            item.Materials = materialList;
                        }
                        var equipmentList = _equipmentManager.GetEquipmentsByIds(search, equipmentIds);
                        if (equipmentList != null && equipmentList.Any())
                        {
                            item.TotalEquipments = equipmentList.Count;
                            item.Equipments = equipmentList;
                        }
                        item.TotalItems = item.TotalEquipments + item.TotalMaterials;
                        result.Body = item;

                    }
                    else
                    {
                        result.Message = BomNotification.NoAddedItem;
                    }
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.NoIdentifierProvided;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.NoIdentifierProvided;
                }


            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get Boms of Specific Template
        /// </summary>
        /// <param name="templateId"></param>
        /// <param name="owner"></param>
        /// <param name="location"></param>
        /// <param name="license"></param>
        /// <returns></returns>
        public async Task<IResult> GetBomsForTemplate(string templateId, string owner, string location, string license)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var bomTemplate = _bomRepository.Query.FirstOrDefault(b => b.Type == BomType.Template && b.BomId == ObjectId.Parse(templateId));
                var bomTemplateViewModel = new BomTemplateViewModel();
                if (bomTemplate != null)
                {
                    bomTemplateViewModel.BomTemplateId = bomTemplate.BomId.ToString();
                    bomTemplateViewModel.BomTemplateName = bomTemplate.Name;
                    var query = (from bom in _bomRepository.Query.Where(x => x.Type == BomType.Bom)
                                 join template in _bomRepository.Query on bom.TemplateId.Value equals template.BomId
                                 join request in _requestRepository.Query on bom.BomId equals request.RegardingId.Value into multipleRequests
                                 where bom.TemplateId == ObjectId.Parse(templateId)
                                 select new
                                 {
                                     bom.BomId,
                                     bom.CreatedBy,
                                     bom.Name,
                                     bom.BomUser,
                                     multipleRequests,
                                     option = bom.Option,
                                     bom.Owner,
                                     bom.Location,
                                     bom.License
                                 });

                    if (!string.IsNullOrEmpty(location))
                    {
                        query = query.Where(x => x.Location.Contains(location));
                    }
                    if (!string.IsNullOrEmpty(owner))
                    {
                        query = query.Where(x => x.Owner.Contains(owner));
                    }
                    if (!string.IsNullOrEmpty(license))
                    {
                        query = query.Where(x => x.License.Contains(license));
                    }

                    var userid = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();

                    bool isAdmin = false;
                    if (!string.IsNullOrEmpty(userid))
                    {
                        isAdmin = _configuration["AuthMethod"] == "local" || (await _graphRepository.FindExternalUser(userid)).IsAdmin;
                    }
                    if (!isAdmin && !string.IsNullOrEmpty(userid))
                    {
                        query = query.Where(t => t.CreatedBy.ToLower().Contains(userid.ToLower()));

                    }

                    var boms = query.ToList();
                    if (boms.Any())
                    {
                        bomTemplateViewModel.bomsForTemplate = boms.Select(t =>
                        {
                            var bom = new BomsForTemplateViewModel
                            {
                                BomId = t.BomId.ToString(),
                                BomName = t.Name,
                                BomUser = MapBomUserToViewModel(t.BomUser),
                                bomLocation = t.Location,
                                bomOwner = t.Owner,
                                bomLicense = t.License
                            };

                            if (t.multipleRequests != null && t.multipleRequests.Any())
                            {
                                var orderByCreatedDate = t.multipleRequests.OrderByDescending(x => x.CreatedDate).FirstOrDefault();
                                bom.FromDate = orderByCreatedDate.FromDate;
                                bom.ToDate = orderByCreatedDate.ToDate;
                            }
                            return bom;
                        }).ToList();
                    }
                    else
                    {
                        bomTemplateViewModel.bomsForTemplate = null;
                    }
                    result.Body = bomTemplateViewModel;
                }
                else
                {
                    result.Body = CommonErrorMessages.NoResultFound;
                }
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Get All Bom Templates.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public async Task<IResult> GetBomTemplates(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = Constants.CreatedDate;
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var userid = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();

                bool isAdmin = false;
                if (!string.IsNullOrEmpty(userid))
                {
                    isAdmin = _configuration["AuthMethod"] == "local" || (await _graphRepository.FindExternalUser(userid)).IsAdmin;
                }

                var query = (from bomTemplate in _bomRepository.Query.Where(x => x.Type == BomType.Template)
                             join bom in _bomRepository.Query
                             on bomTemplate.BomId equals bom.TemplateId.Value
                             into boms

                             select new
                             {
                                 bomTemplate.BomId,
                                 bomTemplate.Name,
                                 bomTemplate.ModifiedDate,
                                 bomsCount = (!isAdmin && !string.IsNullOrEmpty(userid)) ? boms.Where(x => x.CreatedBy.ToLower() == userid.ToLower()).Count() : boms.Count()
                             }).OrderByDescending(t => t.ModifiedDate).ToList();



                if (query != null && query.Any())
                {
                    result.Body = query.Select(x => new BomTemplateViewModel
                    {
                        BomTemplateId = x.BomId.ToString(),
                        BomTemplateName = x.Name,
                        Count = x.bomsCount
                    }).ToList();
                }
                else
                {
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert Bill Of Material.
        /// </summary>
        /// <param name="bomViewModel"></param>
        /// <param name="fileViewModel"></param>
        /// <returns></returns>
        public IResult CreateBillOfMaterial(BillOfMaterialViewModel bomViewModel, FileDetails fileViewModel)
        {
            bomViewModel.BomId = null;
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                long.TryParse(_configuration["AllowedPartImageSize"], out long allowedSize);
                if (fileViewModel?.FileSize > allowedSize)
                {
                    result.Message = string.Format(FileNotification.FileSizeError, allowedSize);
                    result.StatusCode = HttpStatusCode.NotAcceptable;
                    result.Status = Status.Fail;
                    return result;
                }

                var mail = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(mail))
                {
                    if (bomViewModel.Type == BomType.Template)
                    {
                        bomViewModel.TemplateId = null;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(bomViewModel.TemplateId))
                        {
                            result.Message = BomNotification.TemplateNotFound;
                            return result;
                        }
                    }

                    var bom = MapBomToModel(bomViewModel);

                    if (_configuration["AuthMethod"] == "ad")
                    {
                        var user = _graphRepository.FindExternalUser(mail).Result;
                        var userEmail = !string.IsNullOrWhiteSpace(user.Mail) ? user.Mail : mail;
                        if (user != null)
                        {
                            bom.BomUser = new BomUser
                            {
                                FirstName = user.DisplayName,
                                LastName = user.Surname,
                                Mail = userEmail,
                                Company = user.Company
                            };
                        }
                    }
                    else
                    {
                        bom.BomUser = new BomUser
                        {
                            FirstName = "Admin",
                            LastName = "User",
                            Mail = "admin@subquip.com",
                            Company = "SubquipAdmin"
                        };
                    }

                    bom.CreatedBy = mail;
                    bom.Status = BomStatus.InProgress;
                    _bomRepository.InsertOne(bom);
                    if (fileViewModel != null)
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        _fileRepository.InsertOne(file);
                        bom.Image = file.FileId;
                        var updateDefinition = Builders<BillOfMaterial>.Update.Set(x => x.Image, bom.Image);
                        _bomRepository.UpdateOne(t => t.BomId == bom.BomId, updateDefinition);
                    }
                    result.Body = MapBomToViewModel(bom);
                    result.Message = BomNotification.Created;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Update Bill Of Material.
        /// </summary>
        /// <param name="bomViewModel"></param>
        /// <param name="fileViewModel"></param>
        /// <returns></returns>
        public IResult UpdateBillOfMaterial(BillOfMaterialViewModel bomViewModel, FileDetails fileViewModel)
        {
            var result = new Result
            {
                Operation = Operation.Update,
                Status = Status.Success
            };
            try
            {
                long.TryParse(_configuration["AllowedPartImageSize"], out long allowedSize);
                if (fileViewModel?.FileSize > allowedSize)
                {
                    result.Message = string.Format(FileNotification.FileSizeError, allowedSize);
                    result.StatusCode = HttpStatusCode.NotAcceptable;
                    result.Status = Status.Fail;
                    return result;
                }

                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    #region BOM Update
                    var bom = MapBomToModel(bomViewModel);
                    var updateDefinition = Builders<BillOfMaterial>.Update
                        .Set(x => x.Name, bom.Name)
                        .Set(x => x.Description, bom.Description)
                        .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                        .Set(x => x.Groups, bom.Groups)
                        .Set(x => x.Status, bom.Status)
                        .Set(x => x.ModifiedBy, emailActiveUserId);
                    _bomRepository.UpdateOne(t => t.BomId == ObjectId.Parse(bomViewModel.BomId), updateDefinition);
                    #endregion

                    #region Update BOM Image
                    if (fileViewModel != null)
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        if (file.Content != null)
                        {
                            if (!string.IsNullOrEmpty(bomViewModel.Image))
                                _fileRepository.DeleteOne(t => t.FileId.Equals(ObjectId.Parse(bomViewModel.Image)));
                            _fileRepository.InsertOne(file);
                            var updateBomFileDefinition = Builders<BillOfMaterial>.Update
                                 .Set(x => x.Image, file.FileId)
                                 .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                                 .Set(x => x.ModifiedBy, emailActiveUserId);
                            _bomRepository.UpdateOne(t => t.BomId.Equals(ObjectId.Parse(bomViewModel.BomId)), updateBomFileDefinition);
                        }
                    }
                    #endregion

                    result.Body = MapBomToViewModel(bom);
                    result.Message = BomNotification.Updated;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Delete Bill Of Material.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IResult DeleteBillOfMaterial(string id)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _bomRepository.DeleteOne(t => t.BomId == ObjectId.Parse(id));
                _requestRepository.DeleteMany(t => t.RegardingId == ObjectId.Parse(id));
                result.Message = BomNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        public IResult DeleteAllBillOfMaterial()
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                _bomRepository.DeleteMany();
                result.Message = BomNotification.Deleted;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Add Comment to BOM.
        /// </summary>
        /// <param name="bomCommentViewModel"></param>
        /// <returns></returns>
        public IResult SaveCommentForBOM(BomCommentViewModel bomCommentViewModel)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var bomComment = new BomComment();
                bomComment.MapFromViewModel(bomCommentViewModel, (ClaimsIdentity)_principal.Identity);
                var lstBomComments = new List<BomComment> { bomComment };
                var updateDefinition = Builders<BillOfMaterial>.Update.Set(t => t.ModifiedDate, GenericHelper.CurrentDate).AddToSet(t => t.Comments, bomComment);
                _bomRepository.UpdateOne(t => t.BomId.Equals(ObjectId.Parse(bomCommentViewModel.RegardingId)), updateDefinition);
                result.Message = BomNotification.CommentCreated;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Add Option to BOM.
        /// </summary>
        /// <param name="bomOptionViewModel"></param>
        /// <returns></returns>
        public IResult SaveOptionForBOM(BomOptionViewModel bomOptionViewModel)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                if (bomOptionViewModel != null)
                {
                    var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                    if (!string.IsNullOrEmpty(emailActiveUserId))
                    {
                        var bomOption = new BomOption();
                        if (!string.IsNullOrEmpty(bomOptionViewModel.License))
                            bomOption.License = ObjectId.Parse(bomOptionViewModel.License);

                        if (!string.IsNullOrEmpty(bomOptionViewModel.Owner))
                            bomOption.Owner = ObjectId.Parse(bomOptionViewModel.Owner);

                        if (!string.IsNullOrEmpty(bomOptionViewModel.Location))
                            bomOption.Location = ObjectId.Parse(bomOptionViewModel.Location);

                        var updateDefinition = Builders<BillOfMaterial>.Update
                            .Set(t => t.Owner, bomOptionViewModel.OwnerName)
                            .Set(t => t.Location, bomOptionViewModel.LocationName)
                            .Set(t => t.License, bomOptionViewModel.LicenseName)
                            .Set(t => t.ModifiedDate, GenericHelper.CurrentDate)
                            .Set(t => t.ModifiedBy, emailActiveUserId)
                            .Set(t => t.Option, bomOption);
                        _bomRepository.UpdateOne(t => t.BomId.Equals(ObjectId.Parse(bomOptionViewModel.RegardingId)), updateDefinition);

                        result.Message = BomNotification.OptionSaved;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = CommonErrorMessages.MailNotFound;
                        result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = BomNotification.NoOptionProvided;
                    result.StatusCode = HttpStatusCode.BadRequest;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Get Comments of Bill Of Material For Particular User.
        /// </summary>
        /// <param name="bomId"></param>
        /// <returns></returns>
        public IResult GetCommentsForBom(string bomId)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var bomComments = _bomRepository.GetCommentsForBom(bomId);

                if (bomComments != null && bomComments.Any())
                {
                    var bomCommentViewModels = bomComments.Select(t =>
                    {
                        var bomCommentViewModel = new BomCommentViewModel();
                        bomCommentViewModel.MapFromModel(t);
                        bomCommentViewModel.RegardingId = bomId;
                        return bomCommentViewModel;
                    }).ToList();

                    result.Body = bomCommentViewModels;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Message = BomNotification.CommentsNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Insert BOM Request
        /// </summary>
        /// <param name="fileList"></param>
        /// <param name="bomRequestViewModel"></param>
        /// <returns></returns>
        public IResult InsertBOMRequest(List<FileDetails> fileList, BomRequestViewModel bomRequestViewModel)
        {
            bomRequestViewModel.RequestId = null;
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var bomRequest = new Request();
                bomRequest.MapFromViewModel(bomRequestViewModel, (ClaimsIdentity)_principal.Identity);

                bomRequest.MailUsers = new List<MailUserDetails>();
                if (bomRequestViewModel.MailUsers != null && bomRequestViewModel.MailUsers.Any())
                {
                    bomRequest.MailUsers = bomRequestViewModel.MailUsers.Select(user =>
                    {
                        var mailUser = new MailUserDetails();
                        mailUser.MapFromViewModel(user);
                        return mailUser;
                    }).ToList();
                }

                if (bomRequestViewModel.BomRequestNodes != null && bomRequestViewModel.BomRequestNodes.Any())
                {
                    bomRequest.BomRequestNodes = bomRequestViewModel.BomRequestNodes.Select(t =>
                    {
                        var bomNode = new BomRequestNode();
                        bomNode.MapFromViewModel(t);
                        return bomNode;
                    }).ToList();
                }

                if (!string.IsNullOrEmpty(bomRequestViewModel.RegardingId))
                {
                    bomRequest.RegardingId = ObjectId.Parse(bomRequestViewModel.RegardingId);
                }
                _requestRepository.InsertOne(bomRequest);

                if (fileList != null && fileList.Any())
                {
                    bomRequest.Files = fileList.Select(fileViewModel =>
                    {
                        var file = new File();
                        file.MapFromViewModel(fileViewModel, (ClaimsIdentity)_principal.Identity);
                        _fileRepository.InsertOne(file);
                        return file.FileId;
                    }).ToList();
                }
                var updateDefinition = Builders<Request>.Update.Set(t => t.Files, bomRequest.Files);
                _requestRepository.UpdateOne(t => t.RequestId.Equals(bomRequest.RequestId), updateDefinition);
                if (bomRequest.Files != null && bomRequest.Files.Any())
                {
                    bomRequestViewModel.Files = new List<string>();
                    bomRequest.Files.ForEach(x => bomRequestViewModel.Files.Add(x.ToString()));
                }
                result.Body = bomRequestViewModel.MapFromModel(bomRequest);
                result.Message = RequestNotification.Created;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Add Equipment/Material To BOM.
        /// </summary>
        /// <param name="addItem"></param>
        /// <returns></returns>
        public IResult AddItemToBom(AddItemToBom addItem)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                if (addItem != null)
                {
                    var item = new AddToBom();
                    item.MapFromViewModel(addItem);
                    var bom = _bomRepository.GetOne(t => t.BomId == ObjectId.Parse(addItem.BomId));
                    if (bom != null)
                    {
                        var updateDefinition = Builders<BillOfMaterial>.Update.Set(t => t.ModifiedDate, GenericHelper.CurrentDate).AddToSet(t => t.AddedItems, item);
                        _bomRepository.UpdateOne(t => t.BomId.Equals(ObjectId.Parse(addItem.BomId)), updateDefinition);
                        result.Message = BomNotification.ItemAdded;

                    }
                    else
                    {
                        result.Message = BomNotification.BOMNotFound;
                    }
                }
                else
                {
                    result.Message = BomNotification.NoItemProvided;
                }
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
            }
            return result;
        }

        /// <summary>
        /// Bom stats
        /// </summary>
        /// <returns></returns>
        public IResult BomStats()
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var bomStats = new BomStatsViewModel();
                {
                    bomStats.NumBoms = _bomRepository.Query.Count(t => t.Type == BomType.Bom);
                    bomStats.NumBomsCompleted = _bomRepository.Query.Count(bom => bom.Type == BomType.Bom && bom.Status == BomStatus.InProgress);
                    bomStats.NumBomsCompleted = _bomRepository.Query.Count(bom => bom.Type == BomType.Bom && bom.Status == BomStatus.Completed);
                }
                result.Body = bomStats;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Get the distinct column values
        /// </summary>
        /// <param name="searchSort"></param>
        /// <returns></returns>
        public async Task<IResult> GetDistinctBomColumnValues(SearchSortModel searchSort)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var userid = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(userid))
                {
                    var isAdmin = _configuration["AuthMethod"] == "local" || (await _graphRepository.FindExternalUser(userid)).IsAdmin;
                    var data = _bomRepository.GetFilteredSingleColumnValues(searchSort, userid, isAdmin);
                    result.Body = data;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        #region Private methods for BOM model to view model

        /// <summary>
        /// Map bom model to view model
        /// </summary>
        /// <param name="bom"></param>
        /// <returns></returns>
        private BillOfMaterialViewModel MapBomToViewModel(BillOfMaterial bom)
        {
            var lstEmptyBomItems = new List<BomItemViewModel>();
            var bomViewModel = new BillOfMaterialViewModel();
            bomViewModel.MapFromModel(bom);

            if (bom.TemplateId != null)
            {
                bomViewModel.TemplateId = bom.TemplateId.ToString();
            }

            if (bom.Image != null)
            {
                bomViewModel.Image = bom.Image.ToString();
            }

            bomViewModel.BomUser = MapBomUserToViewModel(bom.BomUser);

            if (bom.Groups != null && bom.Groups.Any())
            {
                bomViewModel.Groups = new List<BomGroupViewModel>();
                bom.Groups.ForEach(t =>
                {
                    var bomGroupViewModel = MapBomGroupToViewModel(t, ref lstEmptyBomItems);
                    bomViewModel.Groups.Add(bomGroupViewModel);
                });
            }

            if (bom.Comments != null && bom.Comments.Any())
            {
                bomViewModel.Comments = bom.Comments.Select(t =>
                {
                    var bomCommentViewModel = new BomCommentViewModel();
                    bomCommentViewModel.MapFromModel(t);
                    return bomCommentViewModel;
                }).ToList();
            }

            if (bom.Option != null)
            {
                bomViewModel.Option = new BomOptionViewModel();
                if (bom.Option.License != null) { bomViewModel.Option.License = bom.Option.License.ToString(); }
                if (bom.Option.Owner != null) { bomViewModel.Option.Owner = bom.Option.Owner.ToString(); }
                if (bom.Option.Location != null) { bomViewModel.Option.Location = bom.Option.Location.ToString(); }
            }

            #region Get/Set detail of Equipment/Material

            if (lstEmptyBomItems.Any())
            {
                var materialIds = lstEmptyBomItems.Where(i => i.ItemType == BomItemType.Material)
                    .Select(i => ObjectId.Parse(i.RegardingId)).ToList();
                var materialDb = _materialManager.GetMaterialsByIds(materialIds);

                var equipmentIds = lstEmptyBomItems.Where(i => i.ItemType == BomItemType.Equipment)
                    .Select(i => ObjectId.Parse(i.RegardingId)).ToList();
                var equipmentDb = _equipmentManager.GetEquipmentsByIds(equipmentIds);

                lstEmptyBomItems.ForEach(t =>
                {
                    if (t.ItemType == BomItemType.Equipment)
                    {
                        var equipmentToUse = equipmentDb.FirstOrDefault(m => m.EquipmentId == t.RegardingId);
                        if (equipmentToUse != null)
                            t.Item = equipmentToUse;
                    }
                    else if (t.ItemType == BomItemType.Material)
                    {
                        var materialToUse = materialDb.FirstOrDefault(m => m.MaterialId == t.RegardingId);
                        if (materialToUse != null)
                            t.Item = materialToUse;
                    }
                });
            }

            #endregion

            return bomViewModel;
        }

        private BomUserViewModel MapBomUserToViewModel(BomUser bomUser)
        {
            var bomUserViewModel = new BomUserViewModel();
            if (bomUser != null)
            {
                bomUserViewModel = (BomUserViewModel)bomUserViewModel.MapFromModel(bomUser);
            }
            return bomUserViewModel;
        }

        /// <summary>
        /// Map group model to view model
        /// </summary>
        /// <param name="bomGroup"></param>
        /// <param name="lstEmptyBomItems"></param>
        /// <returns></returns>
        private BomGroupViewModel MapBomGroupToViewModel(BomGroup bomGroup, ref List<BomItemViewModel> lstEmptyBomItems)
        {
            var bomGroupViewModel = new BomGroupViewModel { Name = bomGroup.Name };
            if (bomGroup.BillOfMaterials != null && bomGroup.BillOfMaterials.Any())
            {
                var bomViewModel = new List<BillOfMaterialViewModel>();
                foreach (var groupBillOfMaterial in bomGroup.BillOfMaterials)
                {
                    bomViewModel.Add(MapBomToViewModel(groupBillOfMaterial));
                }
                bomGroupViewModel.BillOfMaterials = bomViewModel;
            }

            if (bomGroup.BomItems != null && bomGroup.BomItems.Any())
            {
                var bomItemsViewModel = new List<BomItemViewModel>();
                foreach (var bomGroupBomItem in bomGroup.BomItems)
                {
                    bomItemsViewModel.Add(MapBomItemToViewModel(bomGroupBomItem, ref lstEmptyBomItems));
                }
                bomGroupViewModel.BomItems = bomItemsViewModel;
            }
            return bomGroupViewModel;
        }

        /// <summary>
        /// Map item model to view model
        /// </summary>
        /// <param name="bomItem"></param>
        /// <param name="lstEmptyBomItems">Here empty elements were created</param>
        /// <returns></returns>
        private BomItemViewModel MapBomItemToViewModel(BomItem bomItem, ref List<BomItemViewModel> lstEmptyBomItems)
        {
            var bomItemViewModel = new BomItemViewModel { ItemType = bomItem.ItemType };
            if (bomItem.ItemType == BomItemType.Equipment)
            {
                bomItemViewModel.RegardingId = bomItem.RegardingId.ToString();
            }
            else
            {
                bomItemViewModel.RegardingId = bomItem.RegardingId.ToString();
            }
            lstEmptyBomItems.Add(bomItemViewModel);
            return bomItemViewModel;
        }

        #endregion

        #region Private methods for BOM ViewModel to Model

        /// <summary>
        /// Map View Model to Model
        /// </summary>
        /// <param name="bomViewModel"></param>
        /// <returns></returns>
        private BillOfMaterial MapBomToModel(BillOfMaterialViewModel bomViewModel)
        {
            var bom = new BillOfMaterial();
            bom.MapFromViewModel(bomViewModel, (ClaimsIdentity)_principal.Identity);

            if (bomViewModel.TemplateId != null)
            {
                bom.TemplateId = ObjectId.Parse(bomViewModel.TemplateId);
            }

            if (!string.IsNullOrEmpty(bomViewModel.Image))
            {
                bom.Image = ObjectId.Parse(bomViewModel.Image);
            }
            bom.AddedItems = new List<AddToBom>();
            bom.Comments = new List<BomComment>();

            #region Group mapping
            if (bomViewModel.Groups != null && bomViewModel.Groups.Any())
            {
                bom.Groups = new List<BomGroup>();
                bomViewModel.Groups.ForEach(t =>
                {
                    var bomGroup = MapBomGroupToModel(t);
                    bom.Groups.Add(bomGroup);
                });
            }
            #endregion

            #region Option mapping
            if (bomViewModel.Option != null)
            {
                var bomOption = new BomOption();
                if (!string.IsNullOrEmpty(bomViewModel.Option.License)) { bomOption.License = ObjectId.Parse(bomViewModel.Option.License); }
                if (!string.IsNullOrEmpty(bomViewModel.Option.Owner)) { bomOption.Owner = ObjectId.Parse(bomViewModel.Option.Owner); }
                if (!string.IsNullOrEmpty(bomViewModel.Option.Location)) { bomOption.Location = ObjectId.Parse(bomViewModel.Option.Location); }
                bom.Option = bomOption;
            }
            #endregion

            return bom;
        }

        /// <summary>
        /// Map Bom Group View Model to Model.
        /// </summary>
        /// <param name="bomGroupViewModel"></param>
        /// <returns></returns>
        private BomGroup MapBomGroupToModel(BomGroupViewModel bomGroupViewModel)
        {
            var bomGroup = new BomGroup { Name = bomGroupViewModel.Name };
            if (bomGroupViewModel.BillOfMaterials != null && bomGroupViewModel.BillOfMaterials.Any())
            {
                var bom = new List<BillOfMaterial>();
                foreach (var groupBillOfMaterial in bomGroupViewModel.BillOfMaterials)
                {
                    bom.Add(MapBomToModel(groupBillOfMaterial));
                }
                bomGroup.BillOfMaterials = bom;
            }

            if (bomGroupViewModel.BomItems != null && bomGroupViewModel.BomItems.Any())
            {
                var bomItems = new List<BomItem>();
                foreach (var bomGroupBomItem in bomGroupViewModel.BomItems)
                {
                    bomItems.Add(MapBomItemToModel(bomGroupBomItem));
                }
                bomGroup.BomItems = bomItems;
            }
            return bomGroup;
        }

        /// <summary>
        /// Map Bom Item View Model To Model
        /// </summary>
        /// <param name="bomItemViewModel"></param>
        /// <returns></returns>
        private BomItem MapBomItemToModel(BomItemViewModel bomItemViewModel)
        {
            var bomItem = new BomItem { ItemType = bomItemViewModel.ItemType };
            if (bomItemViewModel.ItemType == BomItemType.Equipment)
            {
                var equipmentViewModel = JsonConvert.DeserializeObject<EquipmentViewModel>(bomItemViewModel.Item.ToString());
                var equipment = new Equipment();
                equipment.MapFromViewModel(equipmentViewModel as EquipmentViewModel);
                bomItem.RegardingId = equipment.EquipmentId;
            }
            else
            {
                var materialViewModel = JsonConvert.DeserializeObject<MaterialViewModel>(bomItemViewModel.Item.ToString());
                var material = new Material();
                material.MapFromViewModel(materialViewModel as MaterialViewModel);
                bomItem.RegardingId = material.MaterialId;
            }
            return bomItem;
        }

        #endregion
    }
}
