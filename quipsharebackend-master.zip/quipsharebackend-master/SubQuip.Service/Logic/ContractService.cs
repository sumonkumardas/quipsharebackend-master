﻿using SubQuip.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SubQuip.Common.CommonData;
using SubQuip.Data.Interfaces;
using SubQuip.Common.Enums;
using SubQuip.ViewModel.Location;
using System.Linq;
using SubQuip.Common.Extensions;
using SubQuip.Entity.Models;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.ViewModel.ContractWizard;
using File = SubQuip.Entity.Models.File;

namespace SubQuip.Business.Logic
{
    public class ContractService : IContractService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly IContractRepository _contractRepository;
        private readonly IFileRepository _fileRepository;

        /// <summary>
        /// Initializes a new instance of the ContractService.
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="contractRepository"></param>
        /// <param name="fileRepository"></param>
        public ContractService(IPrincipal principal, IContractRepository contractRepository, IFileRepository fileRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _contractRepository = contractRepository;
            _fileRepository = fileRepository;
        }

        /// <summary>
        /// Get all Contracts.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IResult GetAllContracts(SearchSortModel search)
        {
            if (string.IsNullOrEmpty(search.SortColumn))
            {
                search.SortColumn = Constants.CreatedDate;
            }
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var contractDetailViewModels = new List<ContractDetailViewModel>();
                var contracts = _contractRepository.GetAllContracts(search);
                if (contracts != null && contracts.Any())
                {
                    search.SearchResult = contractDetailViewModels.MapFromModel<Contract, ContractDetailViewModel>(contracts);
                }
                else
                {
                    search.SearchResult = contractDetailViewModels;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.Body = search;
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Insert Contract
        /// </summary>
        /// <param name="regardingId"></param>
        /// <param name="contractTitle"></param>
        /// <param name="contractNumber"></param>
        /// <param name="contractData"></param>
        /// <returns></returns>
        public IResult InsertContract(string regardingId, string contractTitle, string contractNumber, string contractData)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var emailActiveUserId = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(emailActiveUserId))
                {
                    var contract = new Contract
                    {
                        ContractTitle = contractTitle,
                        RegardingId = ObjectId.Parse(regardingId),
                        ContractNumber = contractNumber,
                        ContractData = contractData
                    };
                    contract.MapAuditColumns((ClaimsIdentity)_principal.Identity);
                    _contractRepository.InsertOne(contract);

                    var resultView = new ContractDetailViewModel();
                    resultView.MapFromModel(contract);

                    result.Body = resultView;
                    result.Message = ContractNotification.Created;
                    result.StatusCode = HttpStatusCode.OK;
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Get contracts by regarding id
        /// </summary>
        /// <param name="regardingId"></param>
        /// <param name="search"></param>
        /// <returns></returns>
        public IResult GetContractsByRegardingId(SearchSortModel search, string regardingId)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var contractDetailViewModels = new List<ContractDetailViewModel>();
                var contracts = _contractRepository.GetContractsByRegardingId(search, regardingId);
                if (contracts.Any())
                {
                    result.Body = contractDetailViewModels.MapFromModel<Contract, ContractDetailViewModel>(contracts);
                }
                else
                {
                    result.Body = contractDetailViewModels;
                    result.Message = CommonErrorMessages.NoResultFound;
                }
                result.StatusCode = HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }

        /// <summary>
        /// Save the uploded contract file
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public IResult SaveContractFile(UploadContractViewModel viewModel)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var mail = ((ClaimsIdentity)_principal.Identity).GetActiveUserId();
                if (!string.IsNullOrEmpty(mail))
                {
                    if (viewModel.FileDetail != null)
                    {
                        var extension = Path.GetExtension(viewModel.FileDetail.Name);
                        if (extension != ".pdf")
                        {
                            result.Message = FileNotification.InvalidFile;
                            result.StatusCode = HttpStatusCode.NotAcceptable;
                            result.Status = Status.Fail;
                            return result;
                        }
                        // Insert file
                        var file = new File();
                        file.MapFromViewModel(viewModel.FileDetail, (ClaimsIdentity)_principal.Identity);
                        _fileRepository.InsertOne(file);
                        // Update contract file details
                        var updateDefinition = Builders<Contract>.Update.Set(x => x.ContractFile, file.FileId)
                                                                        .Set(x => x.ModifiedDate, GenericHelper.CurrentDate)
                                                                        .Set(x => x.ModifiedBy, mail);
                        _contractRepository.UpdateOne(t => t.ContractId == ObjectId.Parse(viewModel.ContractId), updateDefinition);

                        result.Body = file.FileId.ToString();
                        result.Message = ContractNotification.ContractFileUploaded;
                    }
                }
                else
                {
                    result.Status = Status.Fail;
                    result.Message = CommonErrorMessages.MailNotFound;
                    result.StatusCode = (HttpStatusCode)CustomStatusCode.MailNotFound;
                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
            }
            return result;
        }
    }
}
