﻿using SubQuip.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.Common.CommonData;
using SubQuip.Data.Interfaces;
using SubQuip.Common.Enums;
using SubQuip.ViewModel.Location;
using System.Linq;
using SubQuip.Common.Extensions;
using SubQuip.Entity.Models;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using Microsoft.AspNetCore.Http;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Common.Importer;
using SubQuip.ViewModel.ContractWizard;
using SubQuip.ViewModel.ImportViewModel;
using SubQuip.ViewModel.Licence;

namespace SubQuip.Business.Logic
{
    public class SequenceService : ISequenceService
    {
        private readonly ClaimsPrincipal _principal;
        private readonly ISequenceRepository _sequenceRepository;

        /// <summary>
        /// Initializes a new instance of the ContractService.
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="sequenceRepository"></param>
        public SequenceService(IPrincipal principal, ISequenceRepository sequenceRepository)
        {
            _principal = principal as ClaimsPrincipal;
            _sequenceRepository = sequenceRepository;
        }

        /// <summary>
        /// Get sequence value by name
        /// </summary>
        /// <param name="sequenceType"></param>
        /// <returns></returns>
        public long GetSequenceValue(SequenceTypes sequenceType)
        {
            return _sequenceRepository.GetSequenceValue(sequenceType.ToString());
        }
    }
}
