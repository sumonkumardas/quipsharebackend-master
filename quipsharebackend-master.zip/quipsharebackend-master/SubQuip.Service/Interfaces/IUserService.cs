﻿using SubQuip.Common.CommonData;
using SubQuip.ViewModel.User;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SubQuip.Business.Interfaces
{
    public interface IUserService
    {
        /// <summary>
        ///  Returns User details
        /// </summary>
        /// <returns></returns>
        Task<IResult> GetUser(string userName);

        /// <summary>
        /// Save User and Tab Details.
        /// </summary>
        /// <param name="savedTabViewModel"></param>
        /// <returns></returns>
        IResult SaveTabDetail(SavedTabViewModel savedTabViewModel);

        /// <summary>
        /// Get all Tabs for User.
        /// </summary>
        /// <returns></returns>
        IResult GetTabsForUser();

        /// <summary>
        /// Delete user tab
        /// </summary>
        /// <param name="tabId"></param>
        /// <returns></returns>
        IResult DeleteUserTab(string tabId);

        /// <summary>
        /// List of application users
        /// </summary>
        /// <returns></returns>
        Task<IResult> ApplicationUsers();
    }
}
