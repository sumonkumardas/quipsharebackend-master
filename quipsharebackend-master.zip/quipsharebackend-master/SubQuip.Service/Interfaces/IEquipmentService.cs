﻿using MongoDB.Bson;
using SubQuip.Common;
using SubQuip.Common.CommonData;
using SubQuip.ViewModel.Equipment;
using SubQuip.ViewModel.PartProperties;
using SubQuip.ViewModel.Request;
using SubQuip.ViewModel.Statistics;
using SubQuip.ViewModel.TechSpecs;
using System.Collections.Generic;
using SubQuip.Common.Importer;
using Microsoft.AspNetCore.Http;

namespace SubQuip.Business.Interfaces
{
    public interface IEquipmentService
    {
        /// <summary>
        /// Get All Equipment Info
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        IResult GetAllEquipments(SearchSortModel search);

        /// <summary>
        /// Get a single Equipment
        /// </summary>
        /// <param name="id">equipment id</param>
        /// <returns></returns>
        IResult GetEquipmentById(string id);

        /// <summary>
        /// Insert Equipment
        /// </summary>
        /// <param name="equipmentViewModel"></param>
        /// <returns></returns>
        IResult InsertEquipment(EquipmentViewModel equipmentViewModel, FileDetails fileViewModel);

        /// <summary>
        /// Save Equipment Document
        /// </summary>
        /// <param name="documents"></param>
        /// <returns></returns>
        IResult SaveEquipmentDocument(List<FileDetails> fileList, DocumentViewModel document);

        /// <summary>
        /// Update Equipment
        /// </summary>
        /// <param name="equipmentViewModel"></param>
        /// <returns></returns>
        IResult UpdateEquipment(EquipmentViewModel equipmentViewModel, FileDetails fileViewModel);

        /// <summary>
        /// Insert Update the equipment overview
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        IResult ManageEquipmentPartProperties(PartPropertyViewModel viewModel);

        /// <summary>
        /// Insert update the technical specifications
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        IResult ManageEquipmentTechnicalSpecs(TechSpecsViewModel viewModel);

        /// <summary>
        /// Delete a single Equipment
        /// </summary>
        /// <param name="id">equipment id</param>
        /// <returns></returns>
        IResult DeleteEquipment(string id);

        /// <summary>
        /// Delete All Equipments.
        /// </summary>
        /// <returns></returns>
        IResult DeleteAllEquipment();

        /// <summary>
        /// Delete Equipment Techincal Specification.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="techSpecId"></param>
        /// <returns></returns>
        IResult DeleteEquipmentTechnicalSpecification(string id, string techSpecId);

        /// <summary>
        /// Insert Equipment Request
        /// </summary>
        /// <param name="fileList"></param>
        /// <param name="equipmentRequestViewModel"></param>
        /// <returns></returns>
        IResult InsertEquipmentRequest(List<FileDetails> fileList, EquipmentRequestViewModel equipmentRequestViewModel);

        /// <summary>
        /// Get List of Equipments for corresponding identifiers.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        List<EquipmentViewModel> GetEquipmentsByIds(SearchSortModel search, List<ObjectId> ids);

        /// <summary>
        /// Get List of Equipments for corresponding identifiers.
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="techSpecsRequired"></param>
        /// <returns></returns>
        List<EquipmentViewModel> GetEquipmentsByIds(List<ObjectId> ids, bool techSpecsRequired = false);

        /// <summary>
        /// Import equipment data
        /// </summary>
        /// <param name="dataToImport"></param>
        /// <returns></returns>
        IResult ImportEquipments(IFormFile uploadFile);

        /// <summary>
        /// Get all equipments for export
        /// </summary>
        /// <returns></returns>
        IResult ExportEquipment();

        /// <summary>
        /// Equipment stats
        /// </summary>
        /// <returns></returns>
        IResult EquipmentStats();

        /// <summary>
        /// Get the distinct column values
        /// </summary>
        /// <param name="searchSort"></param>
        /// <returns></returns>
        IResult GetDistinctEquipmentColumnValues(SearchSortModel searchSort);
    }

}

