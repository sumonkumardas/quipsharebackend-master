﻿using SubQuip.Common.CommonData;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace SubQuip.Business.Interfaces
{
    public interface ILocationService
    {
        /// <summary>
        /// Get all Locations.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        IResult GetAllLocations(SearchSortModel search);

        /// <summary>
        /// Import location
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        IResult ImportLocations(IFormFile uploadFile);

        /// <summary>
        /// Export Locations
        /// </summary>
        /// <returns></returns>
        IResult ExportLocations();
    }
}
