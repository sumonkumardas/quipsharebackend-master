﻿using SubQuip.Common;
using SubQuip.Common.CommonData;
using SubQuip.ViewModel.Request;
using System.Collections.Generic;
using SubQuip.Common.Enums;

namespace SubQuip.Business.Interfaces
{
    public interface IRequestService
    {
        /// <summary>
        /// Get All Request Info
        /// </summary>
        /// <param name="search"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        IResult GetRequests(SearchSortModel search, RequestFormType type);

        /// <summary>
        /// Get a single Request
        /// </summary>
        /// <param name="id">Request id</param>
        /// <returns></returns>
        IResult GetRequestById(string id);

        /// <summary>
        /// Insert Request
        /// </summary>
        /// <param name="fileList"></param>
        /// <param name="requestViewModel"></param>
        /// <returns></returns>
        IResult InsertRequest(List<FileDetails> fileList, RequestViewModel requestViewModel);

        /// <summary>
        /// Update Request
        /// </summary>
        /// <param name="fileList"></param>
        /// <param name="requestViewModel"></param>
        /// <returns></returns>
        IResult UpdateRequest(List<FileDetails> fileList, RequestViewModel requestViewModel);

        /// <summary>
        /// Delete a single Request
        /// </summary>
        /// <param name="id">Request id</param>
        /// <returns></returns>
        IResult DeleteRequest(string id);

        /// <summary>
        /// Delete All Requests.
        /// </summary>
        /// <returns></returns>
        IResult DeleteAllRequests();

        /// <summary>
        /// Get Dashboard Requests
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        IResult GetDashboardRequests(SearchSortModel search);
    }
}
