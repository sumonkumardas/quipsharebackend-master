﻿using SubQuip.Common.CommonData;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using SubQuip.ViewModel.ContractWizard;

namespace SubQuip.Business.Interfaces
{
    public interface IContractService
    {
        /// <summary>
        /// Get all Contracts.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        IResult GetAllContracts(SearchSortModel search);


        /// <summary>
        /// Insert Contract
        /// </summary>
        /// <param name="regardingId"></param>
        /// <param name="contractTitle"></param>
        /// <param name="contractNumber"></param>
        /// <param name="contractData"></param>
        /// <returns></returns>
        IResult InsertContract(string regardingId, string contractTitle, string contractNumber, string contractData);

        /// <summary>
        /// Get contracts by regarding id
        /// </summary>
        /// <param name="search"></param>
        /// <param name="regardingId"></param>
        /// <returns></returns>
        IResult GetContractsByRegardingId(SearchSortModel search, string regardingId);

        /// <summary>
        /// Save the uploded contract file
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        IResult SaveContractFile(UploadContractViewModel viewModel);
    }
}
