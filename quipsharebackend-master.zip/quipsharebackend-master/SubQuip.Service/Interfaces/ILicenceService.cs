﻿using SubQuip.Common.CommonData;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace SubQuip.Business.Interfaces
{
    public interface ILicenceService
    {
        /// <summary>
        /// Get all Licence
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        IResult GetAllLicence(SearchSortModel search);

        /// <summary>
        /// Import licence
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        IResult ImportLicences(IFormFile uploadFile);

        /// <summary>
        /// Export Licence
        /// </summary>
        /// <returns></returns>
        IResult ExportLicence();
    }
}
