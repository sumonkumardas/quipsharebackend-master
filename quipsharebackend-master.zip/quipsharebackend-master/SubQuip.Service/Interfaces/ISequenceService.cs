﻿using SubQuip.Common.Enums;

namespace SubQuip.Business.Interfaces
{
    public interface ISequenceService
    {
        /// <summary>
        /// Get sequence value by name
        /// </summary>
        /// <param name="sequenceType"></param>
        /// <returns></returns>
        long GetSequenceValue(SequenceTypes sequenceType);
    }
}
