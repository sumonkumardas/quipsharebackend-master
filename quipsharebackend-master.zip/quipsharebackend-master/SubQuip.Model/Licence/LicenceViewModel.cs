﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using SubQuip.Common.Importer;

namespace SubQuip.ViewModel.Licence
{
    public class LicenceViewModel
    {
        public string LicenceId { get; set; }

        public string LicenceNumber { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
    
    public class LicenceExportViewModel
    {
        [JsonProperty("Id")]
        public string LicenceId { get; set; }

        [JsonProperty("LicenceNumber")]
        public string LicenceNumber { get; set; }

        [JsonProperty("IsDeleted")]
        public bool IsDeleted { get; set; }
    }
}
