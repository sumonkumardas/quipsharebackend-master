﻿using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.Common.CommonData;

namespace SubQuip.ViewModel.ContractWizard
{
    public class UploadContractViewModel
    {
        /// <summary>
        /// Contract identifier
        /// </summary>
        public string ContractId { get; set; }

        public FileDetails FileDetail { get; set; }
    }
}
