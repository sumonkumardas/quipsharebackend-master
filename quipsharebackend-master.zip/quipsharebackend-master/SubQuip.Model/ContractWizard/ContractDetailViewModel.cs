﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.ViewModel.ContractWizard
{
    public class ContractDetailViewModel
    {
        public string ContractId { get; set; }

        public string RegardingId { get; set; }

        public string ContractTitle { get; set; }

        public string ContractNumber { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ContractFile { get; set; }
    }
}
