﻿using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.Common.CommonData;
using SubQuip.Common.Enums;

namespace SubQuip.ViewModel.ContractWizard
{
    public class ContractWizardViewModel
    {
        /// <summary>
        /// BOM identifier
        /// </summary>
        public string RegardingId { get; set; }

        public string ContractTitle { get; set; }

        public string ContractNumber { get; set; }

        public List<ContractAddressViewModel> ContractAddresses { get; set; } = new List<ContractAddressViewModel>();

        public List<ContractPart> Parts { get; set; } = new List<ContractPart>();

        public List<ContractSpecificTerm> SpecificTerms { get; set; } = new List<ContractSpecificTerm>();

        public string MaintenanceBeforePeriod { get; set; }
        public string MaintenanceAfterPeriod { get; set; }
        public string MaintenanceByOem { get; set; }

        public string CollectionAddress { get; set; }

        public string RentalPeriodStartDate { get; set; }

        public string RentalPeriodEndDate { get; set; }

        public List<ContractSignature> ContractSignatures { get; set; } = new List<ContractSignature>();

        public List<ContractTermsAndCondition> TermsAndConditions { get; set; } = new List<ContractTermsAndCondition>();

        /// <summary>
        /// List of users to send contract wizard pdf
        /// </summary>
        public List<MailUser> MailToUsers { get; set; }

        /// <summary>
        /// Contract data string to save in db
        /// </summary>
        public string DataString { get; set; }
    }

    public class ContractAddressViewModel
    {
        public string CompanyName { get; set; }

        public string Technical { get; set; }

        public string Commercial { get; set; }

        public string Address { get; set; }

        public string Telephone { get; set; }

        public string Fax { get; set; }

        public string Email { get; set; }

        public ContractWizardTypes AddressType { get; set; }
    }

    public class ContractPart
    {
        public string Item { get; set; }
        public string SubQuipNo { get; set; }
        public string Description { get; set; }
        public string SubQuipRate { get; set; }
        public string RentalPerDay { get; set; }
    }

    public class ContractSpecificTerm
    {
        public string Item { get; set; }
        public string Term { get; set; }
    }

    public class ContractTermsAndCondition
    {
        public string ArticleNoText { get; set; }

        public List<ContractTnCArticle> Articles { get; set; } = new List<ContractTnCArticle>();
    }

    public class ContractTnCArticle
    {
        public string Item { get; set; }

        public string ArticleText { get; set; }
    }

    public class ContractHeaderContent
    {
        public string HeaderLogoPath { get; set; }

        public string HeaderRightImagePath { get; set; }

        public string FontPath { get; set; }
    }

    public class ContractSignature
    {
        public string NamePosition { get; set; }

        public ContractWizardTypes SignType { get; set; }
    }
}
