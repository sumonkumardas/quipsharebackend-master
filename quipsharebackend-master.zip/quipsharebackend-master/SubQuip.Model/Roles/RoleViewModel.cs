﻿
using System;


namespace SubQuip.ViewModel.Roles
{
    public class RoleViewModel
    {
        public string RoleId { get; set; }

        public string RoleName { get; set; }
    }
}
