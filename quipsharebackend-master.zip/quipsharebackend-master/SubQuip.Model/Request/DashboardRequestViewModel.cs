﻿using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.ViewModel.BillOfMaterial;

namespace SubQuip.ViewModel.Request
{
    public class DashboardRequestViewModel
    {
        public string RequestId { get; set; }

        public string RegardingId { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string BomName { get; set; }

        public BomUserViewModel BomUser { get; set; }

        public string Owner { get; set; }
    }
}
