﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.ViewModel.PartProperties
{
    public class PartPropertyViewModel
    {
        public string PartPropertyId { get; set; }

        public string RegardingId { get; set; }

        public string PropertyName { get; set; }

        public string PropertyValue { get; set; }
    }
}
