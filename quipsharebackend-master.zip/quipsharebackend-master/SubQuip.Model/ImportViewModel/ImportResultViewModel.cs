﻿using System;
using System.Collections.Generic;
using System.Text;
using SubQuip.Common.Importer;

namespace SubQuip.ViewModel.ImportViewModel
{
    public class ImportResultViewModel
    {
        public int InsertedCount { get; set; }

        public int UpdatedCount { get; set; }

        public int RecordsReUploaded { get; set; }

        public int RecordsForDeletion { get; set; }

        public int ErrorCount { get; set; }

        public List<DataParsingError> Errors { get; set; } = new List<DataParsingError>();
    }
   
    public class EquipmentImportResult : ImportResultViewModel
    {
        public int RecordsWithInvalidMaterial { get; set; }
    }
}
