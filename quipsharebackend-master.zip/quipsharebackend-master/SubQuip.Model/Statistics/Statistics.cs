﻿using System;
using System.Collections.Generic;
using SubQuip.ViewModel.Request;
using SubQuip.ViewModel.BillOfMaterial;

namespace SubQuip.ViewModel.Statistics
{
    public class BomStatsViewModel
    {
        public int NumBoms { get; set; }
        public int NumBomsInProgress { get; set; }
        public int NumBomsCompleted { get; set; }
    }

    public class EquipmentStats
    {
        public int NumEquipments { get; set; }
        public int NumEquipmentsWithDocumentation { get; set; }
        public List<PartnerStatistics> NumEquipmentForPartner { get; set; }
        public int NumRecentEquipments { get; set; }
    }

    public class MaterialStats
    {
        public int NumMaterials { get; set; }
        public int NumMaterialsWithDocumentation { get; set; }
        public int NumRecentMaterials { get; set; }
    }
}
