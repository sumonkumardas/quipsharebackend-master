﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.ViewModel.Statistics
{
    public class PartnerStatistics
    {
        public string Name { get; set; }

        public string Email { get; set; }

        public int EquipmentCount { get; set; }
    }
}
