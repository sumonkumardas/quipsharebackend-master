﻿using System.Collections.Generic;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.PartProperties;
using SubQuip.ViewModel.TechSpecs;
using System;
using Newtonsoft.Json;
using SubQuip.Common.CommonData;
using SubQuip.Common.Importer;

namespace SubQuip.ViewModel.Material
{
    public class MaterialViewModel
    {
        public string MaterialId { get; set; } //Should be unique, hidden from user

        public string Materialnumber { get; set; }

        public string Description { get; set; }

        public string ManufactorPartNumber { get; set; }

        public string ManufactorSerialNumber { get; set; }

        public string ManufactorName { get; set; }

        public string Type { get; set; }

        public string Location { get; set; }

        public string Owner { get; set; }

        public bool IsActive { get; set; }

        public string ImageId { get; set; }

        public string ImageContent { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public List<PartPropertyViewModel> PartProperties { get; set; }

        public List<FileDetails> Documents { get; set; }

        public List<TechSpecsViewModel> TechnicalSpecifications { get; set; }
    }

    public class MaterialExportViewModel
    {
        [JsonProperty("Id")]
        public string MaterialId { get; set; }

        [JsonProperty("Material")]
        public string Materialnumber { get; set; }

        [JsonProperty("Description")]
        public string Description { get; set; }

        [JsonProperty("Manufacturer Part no")]
        public string ManufactorPartNumber { get; set; }

        [JsonProperty("Manufacturer Serial Number")]
        public string ManufactorSerialNumber { get; set; }

        [JsonProperty("Manufacturer Name")]
        public string ManufactorName { get; set; }

        [JsonProperty("Owner")]
        public string Owner { get; set; }

        [JsonProperty("Name of field")]
        public string Location { get; set; }

        [JsonProperty("Type")]
        public string Type { get; set; }

        [JsonProperty("IsDeleted")]
        public bool IsDeleted { get; set; }

        public List<TechSpecsViewModel> TechnicalSpecifications { get; set; }
    }
}
