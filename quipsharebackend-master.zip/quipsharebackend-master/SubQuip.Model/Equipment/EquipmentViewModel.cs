﻿using System.Collections.Generic;
using SubQuip.ViewModel.PartProperties;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.Material;
using SubQuip.ViewModel.TechSpecs;
using System;
using Newtonsoft.Json;
using SubQuip.Common.CommonData;
using SubQuip.Common.Importer;

namespace SubQuip.ViewModel.Equipment
{
    public class EquipmentViewModel
    {
        public string EquipmentId { get; set; }

        public string EquipmentNumber { get; set; }

        public string ManufactorPartNumber { get; set; }

        public string ManufactorSerialNumber { get; set; }

        public string ManufactorName { get; set; }

        public string VendorPartNumber { get; set; }

        public string VendorSerialNumber { get; set; }

        public string Vendor { get; set; }

        public string Owner { get; set; }

        public string Description { get; set; }

        public string Location { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public string ImageId { get; set; }

        public string ImageContent { get; set; }

        public List<PartPropertyViewModel> PartProperties { get; set; }

        public List<FileDetails> Documents { get; set; }

        public List<TechSpecsViewModel> TechnicalSpecifications { get; set; }

        public string Material { get; set; }

        public string MaterialNumber { get; set; }

        public MaterialViewModel MaterialDetails { get; set; }
    }

    public class EquipmentExportViewModel
    {
        [JsonProperty("Id")]
        public string EquipmentId { get; set; }

        [JsonProperty("Equipment No_Owner")]
        public string EquipmentNumber { get; set; }

        [JsonProperty("Material")]
        public string MaterialNumber { get; set; }

        [JsonProperty("Manufacturer Part no")]
        public string ManufactorPartNumber { get; set; }

        [JsonProperty("Manufacturer Serial Number")]
        public string ManufactorSerialNumber { get; set; }

        [JsonProperty("Manufacturer Name")]
        public string ManufactorName { get; set; }

        [JsonProperty("Vendor PartNo")]
        public string VendorPartNumber { get; set; }

        [JsonProperty("Vendor SerialNo")]
        public string VendorSerialNumber { get; set; }

        [JsonProperty("Vendor")]
        public string Vendor { get; set; }

        [JsonProperty("Description")]
        public string Description { get; set; }

        [JsonProperty("Owner")]
        public string Owner { get; set; }

        [JsonProperty("Name of field")]
        public string Location { get; set; }

        [JsonProperty("IsDeleted")]
        public bool IsDeleted { get; set; }

        public List<TechSpecsViewModel> TechnicalSpecifications { get; set; }
    }
}
