﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using SubQuip.Common.Importer;

namespace SubQuip.ViewModel.Partner
{
    public class PartnerViewModel
    {
        public string PartnerId { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }

    public class PartnerExportViewModel
    {
        [JsonProperty("Id")]
        public string PartnerId { get; set; }

        [JsonProperty("Name")]
        public string Name { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("IsDeleted")]
        public bool IsDeleted { get; set; }
    }
}
