﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using SubQuip.Common.Importer;

namespace SubQuip.ViewModel.Location
{
    public class LocationViewModel
    {
        public string LocationId { get; set; }

        public string LocationName { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
    
    public class LocationExportViewModel
    {
        [JsonProperty("Id")]
        public string LocationId { get; set; }

        [JsonProperty("LocationName")]
        public string LocationName { get; set; }

        [JsonProperty("IsDeleted")]
        public bool IsDeleted { get; set; }
    }
}
