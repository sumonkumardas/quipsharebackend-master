﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.ViewModel.BillOfMaterial
{
    public class BomOptionViewModel
    {
        public string RegardingId { get; set; }

        public string License { get; set; }

        public string LicenseName { get; set; }

        public string Owner { get; set; }

        public string OwnerName { get; set; }

        public string Location { get; set; }
        public string LocationName { get; set; }

    }
}
