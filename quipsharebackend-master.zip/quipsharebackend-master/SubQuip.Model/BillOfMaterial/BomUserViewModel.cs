﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.ViewModel.BillOfMaterial
{
    public class BomUserViewModel
    {        
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Mail { get; set; }

        public string Company { get; set; }
    }
}
