﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.ViewModel.User
{
    public class SavedTabViewModel
    {
        public string TabId { get; set; }

        public string Name { get; set; }

        public string Path { get; set; }
    }
}
