﻿using SubQuip.Common.CommonData;
using SubQuip.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.Data.Interfaces
{
    public interface ISequenceRepository : IRepository<Sequence>
    {
        /// <summary>
        /// Get sequence value by name
        /// </summary>
        /// <param name="sequenceName"></param>
        /// <returns></returns>
        long GetSequenceValue(string sequenceName);
    }
}
