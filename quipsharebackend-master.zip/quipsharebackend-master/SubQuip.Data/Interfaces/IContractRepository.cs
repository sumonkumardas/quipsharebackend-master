﻿using SubQuip.Common.CommonData;
using SubQuip.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SubQuip.Data.Interfaces
{
    public interface IContractRepository : IRepository<Contract>
    {
        /// <summary>
        /// Get all Contracts.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        List<Contract> GetAllContracts(SearchSortModel search);

        /// <summary>
        /// Get BOM Contracts.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="regardingId"></param>
        /// <returns></returns>
        List<Contract> GetContractsByRegardingId(SearchSortModel search, string regardingId);
    }
}
