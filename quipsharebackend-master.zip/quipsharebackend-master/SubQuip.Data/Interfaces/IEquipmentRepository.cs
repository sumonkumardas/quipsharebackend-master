﻿using SubQuip.Entity.Models.BillOfMaterials;
using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson;
using SubQuip.Common.CommonData;
using SubQuip.Entity.Models;

namespace SubQuip.Data.Interfaces
{
    public interface IEquipmentRepository : IRepository<Equipment>
    {
        /// <summary>
        /// Get All Equipments.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="istechSpecRequired"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        List<Equipment> GetAllEquipments(SearchSortModel search, bool istechSpecRequired, List<ObjectId> ids = null);

        /// <summary>
        /// Get Recent added equipments in week
        /// </summary>
        /// <returns></returns>
        long GetRecentAddedEquipment();

        /// <summary>
        /// Get the single column values after filteration
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        List<string> GetFilteredSingleColumnValues(SearchSortModel search);
    }
}
