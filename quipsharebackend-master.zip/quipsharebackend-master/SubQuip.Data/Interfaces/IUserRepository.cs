﻿using SubQuip.Entity.Models.AppUser;

namespace SubQuip.Data.Interfaces
{
    public interface IUserRepository: IRepository<AppUser>
    {
      
    }
}
