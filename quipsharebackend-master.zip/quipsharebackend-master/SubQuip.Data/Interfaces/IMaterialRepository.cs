﻿using System.Collections.Generic;
using MongoDB.Bson;
using SubQuip.Common.CommonData;
using SubQuip.Entity.Models;
using SubQuip.Entity.Models.BillOfMaterials;

namespace SubQuip.Data.Interfaces
{
    public interface IMaterialRepository : IRepository<Material>
    {
        /// <summary>
        /// Get All Materials.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="istechSpecRequired"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        List<Material> GetAllMaterials(SearchSortModel search, bool istechSpecRequired, List<ObjectId> ids = null);

        /// <summary>
        /// Get Recent added materials in week
        /// </summary>
        /// <returns></returns>
        long GetRecentAddedMaterials();

        /// <summary>
        /// Get the single column values after filteration
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        List<string> GetFilteredSingleColumnValues(SearchSortModel search);
    }
}
