﻿using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using SubQuip.Common.CommonData;
using SubQuip.Data.Interfaces;
using SubQuip.Entity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SubQuip.Data.Logic
{
    public class ContractRepository : Repository<Contract>, IContractRepository
    {
        public IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the ContractRepository
        /// </summary>
        /// <param name="configuration"></param>
        public ContractRepository(IConfiguration configuration) : base(configuration, "contract")
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Get All Contracts.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public List<Contract> GetAllContracts(SearchSortModel search)
        {
            var query = from contract in Query
                        select contract;
            if (!string.IsNullOrEmpty(search.SearchString))
            {
                query = query.Where(t => t.ContractTitle.ToLower().Contains(search.SearchString)
                                         || t.ContractNumber.ToLower().Contains(search.SearchString)
                                         || t.ContractData.ToLower().Contains(search.SearchString));
            }
            query = Sort(query, search.SortColumn, search.SortDirection.ToString());
            var data = Page(query, search.Page, search.PageSize).ToList();
            search.TotalRecords = query.Count();
            return data;
        }

        /// <summary>
        /// Get BOM Contracts.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="regardingId"></param>
        /// <returns></returns>
        public List<Contract> GetContractsByRegardingId(SearchSortModel search, string regardingId)
        {
            var query = from contract in Query
                        where contract.RegardingId == ObjectId.Parse(regardingId)
                        select contract;
            if (!string.IsNullOrEmpty(search.SearchString))
            {
                query = query.Where(t => t.ContractTitle.ToLower().Contains(search.SearchString)
                                         || t.ContractNumber.ToLower().Contains(search.SearchString)
                                         || t.ContractData.ToLower().Contains(search.SearchString));
            }
            query = Sort(query, search.SortColumn, search.SortDirection.ToString());
            var data = Page(query, search.Page, search.PageSize).ToList();
            search.TotalRecords = query.Count();
            return data;
        }
    }
}
