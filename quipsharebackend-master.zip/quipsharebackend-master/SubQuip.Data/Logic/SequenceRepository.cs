﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using SubQuip.Data.Interfaces;
using SubQuip.Entity.Models;

namespace SubQuip.Data.Logic
{
    public class SequenceRepository : Repository<Sequence>, ISequenceRepository
    {
        public IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the ContractRepository
        /// </summary>
        /// <param name="configuration"></param>
        public SequenceRepository(IConfiguration configuration) : base(configuration, "sequence")
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Get sequence value by name
        /// </summary>
        /// <param name="sequenceName"></param>
        /// <returns></returns>
        public long GetSequenceValue(string sequenceName)
        {
            var filter = Builders<Sequence>.Filter.Eq(s => s.SequenceName, sequenceName);
            var update = Builders<Sequence>.Update.Inc(s => s.SequenceValue, 1);
            var result = Collection.FindOneAndUpdate(filter, update, new FindOneAndUpdateOptions<Sequence, Sequence> { IsUpsert = true, ReturnDocument = ReturnDocument.After });
            return result.SequenceValue;
        }
    }
}
