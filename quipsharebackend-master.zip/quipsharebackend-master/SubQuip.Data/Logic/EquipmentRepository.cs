﻿using System;
using System.Collections.Generic;
using SubQuip.Entity.Models;
using Microsoft.Extensions.Configuration;
using SubQuip.Data.Interfaces;
using System.Linq;
using MongoDB.Bson;
using MongoDB.Driver;
using SubQuip.Common.CommonData;
using SubQuip.Common.Extensions;

namespace SubQuip.Data.Logic
{
    public class EquipmentRepository : Repository<Equipment>, IEquipmentRepository
    {
        public IConfiguration Configuration;

        /// <summary>
        /// Initializes a new instance of the EquipmentRepository
        /// </summary>
        /// <param name="configuration"></param>
        public EquipmentRepository(IConfiguration configuration) : base(configuration, "equipment")
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Get All Equipments.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="istechSpecRequired"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        public List<Equipment> GetAllEquipments(SearchSortModel search, bool istechSpecRequired, List<ObjectId> ids = null)
        {
            var query = from equipment in Query
                        select new Equipment
                        {
                            EquipmentId = equipment.EquipmentId,
                            EquipmentNumber = equipment.EquipmentNumber,
                            ManufactorSerialNumber = equipment.ManufactorSerialNumber,
                            ManufactorName = equipment.ManufactorName,
                            ManufactorPartNumber = equipment.ManufactorPartNumber,
                            Owner = equipment.Owner,
                            Vendor = equipment.Vendor,
                            VendorPartNumber = equipment.VendorPartNumber,
                            VendorSerialNumber = equipment.VendorSerialNumber,
                            Location = equipment.Location,
                            Description = equipment.Description,
                            MaterialNumber = equipment.MaterialNumber,
                            Material = equipment.Material,
                            CreatedDate = equipment.CreatedDate,
                            TechnicalSpecifications = (istechSpecRequired ? equipment.TechnicalSpecifications : null)
                        };

            if (!string.IsNullOrEmpty(search.SearchString))
                query = query.Where(t => t.EquipmentNumber.ToLower().Contains(search.SearchString)
                                             || t.ManufactorSerialNumber.ToLower().Contains(search.SearchString)
                                             || t.ManufactorName.ToLower().Contains(search.SearchString)
                                             || t.ManufactorPartNumber.ToLower().Contains(search.SearchString)
                                             || t.Owner.ToLower().Contains(search.SearchString)
                                             || t.Vendor.ToLower().Contains(search.SearchString)
                                             || t.VendorPartNumber.ToLower().Contains(search.SearchString)
                                             || t.VendorSerialNumber.ToLower().Contains(search.SearchString)
                                             || t.Location.ToLower().Contains(search.SearchString)
                                             || t.Description.ToLower().Contains(search.SearchString)
                                             || t.MaterialNumber.ToLower().Contains(search.SearchString));


            if (ids != null)
                query = query.Where(t => ids.Contains(t.EquipmentId));


            if (search.Filters.Any())
            {
                var deleg = ExpressionBuilder.GetExpression<Equipment>(search.Filters);
                query = query.Where(deleg);
            }

            query = Sort(query, search.SortColumn, search.SortDirection.ToString());
            var data = Page(query, search.Page, search.PageSize).ToList();
            search.TotalRecords = query.Count();
            return data;
        }

        /// <summary>
        /// Get Recent added equipments in week
        /// </summary>
        /// <returns></returns>
        public long GetRecentAddedEquipment()
        {
            var start = GenericHelper.CurrentDate.AddDays(Convert.ToDouble(Configuration["PastDays"])).Date;
            var end = GenericHelper.CurrentDate.AddDays(1).Date; // To include the today date upto 24 hrs
            var filterBuilder = Builders<Equipment>.Filter;
            var filter = filterBuilder.Gte(x => x.CreatedDate, start) &
                         filterBuilder.Lt(x => x.CreatedDate, end);
            return Collection.Find(filter).Count();
        }

        /// <summary>
        /// Get the single column values after filteration
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public List<string> GetFilteredSingleColumnValues(SearchSortModel search)
        {
            var query = Query.Where(t => true);
            if (!string.IsNullOrEmpty(search.SearchString))
            {
                query = query.Where(t => t.EquipmentNumber.ToLower().Contains(search.SearchString)
                                         || t.ManufactorSerialNumber.ToLower().Contains(search.SearchString)
                                         || t.ManufactorName.ToLower().Contains(search.SearchString)
                                         || t.ManufactorPartNumber.ToLower().Contains(search.SearchString)
                                         || t.Owner.ToLower().Contains(search.SearchString)
                                         || t.Vendor.ToLower().Contains(search.SearchString)
                                         || t.VendorPartNumber.ToLower().Contains(search.SearchString)
                                         || t.VendorSerialNumber.ToLower().Contains(search.SearchString)
                                         || t.Location.ToLower().Contains(search.SearchString)
                                         || t.Description.ToLower().Contains(search.SearchString)
                                         || t.MaterialNumber.ToLower().Contains(search.SearchString)
                );
            }

            var expression = GenericHelper.MemberSelector<Equipment, string>(CollectionName, search.SingleColumnName);
            var data = query.Select(expression).Distinct().ToList();
            return data;
        }
    }
}
