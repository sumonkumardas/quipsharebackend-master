﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.Extensions.Configuration;
using SubQuip.Common.CommonData;
using SubQuip.Data.Interfaces;
using SubQuip.Entity.Models.BillOfMaterials;
using MongoDB.Bson;
using SubQuip.Common.Enums;
using SubQuip.Common.Extensions;
using SubQuip.Entity.Models;

namespace SubQuip.Data.Logic
{
    public class BillOfMaterialRepository : Repository<BillOfMaterial>, IBillOfMaterialRepository
    {
        public IConfiguration Configuration;

        /// <summary>
        /// Initializes a new instance of the BillOfMaterialRepository
        /// </summary>
        /// <param name="configuration"></param>
        public BillOfMaterialRepository(IConfiguration configuration) : base(configuration, "billofmaterial")
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Get all Bill Of Materials.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="userId"></param>
        /// <param name="isAdmin"></param>
        /// <param name="bomType"></param>
        /// <returns></returns>
        public List<BillOfMaterial> GetAllBillOfMaterial(SearchSortModel search, string userId, bool isAdmin, BomType bomType = BomType.Bom)
        {
            var query = from bom in Query
                        where bom.Type == bomType
                        select new BillOfMaterial
                        {
                            CreatedDate = bom.CreatedDate,
                            BomId = bom.BomId,
                            Name = bom.Name,
                            Status = bom.Status,
                            Type = bom.Type,
                            Description = bom.Description,
                            IsActive = bom.IsActive,
                            TemplateId = bom.TemplateId,
                            Option = bom.Option,
                            BomUser = bom.BomUser,
                            Location = bom.Location,
                            Owner = bom.Owner,
                            License = bom.License
                        };

            if (!string.IsNullOrEmpty(search.SearchString))
            {
                query = query.Where(t => t.Name.ToLower().Contains(search.SearchString) || t.Description.ToLower().Contains(search.SearchString));
            }

            if (!isAdmin && !string.IsNullOrEmpty(userId))
                query = query.Where(t => t.CreatedBy.ToLower().Contains(userId.ToLower()));

            if (search.Filters.Any())
            {
                var deleg = ExpressionBuilder.GetExpression<BillOfMaterial>(search.Filters);
                query = query.Where(deleg);
            }

            search.TotalRecords = query.Count();
            query = Sort(query, search.SortColumn, search.SortDirection.ToString());
            var data = Page(query, search.Page, search.PageSize).ToList();
            return data;
        }

        public int Count(Expression<Func<BillOfMaterial, bool>> filter)
        {
            return Filter(filter).Count();
        }

        public List<BomComment> GetCommentsForBom(string bomId)
        {
            var comments = new List<BomComment>();
            var bom = GetChildDocument(c => c.BomId == ObjectId.Parse(bomId), "Comments", "BomId");
            if (bom != null && bom.Comments != null && bom.Comments.Any())
                comments = bom.Comments.OrderBy(c => c.CreatedDate).ToList();
            return comments;
        }

        /// <summary>
        ///  Get the single column values after filteration
        /// </summary>
        /// <param name="search"></param>
        /// <param name="userId"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public List<string> GetFilteredSingleColumnValues(SearchSortModel search, string userId, bool isAdmin)
        {
            var query = Query.Where(t => t.Type == BomType.Bom);
            if (!string.IsNullOrEmpty(search.SearchString))
            {
                query = query.Where(t => t.Name.ToLower().Contains(search.SearchString) || t.Description.ToLower().Contains(search.SearchString));
            }

            if (!isAdmin && !string.IsNullOrEmpty(userId))
                query = query.Where(t => t.CreatedBy.ToLower().Contains(userId.ToLower()));

            var expression = GenericHelper.MemberSelector<BillOfMaterial, string>(CollectionName, search.SingleColumnName);
            var data = query.Select(expression).Distinct().ToList();
            return data;
        }

        /// <summary>
        /// Get List of boms by bom ids
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public List<BillOfMaterial> GetBillOfMaterialsByIdentifiers(List<ObjectId> ids)
        {
            var data = Query.Select(bom => new BillOfMaterial
            {
                CreatedDate = bom.CreatedDate,
                BomId = bom.BomId,
                Name = bom.Name,
                Status = bom.Status,
                Type = bom.Type,
                Description = bom.Description,
                IsActive = bom.IsActive,
                TemplateId = bom.TemplateId,
                Option = bom.Option,
                BomUser = bom.BomUser,
                Location = bom.Location,
                Owner = bom.Owner,
                License = bom.License
            }).Where(t => ids.Contains(t.BomId)).ToList();

            return data;
        }
    }
}
