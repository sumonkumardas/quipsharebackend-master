﻿using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using SubQuip.Data.Interfaces;
using System.Linq;
using SubQuip.Common.CommonData;
using SubQuip.Entity.Models;
using SubQuip.Common.Extensions;
using MongoDB.Driver;
using System;
using MongoDB.Bson;

namespace SubQuip.Data.Logic
{
    public class MaterialRepository : Repository<Material>, IMaterialRepository
    {
        public IConfiguration Configuration;

        /// <summary>
        /// Initializes a new instance of the MaterialRepository
        /// </summary>
        /// <param name="configuration"></param>
        public MaterialRepository(IConfiguration configuration) : base(configuration, "material")
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Get All Materials.
        /// </summary>
        /// <param name="search"></param>
        /// <param name="istechSpecRequired"></param>
        /// <param name="ids"></param>
        /// <returns></returns>
        public List<Material> GetAllMaterials(SearchSortModel search, bool istechSpecRequired, List<ObjectId> ids = null)
        {
            var query = from material in Query
                        select new Material
                        {
                            MaterialId = material.MaterialId,
                            Materialnumber = material.Materialnumber,
                            Description = material.Description,
                            ManufactorPartNumber = material.ManufactorPartNumber,
                            Type = material.Type,
                            ManufactorName = material.ManufactorName,
                            CreatedDate = material.CreatedDate,
                            Owner = material.Owner,
                            Location = material.Location,
                            IsActive = material.IsActive,
                            TechnicalSpecifications = (istechSpecRequired ? material.TechnicalSpecifications : null)
                        };

            if (!string.IsNullOrEmpty(search.SearchString))
            {
                query = query.Where(t => t.Materialnumber.ToLower().Contains(search.SearchString)
                                         || t.Description.ToLower().Contains(search.SearchString)
                                         || t.ManufactorPartNumber.ToLower().Contains(search.SearchString)
                                         || t.Type.ToLower().Contains(search.SearchString)
                                         || t.ManufactorName.ToLower().Contains(search.SearchString)
                );
            }

            if (ids != null)
            {
                query = query.Where(t => ids.Contains(t.MaterialId));
            }

            if (search.Filters.Any())
            {
                var deleg = ExpressionBuilder.GetExpression<Material>(search.Filters);
                query = query.Where(deleg);
            }

            query = Sort(query, search.SortColumn, search.SortDirection.ToString());
            var data = Page(query, search.Page, search.PageSize).ToList();
            search.TotalRecords = query.Count();
            return data;
        }

        /// <summary>
        /// Get Recent added materials in week
        /// </summary>
        /// <returns></returns>
        public long GetRecentAddedMaterials()
        {
            var start = GenericHelper.CurrentDate.AddDays(Convert.ToDouble(Configuration["PastDays"])).Date;
            var end = GenericHelper.CurrentDate.AddDays(1).Date; // To include the today date upto 24 hrs
            var filterBuilder = Builders<Material>.Filter;
            var filter = filterBuilder.Gte(x => x.CreatedDate, start) &
                         filterBuilder.Lt(x => x.CreatedDate, end);
            return Collection.Find(filter).Count();
        }

        /// <summary>
        /// Get the single column values after filteration
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public List<string> GetFilteredSingleColumnValues(SearchSortModel search)
        {
            var query = Query.Where(t => true);
            if (!string.IsNullOrEmpty(search.SearchString))
            {
                query = query.Where(t => t.Materialnumber.ToLower().Contains(search.SearchString)
                                         || t.Description.ToLower().Contains(search.SearchString)
                                         || t.ManufactorPartNumber.ToLower().Contains(search.SearchString)
                                         || t.Type.ToLower().Contains(search.SearchString)
                                         || t.ManufactorName.ToLower().Contains(search.SearchString)
                );
            }

            var expression = GenericHelper.MemberSelector<Material, string>(CollectionName, search.SingleColumnName);
            var data = query.Select(expression).Distinct().ToList();
            return data;
        }
    }
}
